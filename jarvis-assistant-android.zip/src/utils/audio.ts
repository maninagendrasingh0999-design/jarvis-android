/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AssistantLanguage } from './jarvis-core';

// Web Audio API context for futuristic sound synthesizer
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Play futuristic Stark HUD sound effects without external files
 */
export function playHudSound(type: 'beep' | 'confirm' | 'listen' | 'alert' | 'startup') {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const now = ctx.currentTime;

    osc.connect(gain);
    gain.connect(ctx.destination);

    switch (type) {
      case 'listen':
        // Ascending dual cyber chirp
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
        break;

      case 'confirm':
        // Two-tone confirmation ping
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.08); // A5
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
        osc.start(now);
        osc.stop(now + 0.25);
        break;

      case 'alert':
        // Warning dual pulse
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(240, now + 0.2);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
        break;

      case 'startup':
        // High-tech power-up sweep
        osc.type = 'sine';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(1174.66, now + 0.35);
        gain.gain.setValueAtTime(0.01, now);
        gain.gain.linearRampToValueAtTime(0.15, now + 0.15);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
        osc.start(now);
        osc.stop(now + 0.4);
        break;

      case 'beep':
      default:
        // Subtle cyber click
        osc.type = 'sine';
        osc.frequency.setValueAtTime(960, now);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
        osc.start(now);
        osc.stop(now + 0.06);
        break;
    }
  } catch (e) {
    // Audio context may be restricted by autoplay policy until user gesture
  }
}

/**
 * Speech Recognition Wrapper
 */
export function getSpeechRecognition(): any {
  if (typeof window === 'undefined') return null;
  const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  if (!SpeechRecognition) return null;
  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.maxAlternatives = 1;
  return recognition;
}

export function mapLanguageToLocale(lang: AssistantLanguage): string {
  switch (lang) {
    case 'hi':
      return 'hi-IN';
    case 'hinglish':
      return 'en-IN'; // Indian English handles Hinglish phonetics best in Web Speech API
    case 'en':
    default:
      return 'en-US';
  }
}

/**
 * Text-to-Speech synthesis with female voice preferences
 */
export function speakText(
  text: string,
  lang: AssistantLanguage,
  options: {
    preferredVoiceName?: string;
    rate?: number;
    pitch?: number;
    onEnd?: () => void;
    onError?: (err: any) => void;
  } = {}
): SpeechSynthesisUtterance | null {
  if (typeof window === 'undefined' || !window.speechSynthesis) return null;

  try {
    window.speechSynthesis.cancel(); // Stop any pending speech

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = options.rate ?? 1.0;
    utterance.pitch = options.pitch ?? 1.05; // Slightly higher pitch for natural female tone
    utterance.lang = mapLanguageToLocale(lang);

    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      let selectedVoice: SpeechSynthesisVoice | undefined;

      // 1. Check if user specified a voice
      if (options.preferredVoiceName) {
        selectedVoice = voices.find((v) => v.name.includes(options.preferredVoiceName!));
      }

      // 2. Look for natural female voices for target language
      if (!selectedVoice) {
        const langCode = utterance.lang.split('-')[0];
        const matchingVoices = voices.filter((v) => v.lang.startsWith(langCode));

        // Prioritize female voice names in browser synthesis
        const femaleVoice = (matchingVoices.length ? matchingVoices : voices).find((v) => {
          const n = v.name.toLowerCase();
          return (
            n.includes('female') ||
            n.includes('woman') ||
            n.includes('zira') ||
            n.includes('samantha') ||
            n.includes('karen') ||
            n.includes('victoria') ||
            n.includes('veena') ||
            n.includes('lekha') ||
            n.includes('google')
          );
        });

        selectedVoice = femaleVoice || matchingVoices[0] || voices[0];
      }

      if (selectedVoice) {
        utterance.voice = selectedVoice;
      }
    }

    if (options.onEnd) {
      utterance.onend = () => options.onEnd?.();
    }
    if (options.onError) {
      utterance.onerror = (e) => options.onError?.(e);
    }

    window.speechSynthesis.speak(utterance);
    return utterance;
  } catch (e) {
    console.error('Speech synthesis error:', e);
    options.onError?.(e);
    return null;
  }
}

export function stopSpeaking() {
  if (typeof window !== 'undefined' && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
}

/**
 * Real Web Torch API Controller (distinguishes hardware capability vs Android native)
 */
let torchMediaStream: MediaStream | null = null;

export async function toggleWebTorch(desiredState?: boolean): Promise<{ success: boolean; state: boolean; message: string }> {
  try {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return {
        success: false,
        state: false,
        message: 'Camera MediaDevices API is unavailable in this environment.',
      };
    }

    // If currently running and want to turn off
    if (torchMediaStream) {
      torchMediaStream.getTracks().forEach((track) => track.stop());
      torchMediaStream = null;
      if (desiredState === false || desiredState === undefined) {
        return { success: true, state: false, message: 'Torch illumination deactivated.' };
      }
    }

    if (desiredState === false) {
      return { success: true, state: false, message: 'Torch is currently OFF.' };
    }

    // Try acquiring back-facing camera with torch capability
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: { ideal: 'environment' },
      },
    });

    const track = stream.getVideoTracks()[0];
    const capabilities = (track.getCapabilities ? track.getCapabilities() : {}) as any;

    if (capabilities.torch) {
      await (track as any).applyConstraints({
        advanced: [{ torch: true }],
      });
      torchMediaStream = stream;
      return { success: true, state: true, message: 'Torch activated via Web Torch API.' };
    } else {
      // Camera acquired but hardware torch not exposed on this sensor
      track.stop();
      return {
        success: false,
        state: false,
        message: 'Camera sensor found, but hardware flashlight/torch constraint is not supported by this device browser. Native Android CameraManager.setTorchMode is required.',
      };
    }
  } catch (err: any) {
    return {
      success: false,
      state: false,
      message: err.name === 'NotAllowedError'
        ? 'Camera permission was denied. Flashlight control requires camera permission.'
        : `Torch could not be initialized: ${err.message || 'Device restriction'}. Android Native Camera2 API handles this directly.`,
    };
  }
}
