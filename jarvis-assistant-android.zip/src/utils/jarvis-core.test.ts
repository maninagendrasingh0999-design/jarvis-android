/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseJarvisIntent,
  isInstantLocalCommand,
  getJarvisGreeting,
  generateOfflineJarvisResponse,
} from './jarvis-core';

test('parseJarvisIntent correctly identifies YouTube command in English and Hindi', () => {
  const enIntent = parseJarvisIntent('Open YouTube and play Iron Man theme', 'en');
  assert.equal(enIntent.type, 'OPEN_YOUTUBE');
  assert.equal(enIntent.webFallbackSupported, true);

  const hiIntent = parseJarvisIntent('यूट्यूब खोलो', 'hi');
  assert.equal(hiIntent.type, 'OPEN_YOUTUBE');

  const hinglishIntent = parseJarvisIntent('YouTube pe video chalao', 'hinglish');
  assert.equal(hinglishIntent.type, 'OPEN_YOUTUBE');
});

test('parseJarvisIntent specifically detects YouTube kholo, Open YouTube, and YouTube chalao without query leftovers', () => {
  // 1. "YouTube kholo"
  const kholoIntent = parseJarvisIntent('YouTube kholo', 'hinglish');
  assert.equal(kholoIntent.type, 'OPEN_YOUTUBE');
  assert.equal(kholoIntent.payload?.query, '', 'Query should be empty string for direct homepage launch');

  // 2. "Open YouTube"
  const openIntent = parseJarvisIntent('Open YouTube', 'en');
  assert.equal(openIntent.type, 'OPEN_YOUTUBE');
  assert.equal(openIntent.payload?.query, '', 'Query should be empty for Open YouTube');

  // 3. "YouTube chalao"
  const chalaoIntent = parseJarvisIntent('YouTube chalao', 'hinglish');
  assert.equal(chalaoIntent.type, 'OPEN_YOUTUBE');
  assert.equal(chalaoIntent.payload?.query, '', 'Query should be empty for YouTube chalao');

  // 4. Hindi script: "यूट्यूब चलाओ" & "यूट्यूब खोलो"
  const hiChalao = parseJarvisIntent('यूट्यूब चलाओ', 'hi');
  assert.equal(hiChalao.type, 'OPEN_YOUTUBE');
  assert.equal(hiChalao.payload?.query, '');

  const hiKholo = parseJarvisIntent('यूट्यूब खोलो', 'hi');
  assert.equal(hiKholo.type, 'OPEN_YOUTUBE');
  assert.equal(hiKholo.payload?.query, '');

  // 5. Search topic extraction: "YouTube pe Stark Tech search karo"
  const searchIntent = parseJarvisIntent('YouTube pe Stark Tech search karo', 'hinglish');
  assert.equal(searchIntent.type, 'OPEN_YOUTUBE');
  assert.equal(searchIntent.payload?.query, 'Stark Tech');
});

test('parseJarvisIntent identifies phone call and flags Android Native requirement', () => {
  const dialIntent = parseJarvisIntent('Call +1 800 555 0199', 'en');
  assert.equal(dialIntent.type, 'CALL_PHONE');
  assert.equal(dialIntent.requiresAndroidNative, true);
  assert.ok(dialIntent.androidPermission?.includes('CALL_PHONE'));
  assert.equal(dialIntent.payload?.phoneNumber, '+18005550199');
});

test('parseJarvisIntent identifies torch/flashlight toggles in Hinglish and Hindi', () => {
  const torchOn = parseJarvisIntent('Torch chalu karo', 'hinglish');
  assert.equal(torchOn.type, 'TORCH_CONTROL');
  assert.equal(torchOn.payload?.torchState, 'on');
  assert.equal(torchOn.requiresAndroidNative, true);

  const torchOff = parseJarvisIntent('लाइट बंद करो', 'hi');
  assert.equal(torchOff.type, 'TORCH_CONTROL');
  assert.equal(torchOff.payload?.torchState, 'off');
});

test('parseJarvisIntent identifies reminders with calculated duration', () => {
  const rem = parseJarvisIntent('Remind me to recharge armor in 15 minutes', 'en');
  assert.equal(rem.type, 'SET_REMINDER');
  assert.equal(rem.payload?.reminderMinutes, 15);
  assert.equal(rem.requiresAndroidNative, true);
});

test('parseJarvisIntent identifies device settings request', () => {
  const settingsIntent = parseJarvisIntent('Open phone settings and wifi', 'en');
  assert.equal(settingsIntent.type, 'OPEN_SETTINGS');
  assert.equal(settingsIntent.requiresAndroidNative, true);
  assert.equal(settingsIntent.webFallbackSupported, false);
});

test('getJarvisGreeting returns localized greeting', () => {
  assert.ok(getJarvisGreeting('en').includes('JARVIS'));
  assert.ok(getJarvisGreeting('hi').includes('नमस्ते'));
  assert.ok(getJarvisGreeting('hinglish').includes('Namaste'));
});

test('generateOfflineJarvisResponse handles time queries deterministically and concisely', () => {
  const respEn = generateOfflineJarvisResponse('What is the time?', 'en');
  assert.ok(respEn.toLowerCase().includes('time is'));
  const respHi = generateOfflineJarvisResponse('समय क्या हुआ है?', 'hi');
  assert.ok(respHi.includes('समय'));
});

test('isInstantLocalCommand correctly filters simple commands from complex AI queries', () => {
  // Simple commands must be flagged as instant:
  const ytCheck = isInstantLocalCommand('YouTube kholo', 'hinglish');
  assert.equal(ytCheck.isInstant, true);
  assert.equal(ytCheck.intent.type, 'OPEN_YOUTUBE');

  const torchCheck = isInstantLocalCommand('Torch on karo', 'hinglish');
  assert.equal(torchCheck.isInstant, true);
  assert.equal(torchCheck.intent.type, 'TORCH_CONTROL');

  const timeCheck = isInstantLocalCommand('Time batao', 'hinglish');
  assert.equal(timeCheck.isInstant, true);
  assert.equal(timeCheck.intent.type, 'TIME_QUERY');

  const timeHi = isInstantLocalCommand('समय बताओ', 'hi');
  assert.equal(timeHi.isInstant, true);
  assert.equal(timeHi.intent.type, 'TIME_QUERY');

  // Complex reasoning queries must NOT be instant (routed to Gemini AI)
  const aiQuery = isInstantLocalCommand('Who built the Arc Reactor in Avengers?', 'en');
  assert.equal(aiQuery.isInstant, false);
  assert.equal(aiQuery.intent.type, 'GENERAL_CHAT');
});

test('executeJarvisAction returns actionable YouTube URL and Android Intent details', async () => {
  const { executeJarvisAction } = await import('./action-executor');
  const ytIntent = parseJarvisIntent('YouTube kholo', 'hinglish');
  const actionRes = executeJarvisAction(ytIntent);

  assert.equal(actionRes.type, 'OPEN_YOUTUBE');
  assert.ok(actionRes.url?.startsWith('https://www.youtube.com'));
  assert.ok(actionRes.androidIntent?.includes('vnd.youtube:'));
  assert.ok(actionRes.feedbackText.length > 0);
  assert.ok(['executed', 'ready_to_launch', 'blocked_popup'].includes(actionRes.status));
});

test('Speech Recognition configuration supports continuous listening and interim results', async () => {
  // Mock SpeechRecognition in node environment
  class MockSpeechRecognition {
    continuous = false;
    interimResults = false;
    maxAlternatives = 0;
  }
  (globalThis as any).window = {
    SpeechRecognition: MockSpeechRecognition,
  };

  const { getSpeechRecognition, mapLanguageToLocale } = await import('./audio');
  const recognition = getSpeechRecognition();

  assert.ok(recognition);
  assert.equal(recognition.continuous, true, 'Speech recognition must be continuous to support 15-20s listening');
  assert.equal(recognition.interimResults, true, 'Interim results must be enabled to show real-time words');
  assert.equal(recognition.maxAlternatives, 1);

  assert.equal(mapLanguageToLocale('hi'), 'hi-IN');
  assert.equal(mapLanguageToLocale('hinglish'), 'en-IN');
  assert.equal(mapLanguageToLocale('en'), 'en-US');
});

test('Multi-clause 10-second Hindi command is parsed with full intent preservation', () => {
  const longHindiCommand = 'नमस्ते जार्विस कृपया यूट्यूब खोलो और अरिजीत सिंह के नए गाने चलाओ';
  const intent = parseJarvisIntent(longHindiCommand, 'hi');

  assert.equal(intent.type, 'OPEN_YOUTUBE');
  assert.ok(intent.payload?.query?.includes('अरिजीत सिंह'));
});

test('Multi-clause Hinglish sentence with mid-sentence pause is parsed completely without truncation', () => {
  // Simulating user speaking "YouTube kholo" followed after a pause by "aur Iron Man theme bajao"
  const clause1 = 'YouTube kholo';
  const clause2 = 'aur Iron Man theme bajao';
  const combinedSpokenUtterance = `${clause1} ${clause2}`;

  const intent = parseJarvisIntent(combinedSpokenUtterance, 'hinglish');
  assert.equal(intent.type, 'OPEN_YOUTUBE');
  assert.ok(intent.payload?.query?.includes('Iron Man theme'));
});

test('parseJarvisIntent correctly extracts WhatsApp recipient name and message text', () => {
  const whatsappIntent = parseJarvisIntent('Amit Patel ko WhatsApp par message bhejo: taiyar ho jao', 'hinglish');
  assert.equal(whatsappIntent.type, 'SEND_WHATSAPP');
  assert.equal(whatsappIntent.payload?.recipientName, 'Amit Patel');
  assert.equal(whatsappIntent.payload?.messageText, 'taiyar ho jao');

  const hindiWa = parseJarvisIntent('Papa ko WhatsApp par good morning bhejo', 'hi');
  assert.equal(hindiWa.type, 'SEND_WHATSAPP');
  assert.equal(hindiWa.payload?.recipientName, 'Papa');
  assert.ok(hindiWa.payload?.messageText?.includes('good morning'));

  // Test: Rahul ko bolo ki main 10 minute mein aa raha hoon
  const rahulWa = parseJarvisIntent('Rahul ko bolo ki main 10 minute mein aa raha hoon', 'hinglish');
  assert.equal(rahulWa.type, 'SEND_WHATSAPP');
  assert.equal(rahulWa.payload?.recipientName, 'Rahul');
  assert.ok(rahulWa.payload?.messageText?.includes('10 minute mein aa raha hoon'));

  // Test: Papa ko good morning ka message likho
  const papaMsg = parseJarvisIntent('Papa ko good morning ka message likho', 'hinglish');
  assert.equal(papaMsg.type, 'SEND_WHATSAPP');
  assert.equal(papaMsg.payload?.recipientName, 'Papa');
  assert.ok(papaMsg.payload?.messageText?.includes('good morning'));
});

test('parseJarvisIntent extracts contact name from call command', () => {
  const callIntent = parseJarvisIntent('Amit Patel ko call lagao', 'hinglish');
  assert.equal(callIntent.type, 'CALL_PHONE');
  assert.equal(callIntent.payload?.phoneNumber, 'Amit Patel');

  const callEn = parseJarvisIntent('Call Dr Banner', 'en');
  assert.equal(callEn.type, 'CALL_PHONE');
  assert.equal(callEn.payload?.phoneNumber, 'Dr Banner');
});

test('parseJarvisIntent identifies Google Maps navigation commands', () => {
  const navEn = parseJarvisIntent('Navigate to Mumbai', 'en');
  assert.equal(navEn.type, 'OPEN_MAPS');
  assert.equal(navEn.payload?.destination, 'Mumbai');

  const navHi = parseJarvisIntent('Taj Mahal ka rasta dikhao', 'hinglish');
  assert.equal(navHi.type, 'OPEN_MAPS');
  assert.equal(navHi.payload?.destination, 'Taj Mahal');
});

test('parseJarvisIntent identifies Open App commands', () => {
  const appCalc = parseJarvisIntent('Open Calculator', 'en');
  assert.equal(appCalc.type, 'OPEN_APP');
  assert.equal(appCalc.payload?.appName, 'Calculator');

  const appCam = parseJarvisIntent('Camera kholo', 'hinglish');
  assert.equal(appCam.type, 'OPEN_APP');
  assert.equal(appCam.payload?.appName, 'Camera');
});

test('isInstantLocalCommand flags WhatsApp, Calling, Maps, and App commands as instant (<5ms)', () => {
  const waCheck = isInstantLocalCommand('Rahul ko WhatsApp message bhejo: hello', 'hinglish');
  assert.equal(waCheck.isInstant, true);
  assert.equal(waCheck.intent.type, 'SEND_WHATSAPP');

  const callCheck = isInstantLocalCommand('Amit Patel ko call lagao', 'hinglish');
  assert.equal(callCheck.isInstant, true);
  assert.equal(callCheck.intent.type, 'CALL_PHONE');

  const mapsCheck = isInstantLocalCommand('Navigate to Connaught Place', 'en');
  assert.equal(mapsCheck.isInstant, true);
  assert.equal(mapsCheck.intent.type, 'OPEN_MAPS');

  const appCheck = isInstantLocalCommand('Spotify kholo', 'hinglish');
  assert.equal(appCheck.isInstant, true);
  assert.equal(appCheck.intent.type, 'OPEN_APP');

  const shutdownCheck = isInstantLocalCommand('Javed shutdown ho jao', 'hinglish');
  assert.equal(shutdownCheck.isInstant, true);
  assert.equal(shutdownCheck.intent.type, 'STANDBY_MODE');

  const wakeCheck = isInstantLocalCommand('Hallo Javed', 'hinglish');
  assert.equal(wakeCheck.isInstant, true);
  assert.equal(wakeCheck.intent.type, 'WAKE_WORD_TRIGGER');
  assert.equal(wakeCheck.reply, 'Ji, main sun rahi hoon. Bataiye, kya karna hai?');
});

test('parseJarvisIntent identifies Hallo Javed wake word and custom response', () => {
  const wake1 = parseJarvisIntent('Hallo Javed', 'hinglish');
  assert.equal(wake1.type, 'WAKE_WORD_TRIGGER');
  assert.equal(wake1.suggestedResponse.hinglish, 'Ji, main sun rahi hoon. Bataiye, kya karna hai?');

  const wake2 = parseJarvisIntent('Hello Javed', 'en');
  assert.equal(wake2.type, 'WAKE_WORD_TRIGGER');

  const wake3 = parseJarvisIntent('halo javed', 'hi');
  assert.equal(wake3.type, 'WAKE_WORD_TRIGGER');
});

test('parseJarvisIntent identifies Shutdown and Standby in English, Hinglish, and Hindi', () => {
  const shut1 = parseJarvisIntent('Javed shutdown ho jao', 'hinglish');
  assert.equal(shut1.type, 'STANDBY_MODE');

  const shut2 = parseJarvisIntent('Shutdown ho jao', 'hinglish');
  assert.equal(shut2.type, 'STANDBY_MODE');

  const shut3 = parseJarvisIntent('Band ho jao', 'hinglish');
  assert.equal(shut3.type, 'STANDBY_MODE');

  const shutHi = parseJarvisIntent('सुनना बंद करो', 'hi');
  assert.equal(shutHi.type, 'STANDBY_MODE');
});



