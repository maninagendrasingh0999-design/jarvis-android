/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AssistantLanguage = 'en' | 'hi' | 'hinglish';

export type AssistantState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error';

export type CommandIntentType =
  | 'OPEN_YOUTUBE'
  | 'CALL_PHONE'
  | 'TORCH_CONTROL'
  | 'SET_REMINDER'
  | 'OPEN_SETTINGS'
  | 'SYSTEM_STATUS'
  | 'TIME_QUERY'
  | 'DATE_QUERY'
  | 'SEND_WHATSAPP'
  | 'OPEN_MAPS'
  | 'OPEN_APP'
  | 'STOP_LISTENING'
  | 'WAKE_WORD_TRIGGER'
  | 'STANDBY_MODE'
  | 'GENERAL_CHAT';

export interface CommandIntent {
  type: CommandIntentType;
  rawQuery: string;
  payload?: {
    query?: string;
    phoneNumber?: string;
    torchState?: 'on' | 'off' | 'toggle';
    reminderText?: string;
    reminderMinutes?: number;
    recipientName?: string;
    messageText?: string;
    destination?: string;
    appName?: string;
  };
  requiresAndroidNative: boolean;
  nativeReason?: string;
  androidIntent?: string;
  androidPermission?: string;
  webFallbackSupported: boolean;
  suggestedResponse: Record<AssistantLanguage, string>;
}

/**
 * Analyzes natural language input in English, Hindi, or Hinglish
 * and extracts actionable device or assistant intents.
 */
export function parseJarvisIntent(rawText: string, lang: AssistantLanguage = 'en'): CommandIntent {
  const query = (rawText || '').trim();
  const lower = query.toLowerCase();

  // 1. Phone Settings Intent (check before phone calling to prevent "phone settings" from triggering dialer)
  if (
    lower.includes('setting') ||
    lower.includes('सेटिंग') ||
    lower.includes('wifi') ||
    lower.includes('bluetooth') ||
    lower.includes('brightness') ||
    lower.includes('display')
  ) {
    return {
      type: 'OPEN_SETTINGS',
      rawQuery: query,
      requiresAndroidNative: true,
      nativeReason: 'Android OS restricts deep system setting changes (Wi-Fi, Bluetooth, Display) to system apps or Android Settings Intents (android.provider.Settings.ACTION_SETTINGS).',
      androidIntent: 'Intent(Settings.ACTION_SETTINGS)',
      androidPermission: 'android.permission.WRITE_SETTINGS',
      webFallbackSupported: false,
      suggestedResponse: {
        en: 'System configuration portal required. In native Android, this triggers Settings.ACTION_SETTINGS.',
        hi: 'डिवाइस सेटिंग्स खोलने के लिए एंड्रॉइड सेटिंग्स इंटेंट की आवश्यकता है।',
        hinglish: 'Sir, phone system settings native Android me Settings.ACTION_SETTINGS se open hoti hain.',
      },
    };
  }

  // WAKE WORD: "Hallo Javed", "Hello Javed", "Halo Javed", "Hey Javed"
  if (
    lower === 'hallo javed' ||
    lower === 'hello javed' ||
    lower === 'halo javed' ||
    lower === 'hey javed' ||
    lower === 'javed' ||
    lower === 'hello jarvis' ||
    lower === 'hallo jarvis' ||
    lower === 'hey jarvis' ||
    lower === 'jarvis'
  ) {
    return {
      type: 'WAKE_WORD_TRIGGER',
      rawQuery: query,
      requiresAndroidNative: false,
      webFallbackSupported: true,
      suggestedResponse: {
        en: 'Ji, main sun rahi hoon. Bataiye, kya karna hai?',
        hi: 'जी, मैं सुन रही हूँ। बताइए, क्या करना है?',
        hinglish: 'Ji, main sun rahi hoon. Bataiye, kya karna hai?',
      },
    };
  }

  // STANDBY / SHUTDOWN INTENT: "Javed shutdown ho jao", "Shutdown ho jao", "Band ho jao", "Javed band ho jao"
  if (
    lower.includes('shutdown ho jao') ||
    lower.includes('javed shutdown') ||
    lower.includes('shutdown javed') ||
    lower.includes('band ho jao') ||
    lower.includes('javed band ho jao') ||
    lower.includes('band hojao') ||
    lower.includes('shutdown') ||
    lower.includes('shut down') ||
    lower.includes('stop listening') ||
    lower.includes('stop jarvis') ||
    lower.includes('jarvis stop') ||
    lower.includes('ruk jao') ||
    lower.includes('रुको') ||
    lower.includes('बंद हो जाओ') ||
    lower.includes('सुनना बंद करो') ||
    lower === 'stop' ||
    lower === 'बंद करो'
  ) {
    return {
      type: 'STANDBY_MODE',
      rawQuery: query,
      requiresAndroidNative: false,
      androidIntent: 'JarvisVoiceForegroundService.enterStandbyMode()',
      webFallbackSupported: true,
      suggestedResponse: {
        en: 'Returning to standby mode, Sir. Wake-word detection remains active. Say "Hallo Javed" when ready.',
        hi: 'स्टैंडबाय मोड में जा रही हूँ, सर। वेक-वर्ड पहचान सक्रिय है। तैयार होने पर "Hallo Javed" कहें।',
        hinglish: 'Ji Sir, standby mode mein ja rahi hoon. "Hallo Javed" bolte hi main active ho jaungi.',
      },
    };
  }

  // WhatsApp Message Intent
  if (
    lower.includes('whatsapp') ||
    lower.includes('wa par') ||
    lower.includes('ko likho') ||
    lower.includes('ko bolo') ||
    lower.includes('ko kaho') ||
    lower.includes('ko message') ||
    lower.includes('message bhejo') ||
    lower.includes('ko bhejo') ||
    lower.includes('व्हाट्सएप') ||
    lower.includes('सन्देश') ||
    lower.includes('संदेश')
  ) {
    let recipientName = '';
    let messageText = '';

    // Strip conversational greetings/prefixes
    const cleanText = query.replace(/^(?:jarvis|hey\s*jarvis|please|zara|kripya)[,\s]*/gi, '').trim();

    // Pattern 1: Colon separator (e.g. "Amit Patel ko WhatsApp par message bhejo: taiyar ho jao")
    const colonSplit = cleanText.split(/[:：]/);
    if (colonSplit.length > 1) {
      messageText = colonSplit.slice(1).join(':').trim();
      const prefix = colonSplit[0];
      recipientName = prefix
        .replace(/whatsapp\s*par|whatsapp\s*pe|whatsapp|पर|par|pe|ko\s*message\s*bhejo|ko|message|bhejo|likho|send|ka|bhejna/gi, '')
        .trim();
    } else {
      // Pattern 2: "Rahul ko bolo ki main 10 minute mein aa raha hoon"
      const boloMatch = cleanText.match(/(.*?)\s+ko\s+(?:bolo|kaho)\s+(?:ki\s+)?(.*)/i);
      if (boloMatch) {
        recipientName = boloMatch[1].replace(/whatsapp|par|pe/gi, '').trim();
        messageText = boloMatch[2].trim();
      } else {
        // Pattern 3: "Papa ko good morning ka message likho" or "Papa ko good morning bhejo"
        const msgMatch = cleanText.match(/(.*?)\s+ko\s+(.*?)\s+(?:ka\s+)?(?:message|sandesh|सन्देश|संदेश)?\s*(?:likho|bhejo|send\s*karo|karo)\s*$/i);
        if (msgMatch && msgMatch[2]) {
          recipientName = msgMatch[1].replace(/whatsapp|par|pe/gi, '').trim();
          messageText = msgMatch[2].replace(/whatsapp|par|pe|ka\s*message/gi, '').trim();
        } else {
          // Pattern 4: Generic regex fallback
          const genericMatch = cleanText.match(/(.*?)\s+ko\s+(.*)/i);
          if (genericMatch) {
            recipientName = genericMatch[1].replace(/whatsapp|par|pe/gi, '').trim();
            messageText = genericMatch[2].replace(/^(?:ki\s+|message\s+|bhejo\s+|likho\s+)+/gi, '').trim();
          } else {
            messageText = cleanText.replace(/whatsapp|bhejo|likho|send/gi, '').trim();
          }
        }
      }
    }

    if (!recipientName) recipientName = 'Amit Patel';
    if (!messageText) messageText = 'Hello from JARVIS AI';

    return {
      type: 'SEND_WHATSAPP',
      rawQuery: query,
      payload: { recipientName, messageText },
      requiresAndroidNative: true,
      nativeReason: 'Official WhatsApp messaging intent requires WhatsApp package installed and Android contacts permission.',
      androidIntent: `Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?text=${encodeURIComponent(messageText)}"))`,
      androidPermission: 'android.permission.READ_CONTACTS',
      webFallbackSupported: true,
      suggestedResponse: {
        en: `WhatsApp message ready for ${recipientName}: "${messageText}". Review and tap confirm to send.`,
        hi: `${recipientName} के लिए व्हाट्सएप संदेश तैयार है: "${messageText}"। समीक्षा करें और पुष्टि करें।`,
        hinglish: `Sir, ${recipientName} ke liye WhatsApp message ready hai: "${messageText}". Review karke confirm karein.`,
      },
    };
  }

  // 2. YouTube Intent
  if (
    lower.includes('youtube') ||
    lower.includes('यूट्यूब') ||
    lower.includes('यू ट्यूब') ||
    lower.includes('play song') ||
    lower.includes('gaana bajao') ||
    lower.includes('gana bajao') ||
    lower.includes('gaana chalao') ||
    lower.includes('gana chalao') ||
    lower.includes('video chalao') ||
    lower.includes('गाना बजाओ') ||
    lower.includes('गाना चलाओ') ||
    lower.includes('वीडियो चलाओ')
  ) {
    let searchTopic = query.trim();

    // Strip conversational greetings/polite words
    searchTopic = searchTopic
      .replace(/^(?:please|kripya|zara|hey\s*jarvis|jarvis)\s*/gi, '')
      .replace(/\s*(?:please|jarvis|sir|boss)\s*$/gi, '');

    // Strip leading launch commands
    searchTopic = searchTopic
      .replace(/^(?:open\s*(?:the\s*)?youtube\s*(?:and\s*(?:search\s*(?:for)?|play))?)/gi, '')
      .replace(/^(?:launch|start|play|search\s*(?:for)?)\s*(?:the\s*)?(?:on\s*)?youtube\s*(?:and\s*(?:search\s*(?:for)?|play))?/gi, '')
      .replace(/^(?:kholo|chalao|start\s*karo|open\s*karo|chalu\s*karo|dekho)\s*(?:the\s*)?(?:youtube|यूट्यूब|यू\s*ट्यूब)\s*/gi, '')
      .replace(/^(?:यूट्यूब|यू\s*ट्यूब|youtube|yt)\s*(?:pe|par|me|mein|par\s*bhi)?\s*/gi, '')
      .replace(/^(?:search\s*(?:on)?\s*youtube\s*(?:for)?)\s*/gi, '');

    // Strip trailing action suffixes
    searchTopic = searchTopic
      .replace(/\s*(?:search\s*karo|search\s*kijiye|search|kholo|khol\s*do|kholna|chalao|chala\s*do|chalu\s*karo|bajao|baja\s*do|open\s*karo|start\s*karo|on\s*karo|play\s*karo|play)\s*$/gi, '')
      .replace(/\s*(?:on\s*youtube|in\s*youtube)\s*$/gi, '')
      .replace(/\s*(?:यूट्यूब|यू\s*ट्यूब)\s*(?:पर|में)?\s*$/gi, '')
      .replace(/\s*(?:खोलो|खोल\s*दो|चलाओ|चला\s*दो|बजाओ|बजा\s*दो|चालू\s*करो|ओपन\s*करो|सर्च\s*करो|दिखाओ)\s*$/gi, '')
      .replace(/^(?:and|aur|pe|par|me|mein)\s+/gi, '')
      .trim();

    // If leftover is empty or just generic words, treat as direct launch
    if (/^(?:youtube|यूट्यूब|यू\s*ट्यूब|yt|app|video|gana|gaana|song)?$/i.test(searchTopic)) {
      searchTopic = '';
    }

    return {
      type: 'OPEN_YOUTUBE',
      rawQuery: query,
      payload: { query: searchTopic },
      requiresAndroidNative: false, // Can open https://youtube.com on web; in native Android launches Intent(ACTION_VIEW, Uri.parse("vnd.youtube:..."))
      androidIntent: searchTopic
        ? `android.intent.action.SEARCH (query: "${searchTopic}")`
        : 'android.intent.action.VIEW (vnd.youtube:)',
      androidPermission: 'None (Standard Intent)',
      webFallbackSupported: true,
      suggestedResponse: {
        en: searchTopic
          ? `Direct link for "${searchTopic}" on YouTube is ready, Sir. Tap 'Open YouTube Now' below.`
          : "Direct link for YouTube is ready, Sir. Tap 'Open YouTube Now' below.",
        hi: searchTopic
          ? `यूट्यूब पर "${searchTopic}" का सीधा लिंक तैयार है, सर। कृपया नीचे दिए गए 'Open YouTube Now' बटन पर टैप करें।`
          : 'यूट्यूब का सीधा लिंक तैयार है, सर। कृपया नीचे दिए गए "Open YouTube Now" बटन पर टैप करें।',
        hinglish: searchTopic
          ? `Sir, YouTube par "${searchTopic}" ka direct link ready hai. Niche button par click karke open karein.`
          : 'Sir, YouTube direct link ready hai. Niche diye gaye button par click karke open karein.',
      },
    };
  }

  // 3. Phone Dialer Intent
  if (
    lower.includes('call') ||
    lower.includes('dial') ||
    lower.includes('phone') ||
    lower.includes('कॉल') ||
    lower.includes('फोन') ||
    lower.includes('milao') ||
    lower.includes('lagao') ||
    lower.includes('डायल') ||
    lower.includes('मिलाओ')
  ) {
    // Extract phone numbers or contact
    const numMatch = query.match(/\+?\d[\d\s-]{6,}\d/);
    const phoneNumber = numMatch ? numMatch[0].replace(/\s+/g, '') : '';
    let contactName = !phoneNumber
      ? query
          .replace(/^(?:jarvis|hey\s*jarvis|please|zara|kripya)\s*/gi, '')
          .replace(/\s*(?:ko\s*)?(?:call\s*lagao|call\s*karo|phone\s*lagao|phone\s*karo|dial\s*karo|milao|lagao|डायल|कॉल)\s*$/gi, '')
          .replace(/^(?:call|dial|phone|कॉल|मिलाओ)\s*/gi, '')
          .replace(/\s*ko$/gi, '')
          .trim()
      : undefined;

    return {
      type: 'CALL_PHONE',
      rawQuery: query,
      payload: { phoneNumber: phoneNumber || contactName },
      requiresAndroidNative: true, // Web can only trigger tel: URI, true automated dialing requires Android CALL_PHONE permission
      nativeReason: 'Direct automated calling without user confirmation requires Android CALL_PHONE permission. Web browsers trigger standard tel: dialer prompt.',
      androidIntent: phoneNumber ? `Intent(ACTION_DIAL, Uri.parse("tel:${phoneNumber}"))` : 'Intent(ACTION_DIAL)',
      androidPermission: 'android.permission.CALL_PHONE / READ_CONTACTS',
      webFallbackSupported: true, // tel: link can be triggered
      suggestedResponse: {
        en: phoneNumber
          ? `Initiating telecommunication protocol for ${phoneNumber}, Sir.`
          : `Preparing call protocol for ${contactName || 'contact'}, Sir. Please confirm.`,
        hi: phoneNumber
          ? `${phoneNumber} के लिए फोन डायलर खोला जा रहा है, सर।`
          : `${contactName || 'संपर्क'} को कॉल लगाने के लिए डायलर तैयार है, सर। पुष्टि करें।`,
        hinglish: phoneNumber
          ? `Sir, ${phoneNumber} ke liye dialer launch kar raha hoon.`
          : `Sir, ${contactName || 'contact'} ko call lagane ke liye dialer ready hai. Confirm karein.`,
      },
    };
  }

  // 4. Flashlight / Torch Intent
  if (
    lower.includes('flashlight') ||
    lower.includes('torch') ||
    lower.includes('light') ||
    lower.includes('टॉर्च') ||
    lower.includes('लाइट') ||
    lower.includes('battie') ||
    lower.includes('batti') ||
    lower.includes('रोशनी')
  ) {
    const isOff = lower.includes('off') || lower.includes('band') || lower.includes('बंद');
    const isOn = lower.includes('on') || lower.includes('chalu') || lower.includes('jal') || lower.includes('चालू') || lower.includes('जला');
    const torchState: 'on' | 'off' | 'toggle' = isOff ? 'off' : isOn ? 'on' : 'toggle';

    return {
      type: 'TORCH_CONTROL',
      rawQuery: query,
      payload: { torchState },
      requiresAndroidNative: true,
      nativeReason: 'Native Android uses CameraManager.setTorchMode(cameraId, boolean). Web browsers require navigator.mediaDevices camera track access with user permission.',
      androidIntent: 'CameraManager.setTorchMode(cameraId, state)',
      androidPermission: 'android.permission.CAMERA / FLASHLIGHT',
      webFallbackSupported: true,
      suggestedResponse: {
        en: `Illumination protocol set to ${torchState.toUpperCase()} (Web Preview Simulation). Physical phone LED requires native Android APK.`,
        hi: `टॉर्च प्रोटोकॉल ${torchState === 'off' ? 'बंद' : 'चालू'} (वेब सिमुलेशन), सर। फोन की वास्तविक फ्लैशलाइट के लिए नेटिव एंड्रॉइड ऐप आवश्यक है।`,
        hinglish: `Sir, torch ${torchState === 'off' ? 'band' : 'on'} (Web simulation mode). Phone hardware LED ke liye native Android APK zaroori hai.`,
      },
    };
  }

  // 5. Reminders / Alarms Intent
  if (
    lower.includes('remind') ||
    lower.includes('alarm') ||
    lower.includes('याद') ||
    lower.includes('अलार्म') ||
    lower.includes('yaad')
  ) {
    const minMatch = query.match(/(\d+)\s*(minute|min|m|ghante|hour|ghanta|मिनट|घंटे)/i);
    const minutes = minMatch ? parseInt(minMatch[1], 10) * (minMatch[2].startsWith('ghant') || minMatch[2].startsWith('hour') || minMatch[2].startsWith('घंटे') ? 60 : 1) : 10;
    const cleanReminder = query
      .replace(/remind\s*me\s*to/i, '')
      .replace(/set\s*reminder/i, '')
      .replace(/set\s*alarm/i, '')
      .replace(/in\s*\d+\s*(minutes|min|hours|ghante|मिनट|घंटे)/i, '')
      .replace(/yaad\s*dilana/i, '')
      .replace(/याद\s*दिलाना/i, '')
      .trim();

    return {
      type: 'SET_REMINDER',
      rawQuery: query,
      payload: {
        reminderText: cleanReminder || 'Scheduled Protocol Alert',
        reminderMinutes: minutes,
      },
      requiresAndroidNative: true,
      nativeReason: 'Persisted background wake alarms require Android AlarmManager and android.permission.SCHEDULE_EXACT_ALARM. In web preview, managed via browser scheduler & notifications.',
      androidIntent: 'Intent(AlarmClock.ACTION_SET_ALARM) or WorkManager',
      androidPermission: 'com.android.alarm.permission.SET_ALARM',
      webFallbackSupported: true,
      suggestedResponse: {
        en: `Reminder logged for ${minutes} minutes from now: "${cleanReminder || 'Alert'}", Sir.`,
        hi: `सर, ${minutes} मिनट बाद का रिमाइंडर सेट कर दिया गया है।`,
        hinglish: `Sir, ${minutes} minutes ke baad aapko yaad dila dunga: "${cleanReminder || 'Task'}".`,
      },
    };
  }

  // 6. Time Query Intent
  if (
    lower.includes('time') ||
    lower.includes('samay') ||
    lower.includes('waqt') ||
    lower.includes('समय') ||
    lower.includes('वक्त') ||
    lower.includes('टाइम')
  ) {
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return {
      type: 'TIME_QUERY',
      rawQuery: query,
      requiresAndroidNative: false,
      webFallbackSupported: true,
      suggestedResponse: {
        en: `Current time is ${timeStr}, Sir.`,
        hi: `सर, अभी समय ${timeStr} है।`,
        hinglish: `Sir, abhi ${timeStr} baje hain.`,
      },
    };
  }

  // 7. Date Query Intent
  if (
    lower.includes('date') ||
    lower.includes('tarikh') ||
    lower.includes('taarikh') ||
    lower.includes('aaj') ||
    lower.includes('तारीख') ||
    lower.includes('आज')
  ) {
    const dateStr = new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    return {
      type: 'DATE_QUERY',
      rawQuery: query,
      requiresAndroidNative: false,
      webFallbackSupported: true,
      suggestedResponse: {
        en: `Today is ${dateStr}, Sir.`,
        hi: `सर, आज ${dateStr} है।`,
        hinglish: `Sir, aaj ${dateStr} hai.`,
      },
    };
  }

  // 8. Google Maps & Navigation Intent
  if (
    lower.includes('map') ||
    lower.includes('maps') ||
    lower.includes('navigate') ||
    lower.includes('navigation') ||
    lower.includes('directions') ||
    lower.includes('rasta') ||
    lower.includes('रास्ता') ||
    lower.includes('दिशा')
  ) {
    let destination = query
      .replace(/^(?:jarvis|hey\s*jarvis|please|zara|kripya)[,\s]*/gi, '')
      .replace(/^(?:open\s*(?:the\s*)?google\s*maps?|open\s*maps?|google\s*maps?|maps?)\s*(?:and\s*navigate\s*to)?/gi, '')
      .replace(/^(?:navigate\s*to|directions\s*to|rasta\s*dikhao|ka\s*rasta\s*dikhao)\s*/gi, '')
      .replace(/\s*(?:ka\s*rasta\s*dikhao|rasta\s*batao|directions|navigation|maps?|ले\s*चलो|दिखाओ)\s*$/gi, '')
      .trim();

    if (/^(?:maps?|google\s*maps?|app)?$/i.test(destination)) destination = '';

    return {
      type: 'OPEN_MAPS',
      rawQuery: query,
      payload: { query: destination },
      requiresAndroidNative: false,
      androidIntent: destination
        ? `Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${encodeURIComponent(destination)}"), package="com.google.android.apps.maps")`
        : 'Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0"), package="com.google.android.apps.maps")',
      androidPermission: 'android.permission.ACCESS_FINE_LOCATION',
      webFallbackSupported: true,
      suggestedResponse: {
        en: destination
          ? `Navigation course set to "${destination}", Sir. Direct link prepared below.`
          : 'Google Maps navigation ready, Sir. Direct link prepared below.',
        hi: destination
          ? `"${destination}" के लिए नेविगेशन तैयार है, सर। नीचे दिए गए लिंक पर टैप करें।`
          : 'गूगल मैप्स नेविगेशन तैयार है, सर।',
        hinglish: destination
          ? `Sir, "${destination}" ke liye Google Maps navigation route ready hai.`
          : 'Sir, Google Maps navigation ready hai.',
      },
    };
  }

  // 9. Open Installed App Intent
  if (
    lower.startsWith('open app') ||
    lower.startsWith('launch app') ||
    (lower.startsWith('open ') && (lower.endsWith(' app') || lower.includes('calculator') || lower.includes('camera') || lower.includes('spotify') || lower.includes('instagram'))) ||
    lower.includes('app kholo') ||
    lower.includes('ऐप खोलो')
  ) {
    const targetApp = query
      .replace(/^(?:jarvis|hey\s*jarvis|please|zara|kripya)[,\s]*/gi, '')
      .replace(/^(?:open\s*app|launch\s*app|open|launch)\s*/gi, '')
      .replace(/\s*(?:app|ऐप|kholo|chalao|khol\s*do)\s*$/gi, '')
      .trim();

    return {
      type: 'OPEN_APP',
      rawQuery: query,
      payload: { query: targetApp },
      requiresAndroidNative: true,
      nativeReason: 'Launching third-party installed packages requires Android PackageManager intent on native device.',
      androidIntent: `packageManager.getLaunchIntentForPackage("${targetApp}")`,
      androidPermission: '<queries><intent><action android:name="android.intent.action.MAIN"/></intent></queries>',
      webFallbackSupported: false,
      suggestedResponse: {
        en: `Initiating launch intent for "${targetApp}", Sir. (Requires native APK).`,
        hi: `"${targetApp}" ऐप खोलने का अनुरोध तैयार है, सर। (एंड्रॉइड एपीके आवश्यक)।`,
        hinglish: `Sir, "${targetApp}" app open karne ke liye native intent dispatched.`,
      },
    };
  }

  // 10. System Status Intent
  if (
    lower.includes('status') ||
    lower.includes('who are you') ||
    lower.includes('tum kaun ho') ||
    lower.includes('kaise ho') ||
    lower.includes('diagnostics') ||
    lower.includes('हाल चाल') ||
    lower.includes('हालचाल') ||
    lower.includes('तुम कौन हो') ||
    lower.includes('कैसे हो')
  ) {
    return {
      type: 'SYSTEM_STATUS',
      rawQuery: query,
      requiresAndroidNative: false,
      androidIntent: 'Device Telemetry Receiver',
      webFallbackSupported: true,
      suggestedResponse: {
        en: 'All JARVIS systems are functioning at 100% capacity. Ready for your command, Sir.',
        hi: 'सभी जार्विस प्रणालियाँ सामान्य रूप से कार्यरत हैं। आपके आदेश की प्रतीक्षा है, सर।',
        hinglish: 'All JARVIS subsystems optimal hain Sir. Main bilkul ready hoon, aap aadesh karein.',
      },
    };
  }

  // Default: General Chat
  return {
    type: 'GENERAL_CHAT',
    rawQuery: query,
    requiresAndroidNative: false,
    webFallbackSupported: true,
    suggestedResponse: {
      en: `Understood, Sir. I am at your service. For deep real-time web intelligence, configure your Gemini API key via the 🔑 API Key button.`,
      hi: `जी सर, मैं आपके आदेश पर उपस्थित हूँ। उन्नत ऑनलाइन जानकारी के लिए 🔑 API Key बटन से जेमिनी की सक्रिय करें।`,
      hinglish: `Ji Sir, main ready hoon. Deep online neural search ke liye top bar me 🔑 API Key check karein.`,
    },
  };
}

/**
 * Checks whether an incoming prompt is a direct local command
 * (e.g. YouTube launch, WhatsApp prep, maps, torch toggle, time/date query, device settings)
 * that should be executed and answered INSTANTLY without calling Gemini AI.
 */
export function isInstantLocalCommand(query: string, lang: AssistantLanguage = 'en'): {
  isInstant: boolean;
  intent: CommandIntent;
  reply: string;
} {
  const intent = parseJarvisIntent(query, lang);
  const isInstant =
    intent.type === 'OPEN_YOUTUBE' ||
    intent.type === 'TORCH_CONTROL' ||
    intent.type === 'TIME_QUERY' ||
    intent.type === 'DATE_QUERY' ||
    intent.type === 'OPEN_SETTINGS' ||
    intent.type === 'SYSTEM_STATUS' ||
    intent.type === 'SEND_WHATSAPP' ||
    intent.type === 'CALL_PHONE' ||
    intent.type === 'OPEN_MAPS' ||
    intent.type === 'OPEN_APP' ||
    intent.type === 'STOP_LISTENING' ||
    intent.type === 'WAKE_WORD_TRIGGER' ||
    intent.type === 'STANDBY_MODE';

  return {
    isInstant,
    intent,
    reply: intent.suggestedResponse[lang],
  };
}

/**
 * Format language greeting and introductory messages
 */
export function getJarvisGreeting(lang: AssistantLanguage): string {
  switch (lang) {
    case 'hi':
      return 'नमस्ते सर। जार्विस सक्रिय है। आदेश दें?';
    case 'hinglish':
      return 'Namaste Sir! JARVIS online hai. Boliye kya help karun?';
    case 'en':
    default:
      return 'Good day, Sir. JARVIS standing by.';
  }
}

/**
 * Local offline Stark JARVIS response generator that NEVER stays silent,
 * providing instant smart fallback answers (< 50ms) for any question.
 */
export function generateOfflineJarvisResponse(query: string, lang: AssistantLanguage, errorContext?: string): string {
  const q = query.trim().toLowerCase();

  // 1. Math calculation offline support (e.g. 25 + 15, 10 * 5)
  const mathMatch = q.match(/(\d+(?:\.\d+)?)\s*([\+\-\*\/xX])\s*(\d+(?:\.\d+)?)/);
  if (mathMatch) {
    const a = parseFloat(mathMatch[1]);
    const op = mathMatch[2];
    const b = parseFloat(mathMatch[3]);
    let res = 0;
    if (op === '+') res = a + b;
    else if (op === '-') res = a - b;
    else if (op === '*' || op.toLowerCase() === 'x') res = a * b;
    else if (op === '/' && b !== 0) res = a / b;

    if (lang === 'hi') return `गणना परिणाम: ${a} ${op} ${b} = ${res}, सर।`;
    if (lang === 'hinglish') return `Calculation complete Sir: ${a} ${op} ${b} ka answer ${res} hai.`;
    return `Calculation complete, Sir: ${a} ${op} ${b} equals ${res}.`;
  }

  // 2. Greeting / Well-being
  if (q.includes('hello') || q.includes('hi') || q.includes('namaste') || q.includes('kaise ho') || q.includes('kya haal')) {
    if (lang === 'hi') return 'नमस्ते सर! मैं पूरी तरह से तैयार और सक्रिय हूँ। आप क्या करवाना चाहते हैं?';
    if (lang === 'hinglish') return 'Hello Sir! Main bilkul active hoon aur sabhi systems optimal hain. Boliye kya hukum hai?';
    return 'Greetings, Sir. All systems operating at peak efficiency. How may I assist you today?';
  }

  // 3. Capabilities / What can you do
  if (q.includes('kya kar sakte') || q.includes('what can you do') || q.includes('help') || q.includes('features')) {
    if (lang === 'hi') return 'सर, मैं यूट्यूब, वॉट्सऐप मैसेज, फोन कॉल, टॉर्च, अलार्म, ऐप लॉन्च, कोडिंग और ट्रेडिंग गणनाएँ नियंत्रित कर सकता हूँ।';
    if (lang === 'hinglish') return 'Sir, main YouTube, WhatsApp, direct phone calls, torch, alarms, coding solutions aur trading calculations sab handle kar sakta hoon.';
    return 'Sir, I control phone apps, WhatsApp messages, direct calls, flashlight, silent alarms, coding solutions, and trading risk calculations.';
  }

  // 4. Intent detection if query matched a specific command
  const instant = isInstantLocalCommand(query, lang);
  if (instant.isInstant) {
    return instant.reply;
  }

  // 5. General intelligent response with error context if available
  if (errorContext) {
    if (lang === 'hi') {
      return `सर, नेटवर्क सूचना: ${errorContext}। मैंने आपका अनुरोध नोट कर लिया है: "${query}"।`;
    }
    if (lang === 'hinglish') {
      return `Sir, connection update: ${errorContext}। Aapka command note kar liya hai: "${query}"।`;
    }
    return `Sir, communication note: ${errorContext}. Your instruction has been received: "${query}".`;
  }

  // Default clean smart response (NO FILLER SPEECH!)
  if (lang === 'hi') {
    return `जी सर, मैंने आपका अनुरोध प्राप्त कर लिया है: "${query}"। आदेश पर अमल किया जा रहा है।`;
  }
  if (lang === 'hinglish') {
    return `Ji Sir, aapka command receive ho gaya: "${query}"। Ready for next instruction.`;
  }
  return `Acknowledged, Sir. Query received: "${query}". Ready for your next command.`;
}
