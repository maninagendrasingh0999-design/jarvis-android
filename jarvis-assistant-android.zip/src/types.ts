/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AssistantLanguage, AssistantState, CommandIntent, CommandIntentType } from './utils/jarvis-core';

export interface StructuredAction {
  type:
    | 'OPEN_APP'
    | 'YOUTUBE_SEARCH_PLAY'
    | 'OPEN_YOUTUBE'
    | 'WHATSAPP_SEND'
    | 'MAKE_CALL'
    | 'SET_ALARM'
    | 'SET_TIMER'
    | 'TOGGLE_TORCH'
    | 'SYSTEM_SETTING'
    | 'GOOGLE_SEARCH'
    | 'OPEN_URL'
    | 'GLOBAL_ACTION'
    | string;
  params?: {
    appName?: string;
    packageName?: string;
    query?: string;
    recipientName?: string;
    phoneNumber?: string;
    messageText?: string;
    message?: string;
    hour?: number;
    minutes?: number;
    minutesFromNow?: number;
    seconds?: number;
    skipUi?: boolean;
    state?: 'on' | 'off' | 'toggle';
    setting?: 'wifi' | 'bluetooth' | 'hotspot' | 'location' | 'volume' | 'display' | 'all';
    level?: number;
    delta?: number;
    action?: 'BACK' | 'HOME' | 'RECENTS' | 'NOTIFICATIONS' | 'LOCK_SCREEN';
    url?: string;
    [key: string]: any;
  };
}

export interface CodeSolution {
  title: string;
  language: string;
  code: string;
  explanation: string;
}

export interface MemoryItem {
  id: string;
  key: string;
  value: string;
  createdAt: number;
}

export interface ActionExecutionResult {
  type: string;
  actionName: string;
  url?: string;
  androidIntent?: string;
  androidPermissions?: string[];
  status: 'executed' | 'ready_to_launch' | 'blocked_popup' | 'native_required' | 'web_simulation' | 'failed';
  feedbackText: string;
  timestamp: number;
  payload?: any;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'jarvis';
  text: string;
  timestamp: string;
  language: AssistantLanguage;
  intent?: CommandIntent;
  actionResult?: ActionExecutionResult;
  action?: StructuredAction;
  codeSolution?: CodeSolution;
  provider?: string;
  isAudioPlaying?: boolean;
}

export interface ReminderItem {
  id: string;
  text: string;
  dueTime: number; // Unix timestamp
  minutes: number;
  completed: boolean;
  createdAt: number;
}

export interface SystemStatusData {
  status: string;
  appName: string;
  version: string;
  geminiConfigured: boolean;
  elevenLabsConfigured: boolean;
  activeModel: string;
  serverTime: string;
  supportedLanguages: AssistantLanguage[];
  voiceEngines: Array<{ id: string; name: string; ready: boolean }>;
  configInstructions?: {
    gemini: { envVar: string; configured: boolean; location: string };
    elevenLabs: { envVar: string; configured: boolean; location: string };
  };
}

export interface VoiceSettings {
  engine: 'browser' | 'elevenlabs' | 'gemini_tts';
  elevenLabsVoiceId: string; // e.g. '21m00Tcm4TlvDq8ikWAM' (Rachel)
  preferredBrowserVoiceName: string;
  speechRate: number;
  pitch: number;
  autoSpeak: boolean;
  soundEffects: boolean;
  continuousConversation?: boolean;
  voiceEnrollmentEnabled?: boolean;
  voiceEnrollmentName?: string;
}

export interface CyberAuthProfile {
  phoneNumber: string;
  pin: string; // 4-digit PIN
  apiKey: string;
  isConfigured: boolean;
  rememberDevice: boolean;
}

export interface TradeMasterData {
  symbol: string;
  market: 'crypto' | 'stocks';
  tradeType: 'long' | 'short';
  entryPrice: number;
  stopLossPrice: number;
  targetPrice: number;
  capital: number;
  riskPercent: number;
  calculated: {
    riskRewardRatio: number;
    riskAmount: number;
    profitAmount: number;
    positionSizeQty: number;
    totalPositionValue: number;
  };
  aiHinglishStrategy?: string;
}

export interface NativeBridgeInterface {
  executeAction: (actionJson: string) => boolean;
  saveMemory: (key: string, value: string) => void;
  getMemory: (key: string) => string | null;
  getAllMemories: () => string;
  saveApiKey: (key: string) => void;
  getApiKey: () => string | null;
  triggerMacroDroid: (command: string, target: string, message: string) => void;
  performGlobalAction: (action: string) => boolean;
  sendWhatsApp: (contactName: string, messageText: string) => void;
  makeCall: (phoneNumberOrName: string) => void;
  setTorchMode: (enabled: boolean) => void;
  openYouTube: (query: string) => void;
  openMaps: (destination: string) => void;
  openApp: (appNameOrPackage: string) => void;
  setAlarm: (message: string, minutesFromNow: number) => void;
  startVoiceService: () => void;
  stopVoiceService: () => void;
  speakText: (text: string, lang: string) => void;
  isNativeAndroid: () => boolean;
  toggleFloatingOrb: (enable: boolean) => boolean;
  hasOverlayPermission: () => boolean;
  requestOverlayPermission: () => void;
  isFloatingOrbRunning: () => boolean;
}

declare global {
  interface Window {
    AndroidBridge?: NativeBridgeInterface;
    JarvisNative?: NativeBridgeInterface;
    JarvisAndroid?: NativeBridgeInterface;
    triggerJarvisListening?: () => void;
  }
}

