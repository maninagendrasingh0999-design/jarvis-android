/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Terminal, Copy, Check, X, Code2, Wrench, Sparkles, Send, Volume2 } from 'lucide-react';
import { CodeSolution } from '../types';

interface CodingMasterModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSolution: CodeSolution | null;
  onRequestCode: (prompt: string) => void;
  onSpeakExplanation: (text: string) => void;
  isLoading?: boolean;
}

export const CodingMasterModal: React.FC<CodingMasterModalProps> = ({
  isOpen,
  onClose,
  activeSolution,
  onRequestCode,
  onSpeakExplanation,
  isLoading = false,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [promptInput, setPromptInput] = useState<string>('');

  if (!isOpen) return null;

  const handleCopy = () => {
    if (!activeSolution?.code) return;
    navigator.clipboard.writeText(activeSolution.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptInput.trim() || isLoading) return;
    onRequestCode(promptInput.trim());
    setPromptInput('');
  };

  const quickPrompts = [
    'Create Android Floating Window Service in Kotlin',
    'Fix Windows 100% Disk Usage & High RAM bug',
    'Write a Python script to scan local WiFi network',
    'Create a Flutter WhatsApp direct chat sender',
    'PowerShell command to clear temporary system junk',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-3xl border border-cyan-500/40 bg-slate-950/98 shadow-2xl shadow-cyan-500/25 text-cyan-100 overflow-hidden">
        {/* Terminal Title Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/30 bg-slate-900/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
            </div>
            <div className="flex items-center gap-2 text-cyan-300 font-mono text-sm font-bold">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>JARVIS CODING MASTER & PC TROUBLESHOOTER</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {activeSolution && (
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                {activeSolution.language || 'CODE'}
              </span>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/50 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick Coding Action Chips */}
        <div className="px-4 py-2 bg-slate-900/40 border-b border-cyan-500/20 overflow-x-auto flex gap-1.5 text-nowrap scrollbar-none shrink-0">
          {quickPrompts.map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => onRequestCode(q)}
              className="px-2.5 py-1 rounded-full bg-slate-900 border border-cyan-500/30 text-[10px] font-mono text-cyan-300 hover:bg-cyan-950 hover:border-cyan-400 transition-colors shrink-0 cursor-pointer"
            >
              ⚡ {q}
            </button>
          ))}
        </div>

        {/* Solution Viewport or Empty State */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono">
          {activeSolution ? (
            <div className="space-y-3">
              <div className="p-3 rounded-2xl bg-slate-900/70 border border-cyan-500/25 flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 text-cyan-200 font-bold text-sm mb-1 font-sans">
                    <Wrench className="w-4 h-4 text-cyan-400 shrink-0" />
                    <h4>{activeSolution.title}</h4>
                  </div>
                  {activeSolution.explanation && (
                    <p className="text-xs text-slate-300 font-sans leading-relaxed">
                      {activeSolution.explanation}
                    </p>
                  )}
                </div>

                {activeSolution.explanation && (
                  <button
                    onClick={() => onSpeakExplanation(activeSolution.explanation)}
                    className="p-2 rounded-xl bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 hover:bg-cyan-900 transition-colors shrink-0"
                    title="Vocalize solution in Hinglish"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Code Box with Copy Header */}
              <div className="relative rounded-2xl border border-cyan-500/40 bg-black/95 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-2 border-b border-cyan-500/20 bg-slate-950/80 text-[11px] text-slate-400">
                  <span>Target: {activeSolution.language.toUpperCase()} Implementation</span>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-cyan-950 border border-cyan-500/50 hover:bg-cyan-900 text-cyan-300 font-mono text-xs font-semibold shadow-md transition-all cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                </div>

                <pre className="p-4 overflow-x-auto text-xs text-cyan-300 leading-relaxed max-h-[380px] font-mono select-text selection:bg-cyan-500/30 selection:text-white">
                  <code>{activeSolution.code}</code>
                </pre>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center text-slate-400 space-y-2">
              <Code2 className="w-10 h-10 text-cyan-500/40 animate-pulse" />
              <h4 className="font-bold text-cyan-300 font-sans text-sm">
                JARVIS Coding Master Standing By
              </h4>
              <p className="text-xs text-slate-400 max-w-md font-sans">
                Ask JARVIS to write code for any app (Kotlin, Python, Flutter, React) or diagnose
                computer issues (Windows blue-screen, 100% disk usage, Linux kernel logs).
              </p>
            </div>
          )}
        </div>

        {/* Input Bar to Ask Coding or PC Questions */}
        <form onSubmit={handleSubmit} className="p-3 border-t border-cyan-500/30 bg-slate-900/90 flex gap-2 shrink-0">
          <input
            type="text"
            placeholder="Ask JARVIS to code an app or fix a PC problem (e.g. 'Write Python keylogger detection')..."
            value={promptInput}
            onChange={(e) => setPromptInput(e.target.value)}
            disabled={isLoading}
            className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-xs placeholder-slate-600 focus:outline-none focus:border-cyan-400 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={isLoading || !promptInput.trim()}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-mono text-xs font-bold uppercase tracking-wider shadow-lg shadow-cyan-600/30 flex items-center gap-1.5 transition-all disabled:opacity-50 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Generate</span>
          </button>
        </form>
      </div>
    </div>
  );
};
