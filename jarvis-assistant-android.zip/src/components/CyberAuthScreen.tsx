/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Shield, Lock, Unlock, Phone, Key, ChevronRight, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';
import { CyberAuthProfile } from '../types';
import { getNativeBridge } from '../utils/action-executor';

interface CyberAuthScreenProps {
  authProfile: CyberAuthProfile;
  onAuthenticateSuccess: (profile: CyberAuthProfile) => void;
  onResetAuth: () => void;
}

export const CyberAuthScreen: React.FC<CyberAuthScreenProps> = ({
  authProfile,
  onAuthenticateSuccess,
  onResetAuth,
}) => {
  const isFirstLaunch = !authProfile.isConfigured;

  // Setup state
  const [phoneNumber, setPhoneNumber] = useState(authProfile.phoneNumber || '');
  const [setupPin, setSetupPin] = useState(authProfile.pin || '');
  const [confirmPin, setConfirmPin] = useState('');
  const [geminiApiKey, setGeminiApiKey] = useState(authProfile.apiKey || 'AIzaSyDNKMF5hhri9fvpU7DSgHyFKB7rdkxKaTI');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Unlock state
  const [enteredPin, setEnteredPin] = useState<string>('');
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);

  const handleKeypadPress = (digit: string) => {
    if (enteredPin.length < 4) {
      const newPin = enteredPin + digit;
      setEnteredPin(newPin);
      setErrorMsg(null);

      // Auto verify when 4th digit entered
      if (newPin.length === 4) {
        if (newPin === authProfile.pin) {
          setIsUnlocked(true);
          setTimeout(() => {
            onAuthenticateSuccess(authProfile);
          }, 450);
        } else {
          setErrorMsg('Access Denied: Invalid Security PIN.');
          setTimeout(() => setEnteredPin(''), 600);
        }
      }
    }
  };

  const handleKeypadBackspace = () => {
    setEnteredPin((prev) => prev.slice(0, -1));
    setErrorMsg(null);
  };

  const handleCompleteSetup = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanPhone = phoneNumber.trim().replace(/\s+/g, '');
    if (!cleanPhone || cleanPhone.length < 10) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }
    if (setupPin.length !== 4 || !/^\d{4}$/.test(setupPin)) {
      setErrorMsg('Security PIN must be exactly 4 numeric digits.');
      return;
    }
    if (setupPin !== confirmPin) {
      setErrorMsg('PIN confirmation does not match.');
      return;
    }

    const updatedProfile: CyberAuthProfile = {
      phoneNumber: cleanPhone,
      pin: setupPin,
      apiKey: geminiApiKey.trim(),
      isConfigured: true,
      rememberDevice: true,
    };

    // Save to storage and native bridge
    try {
      localStorage.setItem('jarvis_cyber_auth', JSON.stringify(updatedProfile));
      if (geminiApiKey.trim()) {
        localStorage.setItem('jarvis_gemini_api_key', geminiApiKey.trim());
      }
    } catch (e) {}

    const bridge = getNativeBridge();
    if (bridge && typeof bridge.saveApiKey === 'function' && geminiApiKey.trim()) {
      try {
        bridge.saveApiKey(geminiApiKey.trim());
      } catch (e) {}
    }

    setIsUnlocked(true);
    setTimeout(() => {
      onAuthenticateSuccess(updatedProfile);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950 text-cyan-100 select-none overflow-y-auto">
      {/* Background Holographic Grid Accent */}
      <div className="absolute inset-0 bg-[radial-gradient(#00e5ff_1px,transparent_1px)] [background-size:24px_24px] opacity-15 pointer-events-none" />

      <div className="relative w-full max-w-sm rounded-3xl border border-cyan-500/40 bg-slate-900/95 p-6 shadow-2xl shadow-cyan-500/20 backdrop-blur-xl">
        {/* Arc-Reactor Header Badge */}
        <div className="flex flex-col items-center text-center mb-5">
          <div className="relative flex items-center justify-center mb-3">
            <div className={`w-14 h-14 rounded-2xl border flex items-center justify-center shadow-lg transition-all duration-300 ${
              isUnlocked
                ? 'bg-emerald-950/80 border-emerald-400 text-emerald-400 shadow-emerald-500/30'
                : 'bg-cyan-950/80 border-cyan-400 text-cyan-300 shadow-cyan-500/30'
            }`}>
              {isUnlocked ? (
                <Unlock className="w-7 h-7 animate-bounce" />
              ) : (
                <Shield className="w-7 h-7 animate-pulse text-cyan-400" />
              )}
            </div>
            <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
          </div>

          <h2 className="text-xl font-bold tracking-wider text-cyan-300 font-mono uppercase">
            {isFirstLaunch ? 'Cyber Setup Shield' : 'Terminal Security'}
          </h2>
          <p className="text-xs text-slate-400 font-mono mt-0.5">
            {isFirstLaunch
              ? 'Configure Phone & Security PIN'
              : `Operator: ${authProfile.phoneNumber.slice(0, 3)}•••••${authProfile.phoneNumber.slice(-2)}`}
          </p>
        </div>

        {errorMsg && (
          <div className="mb-4 p-2.5 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-300 text-xs font-mono flex items-center gap-2 animate-in fade-in zoom-in-95">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* MODE 1: FIRST-LAUNCH SETUP FORM */}
        {isFirstLaunch ? (
          <form onSubmit={handleCompleteSetup} className="space-y-3.5">
            <div>
              <label className="block text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1">
                Operator Phone Number
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-cyan-500" />
                <input
                  type="tel"
                  placeholder="+91 9876543210"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-xs placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1">
                  4-Digit PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  placeholder="••••"
                  value={setupPin}
                  onChange={(e) => setSetupPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-center tracking-widest text-sm placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1">
                  Confirm PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  placeholder="••••"
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-center tracking-widest text-sm placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono text-cyan-400 uppercase tracking-wider mb-1 flex items-center justify-between">
                <span>Gemini API Key</span>
                <span className="text-[9px] text-slate-500">(Optional / Cloud default)</span>
              </label>
              <div className="relative">
                <Key className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-cyan-500" />
                <input
                  type="password"
                  placeholder="AIzaSy..."
                  value={geminiApiKey}
                  onChange={(e) => setGeminiApiKey(e.target.value)}
                  className="w-full pl-9 pr-3.5 py-2 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-100 font-mono text-xs placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-mono text-xs font-bold uppercase tracking-wider shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>Initialize Terminal</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          /* MODE 2: SUBSEQUENT PIN UNLOCK KEYPAD */
          <div className="flex flex-col items-center">
            {/* 4 Pin Indicator Dots */}
            <div className="flex items-center gap-4 my-3">
              {[0, 1, 2, 3].map((idx) => {
                const isFilled = enteredPin.length > idx;
                return (
                  <div
                    key={idx}
                    className={`w-4 h-4 rounded-full border-2 transition-all duration-200 ${
                      isFilled
                        ? 'bg-cyan-400 border-cyan-300 shadow-[0_0_12px_#00e5ff] scale-110'
                        : 'border-cyan-500/40 bg-slate-950'
                    }`}
                  />
                );
              })}
            </div>

            {/* Tactical 3x4 Touch Keypad */}
            <div className="grid grid-cols-3 gap-2.5 w-full mt-3">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  type="button"
                  onClick={() => handleKeypadPress(digit)}
                  className="h-12 rounded-xl border border-cyan-500/30 bg-slate-950 hover:bg-cyan-950/60 active:scale-95 text-cyan-200 font-mono text-lg font-bold flex items-center justify-center shadow-sm transition-all cursor-pointer"
                >
                  {digit}
                </button>
              ))}
              <button
                type="button"
                onClick={onResetAuth}
                className="h-12 rounded-xl border border-cyan-500/20 bg-slate-950 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 font-mono text-[10px] uppercase font-semibold flex items-center justify-center transition-all cursor-pointer"
                title="Switch Account / Reset"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={() => handleKeypadPress('0')}
                className="h-12 rounded-xl border border-cyan-500/30 bg-slate-950 hover:bg-cyan-950/60 active:scale-95 text-cyan-200 font-mono text-lg font-bold flex items-center justify-center shadow-sm transition-all cursor-pointer"
              >
                0
              </button>
              <button
                type="button"
                onClick={handleKeypadBackspace}
                className="h-12 rounded-xl border border-cyan-500/30 bg-slate-950 hover:bg-cyan-950/60 active:scale-95 text-cyan-300 font-mono text-xs font-semibold flex items-center justify-center transition-all cursor-pointer"
              >
                DEL
              </button>
            </div>

            {/* Emergency Reset Text Link */}
            <button
              onClick={onResetAuth}
              className="mt-4 text-[10px] font-mono text-slate-500 hover:text-cyan-300 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Change Phone or Security PIN</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
