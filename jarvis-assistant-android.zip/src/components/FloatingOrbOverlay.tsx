/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Mic, X, Radio, Sparkles } from 'lucide-react';

interface FloatingOrbOverlayProps {
  isVisible: boolean;
  onClose: () => void;
  onTriggerListening: () => void;
  isListening: boolean;
}

export const FloatingOrbOverlay: React.FC<FloatingOrbOverlayProps> = ({
  isVisible,
  onClose,
  onTriggerListening,
  isListening,
}) => {
  // Screen coordinate positioning
  const [position, setPosition] = useState<{ x: number; y: number }>(() => {
    if (typeof window !== 'undefined') {
      return { x: window.innerWidth - 80, y: window.innerHeight * 0.35 };
    }
    return { x: 300, y: 220 };
  });

  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; initialX: number; initialY: number }>({
    startX: 0,
    startY: 0,
    initialX: 0,
    initialY: 0,
  });
  const hasMovedRef = useRef<boolean>(false);

  useEffect(() => {
    const handleResize = () => {
      setPosition((prev) => ({
        x: Math.min(prev.x, window.innerWidth - 75),
        y: Math.min(prev.y, window.innerHeight - 75),
      }));
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!isVisible) return null;

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    hasMovedRef.current = false;
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: position.x,
      initialY: position.y,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.startX;
    const dy = e.clientY - dragStartRef.current.startY;

    if (Math.abs(dx) > 6 || Math.abs(dy) > 6) {
      hasMovedRef.current = true;
    }

    const newX = Math.max(10, Math.min(window.innerWidth - 75, dragStartRef.current.initialX + dx));
    const newY = Math.max(50, Math.min(window.innerHeight - 75, dragStartRef.current.initialY + dy));
    setPosition({ x: newX, y: newY });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {}

    // Tap detection: if barely moved, trigger voice recognition!
    if (!hasMovedRef.current) {
      onTriggerListening();
    }
  };

  return (
    <div
      style={{
        left: `${position.x}px`,
        top: `${position.y}px`,
        touchAction: 'none',
      }}
      className="fixed z-50 select-none group cursor-grab active:cursor-grabbing transition-transform duration-75"
    >
      {/* Floating Arc-Reactor Orb */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="relative w-16 h-16 rounded-full flex items-center justify-center p-1 bg-slate-950/90 border-2 border-cyan-400 shadow-[0_0_25px_rgba(0,229,255,0.6)] backdrop-blur-md active:scale-95 transition-all"
        title="Tap to activate JARVIS Voice Recognition (Drag to reposition)"
      >
        {/* Animated Radial Pulse Ripples when Listening */}
        {isListening && (
          <>
            <span className="absolute inset-0 rounded-full border-2 border-cyan-400 animate-ping opacity-75" />
            <span className="absolute -inset-2 rounded-full border border-emerald-400 animate-pulse opacity-60" />
          </>
        )}

        {/* Outer Rotating Cyan Ring */}
        <div className="absolute inset-1 rounded-full border border-dashed border-cyan-300 animate-spin-slow opacity-80 pointer-events-none" />

        {/* Inner Reactor Glow Core */}
        <div
          className={`w-9 h-9 rounded-full flex items-center justify-center transition-all ${
            isListening
              ? 'bg-gradient-to-tr from-cyan-400 to-emerald-400 text-black shadow-[0_0_15px_#00e5ff]'
              : 'bg-gradient-to-tr from-cyan-600 to-blue-600 text-white shadow-[0_0_10px_rgba(0,229,255,0.4)]'
          }`}
        >
          {isListening ? (
            <Radio className="w-5 h-5 animate-pulse" />
          ) : (
            <Mic className="w-5 h-5" />
          )}
        </div>

        {/* Tiny Active Telemetry Indicator */}
        <div className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-black flex items-center justify-center">
          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
        </div>
      </div>

      {/* Floating Close Pill on Hover/Mobile */}
      <button
        onClick={(e) => {
          e.stopPropagation();
          onClose();
        }}
        className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-slate-900 border border-cyan-500/50 text-slate-400 hover:text-rose-400 flex items-center justify-center shadow-md transition-colors"
        title="Hide Floating Widget"
      >
        <X className="w-3 h-3" />
      </button>
    </div>
  );
};
