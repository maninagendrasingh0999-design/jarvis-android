/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { AssistantState } from '../utils/jarvis-core';

interface VoiceOrbProps {
  state: AssistantState;
  onClick?: () => void;
  isListening?: boolean;
}

export const VoiceOrb: React.FC<VoiceOrbProps> = ({ state, onClick, isListening }) => {
  // Generate concentric tick marks for futuristic HUD ring
  const ticks = useMemo(() => {
    return Array.from({ length: 36 }).map((_, i) => {
      const angle = i * 10;
      const isMajor = i % 9 === 0;
      return { angle, isMajor };
    });
  }, []);

  // Determine state display text and status color
  const stateInfo = useMemo(() => {
    switch (state) {
      case 'listening':
        return {
          title: 'AUDIO RECEPTOR ACTIVE',
          subtitle: 'Awaiting Voice Input',
          glowClass: 'shadow-[0_0_50px_rgba(0,229,255,0.8),inset_0_0_30px_rgba(0,229,255,0.4)]',
          coreBg: 'radial-gradient(circle, rgba(0,229,255,0.9) 0%, rgba(0,102,255,0.7) 50%, rgba(2,6,23,0.9) 100%)',
          textColor: 'text-cyan-400',
          speed: 'animate-spin-slow',
          pulseSpeed: 'animate-ping',
        };
      case 'thinking':
        return {
          title: 'NEURAL PROCESSING',
          subtitle: 'Synthesizing Response...',
          glowClass: 'shadow-[0_0_60px_rgba(96,165,250,0.8),inset_0_0_35px_rgba(59,130,246,0.5)]',
          coreBg: 'radial-gradient(circle, rgba(96,165,250,0.95) 0%, rgba(37,99,235,0.7) 45%, rgba(2,6,23,0.95) 100%)',
          textColor: 'text-blue-400',
          speed: 'animate-spin',
          pulseSpeed: 'animate-pulse',
        };
      case 'speaking':
        return {
          title: 'VOCAL SYNTHESIZER ACTIVE',
          subtitle: 'Transmitting Audio Response',
          glowClass: 'shadow-[0_0_55px_rgba(0,255,200,0.8),inset_0_0_30px_rgba(0,255,200,0.35)]',
          coreBg: 'radial-gradient(circle, rgba(0,255,200,0.9) 0%, rgba(0,180,255,0.65) 55%, rgba(2,6,23,0.9) 100%)',
          textColor: 'text-emerald-400',
          speed: 'animate-pulse',
          pulseSpeed: 'animate-bounce',
        };
      case 'error':
        return {
          title: 'PROTOCOL EXCEPTION',
          subtitle: 'Diagnostic Alert',
          glowClass: 'shadow-[0_0_50px_rgba(244,63,94,0.8),inset_0_0_30px_rgba(244,63,94,0.4)]',
          coreBg: 'radial-gradient(circle, rgba(244,63,94,0.9) 0%, rgba(159,18,57,0.7) 50%, rgba(2,6,23,0.9) 100%)',
          textColor: 'text-rose-400',
          speed: 'animate-pulse',
          pulseSpeed: 'animate-ping',
        };
      case 'idle':
      default:
        return {
          title: 'JARVIS SYSTEM ONLINE',
          subtitle: 'Standby & Monitoring',
          glowClass: 'shadow-[0_0_35px_rgba(0,229,255,0.4),inset_0_0_20px_rgba(0,229,255,0.2)]',
          coreBg: 'radial-gradient(circle, rgba(0,229,255,0.6) 0%, rgba(0,102,255,0.4) 60%, rgba(3,7,18,0.9) 100%)',
          textColor: 'text-cyan-500',
          speed: '',
          pulseSpeed: '',
        };
    }
  }, [state]);

  return (
    <div className="flex flex-col items-center justify-center relative select-none my-4">
      {/* Outer Holographic Arc Reactor Visualizer */}
      <div
        onClick={onClick}
        role="button"
        tabIndex={0}
        aria-label={`JARVIS Voice Orb - Current state: ${state}. Click to trigger microphone input.`}
        className="relative w-44 h-44 sm:w-52 sm:h-52 flex items-center justify-center cursor-pointer group"
      >
        {/* Subtle Ambient Shockwave Ripples when Listening or Speaking */}
        {(state === 'listening' || state === 'speaking') && (
          <>
            <div className="absolute inset-0 rounded-full border border-cyan-400/40 animate-ping opacity-75 pointer-events-none" />
            <div className="absolute -inset-3 rounded-full border border-cyan-500/20 animate-pulse pointer-events-none" />
          </>
        )}

        {/* Outer Rotating HUD Calibrated Ring */}
        <div
          className={`absolute inset-0 rounded-full border border-cyan-500/30 transition-transform duration-1000 ${
            state === 'thinking' ? 'animate-[spin_4s_linear_infinite]' : 'animate-[spin_24s_linear_infinite]'
          }`}
        >
          {ticks.map((tick, i) => (
            <div
              key={i}
              className={`absolute top-0 left-1/2 -translate-x-1/2 origin-[50%_88px] sm:origin-[50%_104px] ${
                tick.isMajor ? 'h-2 w-0.5 bg-cyan-400/80' : 'h-1.5 w-[1px] bg-cyan-500/40'
              }`}
              style={{ transform: `rotate(${tick.angle}deg)` }}
            />
          ))}
        </div>

        {/* Secondary Reverse Counter-Rotating Dashed Segment Ring */}
        <div
          className={`absolute inset-2.5 sm:inset-3 rounded-full border-2 border-dashed border-cyan-400/25 ${
            state === 'thinking'
              ? 'animate-[spin_3s_linear_infinite_reverse]'
              : 'animate-[spin_36s_linear_infinite_reverse]'
          }`}
        />

        {/* Inner Holographic Arc Segments */}
        <svg
          viewBox="0 0 100 100"
          className={`absolute inset-5 sm:inset-6 w-[calc(100%-40px)] h-[calc(100%-40px)] sm:w-[calc(100%-48px)] sm:h-[calc(100%-48px)] transition-transform duration-700 ${
            state === 'thinking' ? 'animate-[spin_6s_linear_infinite]' : 'animate-[spin_40s_linear_infinite]'
          }`}
        >
          <circle
            cx="50"
            cy="50"
            r="44"
            fill="none"
            stroke="rgba(0, 229, 255, 0.45)"
            strokeWidth="1.5"
            strokeDasharray="20 10 35 15 5 10"
          />
          <circle
            cx="50"
            cy="50"
            r="38"
            fill="none"
            stroke="rgba(0, 102, 255, 0.5)"
            strokeWidth="1"
            strokeDasharray="12 8 30 14"
          />
        </svg>

        {/* Core Glowing Orb Sphere */}
        <div
          className={`relative w-22 h-22 sm:w-26 sm:h-26 rounded-full flex items-center justify-center transition-all duration-500 border border-cyan-300/60 ${stateInfo.glowClass} group-hover:scale-105`}
          style={{ background: stateInfo.coreBg }}
        >
          {/* Internal Arc Reactor Geometric Mesh */}
          <div className="absolute inset-1.5 rounded-full border border-cyan-200/40 flex items-center justify-center">
            {/* Center Core Light Node */}
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-cyan-100/90 shadow-[0_0_18px_#00e5ff] flex items-center justify-center">
              <div className="w-3.5 h-3.5 rounded-full bg-white shadow-[0_0_10px_#ffffff]" />
            </div>
          </div>

          {/* Dynamic Audio Visualizer Wave Bars (when listening or speaking) */}
          {(state === 'listening' || state === 'speaking') && (
            <div className="absolute inset-0 flex items-center justify-center gap-1 pointer-events-none">
              {[4, 12, 24, 38, 20, 32, 16, 6].map((height, idx) => (
                <div
                  key={idx}
                  className="w-1 bg-white/90 rounded-full animate-pulse"
                  style={{
                    height: `${height}px`,
                    animationDuration: `${0.3 + (idx % 4) * 0.15}s`,
                    animationDelay: `${idx * 0.05}s`,
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {/* Radial Holographic Cardinal Coordinate Labels */}
        <span className="absolute top-1 text-[9px] font-mono text-cyan-400/60 tracking-widest">N 00°</span>
        <span className="absolute bottom-1 text-[9px] font-mono text-cyan-400/60 tracking-widest">S 180°</span>
        <span className="absolute left-1 text-[9px] font-mono text-cyan-400/60 tracking-widest">W 270°</span>
        <span className="absolute right-1 text-[9px] font-mono text-cyan-400/60 tracking-widest">E 090°</span>
      </div>

      {/* State Telemetry Readout */}
      <div className="mt-3 text-center">
        <div className="flex items-center justify-center gap-2">
          <span className={`w-2 h-2 rounded-full ${state === 'error' ? 'bg-rose-500' : 'bg-cyan-400'} animate-ping`} />
          <h2 className="font-hud text-xs sm:text-sm font-semibold tracking-wider text-cyan-300">
            {stateInfo.title}
          </h2>
        </div>
        <p className="text-[11px] sm:text-xs font-mono text-slate-400 tracking-wide mt-0.5">
          {stateInfo.subtitle}
        </p>
      </div>
    </div>
  );
};
