/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  X,
  Volume2,
  Sliders,
  Radio,
  Cpu,
  Smartphone,
  CheckCircle2,
  AlertTriangle,
  Info,
  Sparkles,
  ShieldCheck,
  Code2,
  Play,
  RotateCw,
  ExternalLink,
  Key,
} from 'lucide-react';
import { VoiceSettings, SystemStatusData } from '../types';
import { AssistantLanguage } from '../utils/jarvis-core';
import { speakText, stopSpeaking } from '../utils/audio';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  voiceSettings: VoiceSettings;
  onUpdateVoiceSettings: (settings: Partial<VoiceSettings>) => void;
  language: AssistantLanguage;
  onSelectLanguage: (lang: AssistantLanguage) => void;
  systemStatus: SystemStatusData | null;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  voiceSettings,
  onUpdateVoiceSettings,
  language,
  onSelectLanguage,
  systemStatus,
}) => {
  const [activeTab, setActiveTab] = useState<'voice' | 'language' | 'apis' | 'android'>('voice');

  // Test Voice state
  const [testVoiceState, setTestVoiceState] = useState<{
    loading: boolean;
    playing: boolean;
    error: string | null;
    successMessage: string | null;
  }>({
    loading: false,
    playing: false,
    error: null,
    successMessage: null,
  });

  // Gemini Ping Diagnostic state
  const [geminiPingState, setGeminiPingState] = useState<{
    testing: boolean;
    tested: boolean;
    connected: boolean;
    latencyMs: number | null;
    model: string | null;
    reply: string | null;
    error: string | null;
  }>({
    testing: false,
    tested: false,
    connected: false,
    latencyMs: null,
    model: null,
    reply: null,
    error: null,
  });

  // ElevenLabs Live Handshake Diagnostic state
  const [elevenLabsValidation, setElevenLabsValidation] = useState<{
    validating: boolean;
    validated: boolean;
    connected: boolean;
    configured: boolean;
    statusMessage: string | null;
    tier?: string;
    characterCount?: number;
    characterLimit?: number;
  }>({
    validating: false,
    validated: false,
    connected: false,
    configured: false,
    statusMessage: null,
  });

  if (!isOpen) return null;

  // Real ElevenLabs API Handshake validation
  const handleValidateElevenLabs = async () => {
    setElevenLabsValidation({
      validating: true,
      validated: false,
      connected: false,
      configured: false,
      statusMessage: null,
    });

    try {
      const resp = await fetch('/api/status/validate-elevenlabs');
      const data = await resp.json();

      setElevenLabsValidation({
        validating: false,
        validated: true,
        connected: Boolean(data.connected),
        configured: Boolean(data.configured),
        statusMessage: data.statusMessage || (data.connected ? 'Handshake successful (200 OK).' : 'Handshake failed.'),
        tier: data.tier,
        characterCount: data.characterCount,
        characterLimit: data.characterLimit,
      });
    } catch (err: any) {
      setElevenLabsValidation({
        validating: false,
        validated: true,
        connected: false,
        configured: false,
        statusMessage: err.message || 'Network error performing ElevenLabs handshake',
      });
    }
  };

  // Handle Testing ElevenLabs Voice in Hindi
  const handleTestElevenLabsHindi = async () => {
    setTestVoiceState({
      loading: true,
      playing: false,
      error: null,
      successMessage: null,
    });

    try {
      const resp = await fetch('/api/tts/test-hindi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ voiceId: voiceSettings.elevenLabsVoiceId }),
      });

      const contentType = resp.headers.get('Content-Type') || '';

      if (!resp.ok || !contentType.includes('audio')) {
        const data = await resp.json().catch(() => ({}));
        setTestVoiceState({
          loading: false,
          playing: false,
          error: data.error || 'ElevenLabs API key is not configured on the server. Natural voice is unavailable.',
          successMessage: null,
        });
        return;
      }

      // Audio returned successfully from ElevenLabs
      const blob = await resp.blob();
      const audioUrl = URL.createObjectURL(blob);
      const audio = new Audio(audioUrl);

      setTestVoiceState({
        loading: false,
        playing: true,
        error: null,
        successMessage: 'Speaking ElevenLabs Hindi: "नमस्ते सर, मैं आपकी JARVIS असिस्टेंट हूँ।"',
      });

      audio.onended = () => {
        setTestVoiceState((prev) => ({ ...prev, playing: false }));
      };
      audio.onerror = () => {
        setTestVoiceState({
          loading: false,
          playing: false,
          error: 'Browser audio playback encountered an error decoding audio buffer.',
          successMessage: null,
        });
      };

      await audio.play();
    } catch (err: any) {
      setTestVoiceState({
        loading: false,
        playing: false,
        error: err.message || 'Network communication failure with ElevenLabs endpoint.',
        successMessage: null,
      });
    }
  };

  // Handle Testing Browser Speech Voice
  const handleTestBrowserVoice = (testLang: 'hi' | 'en') => {
    stopSpeaking();
    const testText = testLang === 'hi'
      ? 'नमस्ते सर, यह डिवाइस की स्वाभाविक हिंदी आवाज़ का परीक्षण है।'
      : 'Good day Sir, this is a test of your device female voice synthesis.';

    setTestVoiceState({
      loading: false,
      playing: true,
      error: null,
      successMessage: `Vocalizing via browser synthesis (${testLang.toUpperCase()}): "${testText}"`,
    });

    speakText(testText, testLang, {
      pitch: voiceSettings.pitch,
      rate: voiceSettings.speechRate,
      onEnd: () => {
        setTestVoiceState((prev) => ({ ...prev, playing: false }));
      },
      onError: (err) => {
        setTestVoiceState({
          loading: false,
          playing: false,
          error: 'Browser speech synthesis error.',
          successMessage: null,
        });
      },
    });
  };

  // Handle Live Gemini Ping
  const handlePingGemini = async () => {
    setGeminiPingState({
      testing: true,
      tested: false,
      connected: false,
      latencyMs: null,
      model: null,
      reply: null,
      error: null,
    });

    try {
      const resp = await fetch('/api/status/ping-gemini');
      const data = await resp.json();

      if (!resp.ok || !data.connected) {
        setGeminiPingState({
          testing: false,
          tested: true,
          connected: false,
          latencyMs: data.latencyMs || null,
          model: null,
          reply: null,
          error: data.error || data.message || 'Gemini ping failed.',
        });
        return;
      }

      setGeminiPingState({
        testing: false,
        tested: true,
        connected: true,
        latencyMs: data.latencyMs,
        model: data.model,
        reply: data.reply,
        error: null,
      });
    } catch (err: any) {
      setGeminiPingState({
        testing: false,
        tested: true,
        connected: false,
        latencyMs: null,
        model: null,
        reply: null,
        error: err.message || 'Ping request failed',
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
      <div className="bg-slate-950 border border-cyan-500/50 rounded-2xl max-w-xl w-full p-4 sm:p-6 jarvis-glow relative max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-cyan-500/25 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-cyan-950 border border-cyan-400/50 flex items-center justify-center">
              <Sliders className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h3 className="font-hud text-sm sm:text-base font-bold text-white tracking-wider">
                JARVIS Core Configuration Portal
              </h3>
              <p className="text-[10px] font-mono text-cyan-400/80">
                Live API Diagnostic Hub & Voice Architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
            aria-label="Close Settings modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-cyan-500/20 mt-3 shrink-0 overflow-x-auto text-nowrap scrollbar-none">
          <button
            onClick={() => setActiveTab('voice')}
            className={`px-3 py-2 text-xs font-tech tracking-wider flex items-center gap-1.5 border-b-2 transition-all cursor-pointer ${
              activeTab === 'voice'
                ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" /> Voice & TTS
          </button>
          <button
            onClick={() => setActiveTab('apis')}
            className={`px-3 py-2 text-xs font-tech tracking-wider flex items-center gap-1.5 border-b-2 transition-all cursor-pointer ${
              activeTab === 'apis'
                ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" /> API Status & Keys
          </button>
          <button
            onClick={() => setActiveTab('language')}
            className={`px-3 py-2 text-xs font-tech tracking-wider flex items-center gap-1.5 border-b-2 transition-all cursor-pointer ${
              activeTab === 'language'
                ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-3.5 h-3.5" /> Language
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`px-3 py-2 text-xs font-tech tracking-wider flex items-center gap-1.5 border-b-2 transition-all cursor-pointer ${
              activeTab === 'android'
                ? 'border-cyan-400 text-cyan-300 font-bold bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" /> Android Bridge
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1 text-xs font-tech">
          {/* TAB 1: VOICE SETTINGS */}
          {activeTab === 'voice' && (
            <div className="space-y-4">
              {/* Voice Engine Card */}
              <div className="p-3 rounded-xl bg-slate-900/80 border border-cyan-500/30 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="font-hud text-xs text-cyan-300 uppercase tracking-wider">
                    Audio Output Engine
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">Modular TTS Architecture</span>
                </div>

                <div className="space-y-2">
                  {/* ElevenLabs Option */}
                  <div
                    className={`p-3 rounded-lg border transition-all ${
                      systemStatus?.elevenLabsConfigured
                        ? voiceSettings.engine === 'elevenlabs'
                          ? 'border-cyan-400 bg-cyan-950/40'
                          : 'border-cyan-500/20 bg-slate-950/50'
                        : 'border-slate-800 bg-slate-950/80 opacity-90'
                    }`}
                  >
                    <label className="flex items-start gap-2.5 cursor-pointer">
                      <input
                        type="radio"
                        name="voiceEngine"
                        disabled={!systemStatus?.elevenLabsConfigured}
                        checked={voiceSettings.engine === 'elevenlabs'}
                        onChange={() => onUpdateVoiceSettings({ engine: 'elevenlabs' })}
                        className="mt-1 text-cyan-500 disabled:opacity-40"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between flex-wrap gap-1">
                          <span className="font-semibold text-white">
                            ElevenLabs Neural Voice (Natural Female)
                          </span>
                          {systemStatus?.elevenLabsConfigured ? (
                            <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-[9px] font-mono text-emerald-300 flex items-center gap-1">
                              <CheckCircle2 className="w-3 h-3" /> CONNECTED & READY
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-amber-950/70 border border-amber-500/40 text-[9px] font-mono text-amber-300 flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" /> UNAVAILABLE (KEY NOT DETECTED)
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-slate-400 mt-1">
                          Ultra-realistic female voice synthesis (Rachel / Sarah voice model).
                          {!systemStatus?.elevenLabsConfigured && (
                            <span className="text-amber-300/90 block mt-0.5 font-mono">
                              • Requires server secret <code className="text-amber-200">ELEVENLABS_API_KEY</code>. While unconfigured, this engine is honestly marked unavailable.
                            </span>
                          )}
                        </p>
                      </div>
                    </label>

                    {/* Female Voice Model Selector */}
                    <div className="mt-2.5 pt-2 border-t border-cyan-500/15">
                      <label className="block text-[11px] font-mono text-slate-300 mb-1">
                        Select Natural Female Persona (Hindi Multilingual):
                      </label>
                      <select
                        value={voiceSettings.elevenLabsVoiceId}
                        onChange={(e) => onUpdateVoiceSettings({ elevenLabsVoiceId: e.target.value })}
                        disabled={!systemStatus?.elevenLabsConfigured}
                        className="w-full bg-slate-900 border border-cyan-500/30 rounded px-2.5 py-1.5 text-xs text-cyan-200 focus:outline-none focus:border-cyan-400 font-mono disabled:opacity-40"
                      >
                        <option value="21m00Tcm4TlvDq8ikWAM">Rachel — Calm & Natural Female (Recommended)</option>
                        <option value="EXAVITQu4vr4xnSDxMaL">Sarah — Soft & Warm Conversational Female</option>
                        <option value="LcfcDJNigLHyjAdBueYs">Emily — Clear & Professional Assistant</option>
                        <option value="MF3mGyEYCl7XYWbV9V6O">Elli — Bright & Expressive Female</option>
                      </select>
                    </div>

                    {/* Test Voice (Hindi) Button specifically requested */}
                    <div className="mt-3 pt-2.5 border-t border-cyan-500/15 flex flex-wrap items-center justify-between gap-2">
                      <div className="text-[10px] font-mono text-slate-400">
                        Sentence: <span className="text-cyan-300 font-medium">"नमस्ते सर, मैं आपकी JARVIS असिस्टेंट हूँ।"</span>
                      </div>
                      <button
                        type="button"
                        onClick={handleTestElevenLabsHindi}
                        disabled={testVoiceState.loading}
                        className={`px-3 py-1.5 rounded text-xs font-tech flex items-center gap-1.5 transition-all cursor-pointer ${
                          systemStatus?.elevenLabsConfigured
                            ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-amber-500/30'
                        }`}
                        title="Test ElevenLabs Voice in Hindi"
                      >
                        {testVoiceState.loading ? (
                          <>
                            <RotateCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                            <span>Contacting ElevenLabs API...</span>
                          </>
                        ) : testVoiceState.playing ? (
                          <>
                            <Volume2 className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                            <span>Speaking Hindi Audio...</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            <span>Test Voice (Hindi - ElevenLabs)</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Test Voice Feedback Banner */}
                    {testVoiceState.error && (
                      <div className="mt-2 p-2 rounded bg-amber-950/40 border border-amber-500/40 text-[11px] font-mono text-amber-200 flex items-start gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div>
                          <p className="font-bold text-amber-300">ElevenLabs Not Connected:</p>
                          <p>{testVoiceState.error}</p>
                          <p className="text-[10px] text-slate-400 mt-1">
                            Go to the <strong>API Status & Keys</strong> tab to see how to add <code className="text-amber-300">ELEVENLABS_API_KEY</code>.
                          </p>
                        </div>
                      </div>
                    )}

                    {testVoiceState.successMessage && (
                      <div className="mt-2 p-2 rounded bg-emerald-950/40 border border-emerald-500/40 text-[11px] font-mono text-emerald-200 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        <p>{testVoiceState.successMessage}</p>
                      </div>
                    )}
                  </div>

                  {/* Browser Web Speech Option */}
                  <div
                    className={`p-3 rounded-lg border transition-all ${
                      voiceSettings.engine === 'browser'
                        ? 'border-cyan-400 bg-cyan-950/40'
                        : 'border-cyan-500/20 bg-slate-950/50'
                    }`}
                  >
                    <label className="flex items-start gap-2.5 cursor-pointer">
                      <input
                        type="radio"
                        name="voiceEngine"
                        checked={voiceSettings.engine === 'browser'}
                        onChange={() => onUpdateVoiceSettings({ engine: 'browser' })}
                        className="mt-1 text-cyan-500"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between flex-wrap gap-1">
                          <span className="font-semibold text-white">
                            High-Quality Device Speech Synthesis
                          </span>
                          <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-[9px] font-mono text-emerald-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> ACTIVE DEFAULT (100% READY)
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Uses Android/browser neural TTS with female pitch adjustments. Works 100% offline, zero latency, and supports Hindi and English.
                        </p>
                      </div>
                    </label>

                    {/* Test Browser Voice Buttons */}
                    <div className="mt-2.5 pt-2 border-t border-cyan-500/15 flex items-center gap-2">
                      <span className="text-[10px] font-mono text-slate-400">Test Device Voice:</span>
                      <button
                        type="button"
                        onClick={() => handleTestBrowserVoice('hi')}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-cyan-950 hover:border-cyan-400 border border-cyan-500/30 text-[11px] font-mono text-cyan-300 flex items-center gap-1 cursor-pointer"
                      >
                        <Volume2 className="w-3 h-3" /> Test Hindi
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTestBrowserVoice('en')}
                        className="px-2.5 py-1 rounded bg-slate-800 hover:bg-cyan-950 hover:border-cyan-400 border border-cyan-500/30 text-[11px] font-mono text-cyan-300 flex items-center gap-1 cursor-pointer"
                      >
                        <Volume2 className="w-3 h-3" /> Test English
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Pitch & Rate Sliders */}
              <div className="p-3 rounded-xl bg-slate-900/80 border border-cyan-500/30 space-y-3">
                <span className="font-hud text-xs text-cyan-300 uppercase tracking-wider block">
                  Vocal Modulation Matrices
                </span>

                <div>
                  <div className="flex justify-between text-[11px] font-mono text-slate-300 mb-1">
                    <span>Voice Pitch (Female Cadence):</span>
                    <span className="text-cyan-400">{voiceSettings.pitch}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.4"
                    step="0.05"
                    value={voiceSettings.pitch}
                    onChange={(e) => onUpdateVoiceSettings({ pitch: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] font-mono text-slate-300 mb-1">
                    <span>Speech Rate (Speed):</span>
                    <span className="text-cyan-400">{voiceSettings.speechRate}x</span>
                  </div>
                  <input
                    type="range"
                    min="0.8"
                    max="1.3"
                    step="0.05"
                    value={voiceSettings.speechRate}
                    onChange={(e) => onUpdateVoiceSettings({ speechRate: parseFloat(e.target.value) })}
                    className="w-full accent-cyan-400 cursor-pointer"
                  />
                </div>

                {/* Auto Speak Toggle */}
                <div className="flex items-center justify-between pt-2 border-t border-cyan-500/20">
                  <div>
                    <p className="font-semibold text-white text-xs">Auto-Vocalize AI Responses</p>
                    <p className="text-[10px] font-mono text-slate-400">Automatically read JARVIS responses out loud</p>
                  </div>
                  <button
                    onClick={() => onUpdateVoiceSettings({ autoSpeak: !voiceSettings.autoSpeak })}
                    className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                      voiceSettings.autoSpeak ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                    aria-label="Toggle auto speak"
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        voiceSettings.autoSpeak ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Continuous Conversation Toggle */}
                <div className="flex items-center justify-between pt-2 border-t border-cyan-500/20">
                  <div className="pr-2">
                    <div className="flex items-center gap-1.5">
                      <p className="font-semibold text-white text-xs">Continuous Conversation Mode</p>
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold ${
                        voiceSettings.continuousConversation
                          ? 'bg-cyan-950 border border-cyan-400 text-cyan-300'
                          : 'bg-slate-900 border border-slate-700 text-slate-400'
                      }`}>
                        {voiceSettings.continuousConversation ? 'LOOP ACTIVE' : 'PUSH-TO-TALK'}
                      </span>
                    </div>
                    <p className="text-[10px] font-mono text-slate-400 mt-0.5">
                      Automatically restarts microphone listening after JARVIS finishes speaking. Keeps the conversational flow open hands-free while this page is active.
                    </p>
                    <p className="text-[9px] font-mono text-cyan-400/80 mt-0.5">
                      • Web limitation: Active in foreground browser tab only. Pauses if phone locks or tab is hidden.
                    </p>
                  </div>
                  <button
                    onClick={() =>
                      onUpdateVoiceSettings({
                        continuousConversation: !voiceSettings.continuousConversation,
                      })
                    }
                    className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer shrink-0 ${
                      voiceSettings.continuousConversation ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                    aria-label="Toggle continuous conversation"
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        voiceSettings.continuousConversation ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Voice Enrollment / My Voice Only Toggle */}
                <div className="flex items-center justify-between pt-2 border-t border-cyan-500/20">
                  <div className="pr-2">
                    <div className="flex items-center gap-1.5">
                      <p className="font-semibold text-white text-xs">My Voice Only (Biometric Enrollment)</p>
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold ${
                        voiceSettings.voiceEnrollmentEnabled
                          ? 'bg-emerald-950 border border-emerald-400 text-emerald-300'
                          : 'bg-slate-900 border border-slate-700 text-slate-400'
                      }`}>
                        {voiceSettings.voiceEnrollmentEnabled ? 'ENROLLED' : 'EXPERIMENTAL'}
                      </span>
                    </div>
                    <p className="text-[10px] font-mono text-slate-400 mt-0.5">
                      Optional voice profile enrollment with explicit consent. Note: Browser speech recognition alone cannot guarantee cryptographic speaker verification; this labels assistant access for demo security.
                    </p>
                  </div>
                  <button
                    onClick={() =>
                      onUpdateVoiceSettings({
                        voiceEnrollmentEnabled: !voiceSettings.voiceEnrollmentEnabled,
                      })
                    }
                    className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer shrink-0 ${
                      voiceSettings.voiceEnrollmentEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                    aria-label="Toggle voice enrollment"
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        voiceSettings.voiceEnrollmentEnabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Sound Effects Toggle */}
                <div className="flex items-center justify-between pt-2 border-t border-cyan-500/20">
                  <div>
                    <p className="font-semibold text-white text-xs">HUD Sound Synthesis</p>
                    <p className="text-[10px] font-mono text-slate-400">Play sci-fi tones on input and state changes</p>
                  </div>
                  <button
                    onClick={() => onUpdateVoiceSettings({ soundEffects: !voiceSettings.soundEffects })}
                    className={`w-11 h-6 rounded-full transition-colors relative p-0.5 cursor-pointer ${
                      voiceSettings.soundEffects ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                    aria-label="Toggle HUD sound effects"
                  >
                    <div
                      className={`w-5 h-5 rounded-full bg-white transition-transform ${
                        voiceSettings.soundEffects ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: API STATUS & CONFIGURATION */}
          {activeTab === 'apis' && (
            <div className="space-y-4">
              <div className="p-3 rounded-lg bg-slate-900/90 border border-cyan-500/25 text-[11px] font-mono text-slate-300 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-cyan-300">Security Architecture:</p>
                  <p>All API credentials are read strictly on the server (<code className="text-cyan-400">process.env</code>) and never bundled into client-side JavaScript or HTML.</p>
                </div>
              </div>

              {/* Status Matrix */}
              <div className="space-y-3">
                {/* 1. Gemini AI Status Card */}
                <div className="p-3 rounded-xl bg-slate-900/80 border border-cyan-500/30 space-y-2.5">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <span className="font-bold text-white text-xs sm:text-sm">
                        Google Gemini AI Engine
                      </span>
                    </div>
                    {systemStatus?.geminiConfigured ? (
                      <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-[10px] font-mono text-emerald-300 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> CONNECTED & RESPONDING
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded bg-amber-950 border border-amber-500/40 text-[10px] font-mono text-amber-300 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> NOT CONFIGURED
                      </span>
                    )}
                  </div>

                  <div className="text-[11px] font-mono text-slate-300 space-y-1">
                    <p>• <strong>Environment Secret:</strong> <code className="text-cyan-300">GEMINI_API_KEY</code></p>
                    <p>• <strong>Active Model:</strong> <code className="text-cyan-300">gemini-3.1-flash-lite</code> (High-speed voice neural engine with sub-2s latency)</p>
                    <p>• <strong>Languages Supported:</strong> English, Hindi (हिन्दी), Hinglish</p>
                  </div>

                  {/* Live Ping Button */}
                  <div className="pt-2 border-t border-cyan-500/15 flex items-center justify-between flex-wrap gap-2">
                    <button
                      onClick={handlePingGemini}
                      disabled={geminiPingState.testing}
                      className="px-3 py-1.5 rounded bg-cyan-600 hover:bg-cyan-500 text-black font-semibold text-xs font-tech flex items-center gap-1.5 shadow-[0_0_12px_rgba(0,229,255,0.4)] transition-all cursor-pointer"
                    >
                      {geminiPingState.testing ? (
                        <>
                          <RotateCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Testing Live Ping...</span>
                        </>
                      ) : (
                        <>
                          <Radio className="w-3.5 h-3.5" />
                          <span>Ping Gemini Server Now</span>
                        </>
                      )}
                    </button>

                    {geminiPingState.tested && (
                      <div className="text-[11px] font-mono">
                        {geminiPingState.connected ? (
                          <span className="text-emerald-300 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Live in {geminiPingState.latencyMs}ms ({geminiPingState.model})
                          </span>
                        ) : (
                          <span className="text-rose-400 flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            Ping failed: {geminiPingState.error}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* 2. ElevenLabs Status Card */}
                <div className="p-3 rounded-xl bg-slate-900/80 border border-cyan-500/30 space-y-2.5">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <Volume2 className="w-4 h-4 text-purple-400" />
                      <span className="font-bold text-white text-xs sm:text-sm">
                        ElevenLabs Natural Voice TTS
                      </span>
                    </div>
                    {elevenLabsValidation.validated ? (
                      elevenLabsValidation.connected ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500/40 text-[10px] font-mono text-emerald-300 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> VERIFIED CONNECTED (200 OK)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-rose-950 border border-rose-500/40 text-[10px] font-mono text-rose-300 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" /> HANDSHAKE FAILED
                        </span>
                      )
                    ) : systemStatus?.elevenLabsConfigured ? (
                      <span className="px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/40 text-[10px] font-mono text-emerald-300 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> KEY DETECTED (READY TO VERIFY)
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded bg-amber-950 border border-amber-500/40 text-[10px] font-mono text-amber-300 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" /> NOT CONFIGURED (FALLBACK ACTIVE)
                      </span>
                    )}
                  </div>

                  <div className="text-[11px] font-mono text-slate-300 space-y-1">
                    <p>• <strong>Environment Secret:</strong> <code className="text-purple-300">ELEVENLABS_API_KEY</code></p>
                    <p>• <strong>Voice Models:</strong> <code className="text-purple-300">eleven_multilingual_v2</code> with Hindi support</p>
                    <p>• <strong>Female Personas:</strong> Rachel, Sarah, Emily, Elli</p>
                    <p>• <strong>Integrity Policy:</strong> Status is never marked as Connected until a real server-side API request succeeds.</p>
                  </div>

                  {/* ElevenLabs Live Handshake Verification Button */}
                  <div className="pt-2 border-t border-cyan-500/15 flex items-center justify-between flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={handleValidateElevenLabs}
                      disabled={elevenLabsValidation.validating}
                      className="px-3 py-1.5 rounded bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs font-tech flex items-center gap-1.5 shadow-[0_0_12px_rgba(168,85,247,0.4)] transition-all cursor-pointer"
                    >
                      {elevenLabsValidation.validating ? (
                        <>
                          <RotateCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Pinging ElevenLabs API...</span>
                        </>
                      ) : (
                        <>
                          <Radio className="w-3.5 h-3.5" />
                          <span>Test Live ElevenLabs Handshake</span>
                        </>
                      )}
                    </button>

                    {elevenLabsValidation.validated && (
                      <div className="text-[11px] font-mono w-full mt-1.5">
                        {elevenLabsValidation.connected ? (
                          <div className="p-2 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-200">
                            <p className="font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              Handshake Verified: ElevenLabs API returned 200 OK
                            </p>
                            <p className="text-[10px] text-slate-300 mt-0.5">
                              Tier: <span className="text-cyan-300">{elevenLabsValidation.tier}</span> | Characters used: <span className="text-cyan-300">{elevenLabsValidation.characterCount}</span> / {elevenLabsValidation.characterLimit}
                            </p>
                          </div>
                        ) : (
                          <div className="p-2 rounded bg-rose-950/60 border border-rose-500/40 text-rose-200">
                            <p className="font-semibold flex items-center gap-1">
                              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                              Handshake Failed (Real API Check):
                            </p>
                            <p className="text-[10px] text-rose-300 mt-0.5">
                              {elevenLabsValidation.statusMessage}
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* 3. Step-by-Step API Key Setup Guide */}
                <div className="p-3.5 rounded-xl bg-slate-950 border border-cyan-500/40 space-y-2 text-xs">
                  <h5 className="font-hud text-xs text-cyan-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <Key className="w-4 h-4 text-cyan-400" />
                    How to Securely Configure API Keys on Server
                  </h5>

                  <div className="space-y-2 font-tech text-slate-300 text-[11px] leading-relaxed">
                    <div className="p-2 rounded bg-slate-900/90 border border-cyan-500/20">
                      <p className="text-white font-semibold flex items-center gap-1 mb-0.5">
                        <span className="w-4 h-4 rounded-full bg-cyan-900 text-cyan-200 text-center text-[10px] leading-4 font-mono">1</span>
                        In Google AI Studio:
                      </p>
                      <p className="text-slate-400">
                        Look at the AI Studio UI top navigation or Settings menu and click on <strong>Secrets</strong>.
                      </p>
                    </div>

                    <div className="p-2 rounded bg-slate-900/90 border border-cyan-500/20">
                      <p className="text-white font-semibold flex items-center gap-1 mb-0.5">
                        <span className="w-4 h-4 rounded-full bg-cyan-900 text-cyan-200 text-center text-[10px] leading-4 font-mono">2</span>
                        To configure Gemini AI:
                      </p>
                      <p className="text-slate-400">
                        AI Studio automatically injects your selected Gemini API key into <code className="text-cyan-300 font-mono">GEMINI_API_KEY</code>. It is currently <strong className="text-emerald-400">active</strong> in this environment.
                      </p>
                    </div>

                    <div className="p-2 rounded bg-slate-900/90 border border-cyan-500/20">
                      <p className="text-white font-semibold flex items-center gap-1 mb-0.5">
                        <span className="w-4 h-4 rounded-full bg-cyan-900 text-cyan-200 text-center text-[10px] leading-4 font-mono">3</span>
                        To configure ElevenLabs Voice:
                      </p>
                      <p className="text-slate-400">
                        1. Obtain your API key from <span className="text-purple-300 font-mono">elevenlabs.io</span>.<br />
                        2. In AI Studio Secrets panel, click <strong>Add Secret</strong>.<br />
                        3. Set name to: <code className="text-purple-300 font-mono">ELEVENLABS_API_KEY</code>.<br />
                        4. Paste your key and save. The server immediately detects it without any code edits!
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: LANGUAGE */}
          {activeTab === 'language' && (
            <div className="space-y-3">
              <p className="text-slate-300 text-xs">
                JARVIS natively processes input and formulates replies across English, Hindi, and Hinglish. Select your primary preferred interaction mode:
              </p>

              <div className="space-y-2">
                {/* English */}
                <button
                  onClick={() => onSelectLanguage('en')}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                    language === 'en'
                      ? 'border-cyan-400 bg-cyan-950/40 text-white'
                      : 'border-cyan-500/20 bg-slate-900/60 text-slate-300 hover:border-cyan-500/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">English (Global)</span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-cyan-300">en-US</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      "Good day Sir, JARVIS standing by for your command."
                    </p>
                  </div>
                  {language === 'en' && <CheckCircle2 className="w-5 h-5 text-cyan-400" />}
                </button>

                {/* Hindi */}
                <button
                  onClick={() => onSelectLanguage('hi')}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                    language === 'hi'
                      ? 'border-cyan-400 bg-cyan-950/40 text-white'
                      : 'border-cyan-500/20 bg-slate-900/60 text-slate-300 hover:border-cyan-500/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">हिन्दी (Hindi)</span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-cyan-300">hi-IN</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      "नमस्ते सर, जार्विस सिस्टम्स सक्रिय हैं। मैं आपकी क्या सेवा कर सकता हूँ?"
                    </p>
                  </div>
                  {language === 'hi' && <CheckCircle2 className="w-5 h-5 text-cyan-400" />}
                </button>

                {/* Hinglish */}
                <button
                  onClick={() => onSelectLanguage('hinglish')}
                  className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                    language === 'hinglish'
                      ? 'border-cyan-400 bg-cyan-950/40 text-white'
                      : 'border-cyan-500/20 bg-slate-900/60 text-slate-300 hover:border-cyan-500/40'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">Hinglish (Mix)</span>
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-cyan-300">en-IN / hi</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      "Namaste Sir! JARVIS ready hai, aap batayein kya task execute karna hai?"
                    </p>
                  </div>
                  {language === 'hinglish' && <CheckCircle2 className="w-5 h-5 text-cyan-400" />}
                </button>
              </div>
            </div>
          )}

          {/* TAB 4: ANDROID NATIVE ARCHITECTURE */}
          {activeTab === 'android' && (
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-slate-900/80 border border-cyan-500/30 space-y-2">
                <h4 className="font-hud text-xs text-cyan-300 uppercase flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  Prototype vs Native Android Production Guide
                </h4>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  This app prototype is engineered mobile-first so it can run as an interactive web preview now and compile into a complete native Android APK via <strong>Capacitor</strong> or <strong>Jetpack Compose WebView Bridge</strong>.
                </p>
              </div>

              {/* Matrix of Feature Support */}
              <div className="space-y-2">
                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-cyan-500/20 text-[11px] space-y-1">
                  <div className="flex items-center justify-between text-white font-semibold">
                    <span>1. YouTube Dispatch</span>
                    <span className="text-emerald-400">Working Now & Native Ready</span>
                  </div>
                  <p className="text-slate-400 font-mono">
                    Web preview opens YouTube search directly; Android uses <code className="text-cyan-400">Intent(ACTION_VIEW, Uri.parse("vnd.youtube:..."))</code>.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-cyan-500/20 text-[11px] space-y-1">
                  <div className="flex items-center justify-between text-white font-semibold">
                    <span>2. Phone Dialer & Calls</span>
                    <span className="text-amber-400">tel: Working / Direct Call Needs APK</span>
                  </div>
                  <p className="text-slate-400 font-mono">
                    Web preview opens system dialer via <code className="text-cyan-400">tel:</code> URI. Native Android uses <code className="text-cyan-400">CALL_PHONE</code> permission for hands-free auto-dialing.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-cyan-500/20 text-[11px] space-y-1">
                  <div className="flex items-center justify-between text-white font-semibold">
                    <span>3. Flashlight Control</span>
                    <span className="text-cyan-400">Web Torch Supported / Camera2 APK</span>
                  </div>
                  <p className="text-slate-400 font-mono">
                    Web preview invokes <code className="text-cyan-400">navigator.mediaDevices</code> torch constraint; Android APK calls <code className="text-cyan-400">CameraManager.setTorchMode()</code>.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-cyan-500/20 text-[11px] space-y-1">
                  <div className="flex items-center justify-between text-white font-semibold">
                    <span>4. Reminders & Alarms</span>
                    <span className="text-purple-400">Web Scheduler / AlarmManager APK</span>
                  </div>
                  <p className="text-slate-400 font-mono">
                    Web preview schedules timers with audio cues; Android APK hooks into <code className="text-cyan-400">AlarmClock.ACTION_SET_ALARM</code> and <code className="text-cyan-400">WorkManager</code> for screen-off alarms.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-slate-900/60 border border-cyan-500/20 text-[11px] space-y-1">
                  <div className="flex items-center justify-between text-white font-semibold">
                    <span>5. System Settings</span>
                    <span className="text-rose-400">Strictly Native Intent</span>
                  </div>
                  <p className="text-slate-400 font-mono">
                    Sandboxed browsers cannot modify Android OS settings; in native APK, JARVIS launches <code className="text-cyan-400">Settings.ACTION_SETTINGS</code>.
                  </p>
                </div>

                <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-400/40 text-[11px] space-y-1.5">
                  <div className="flex items-center justify-between text-white font-semibold">
                    <span className="text-cyan-300">6. Continuous Microphone & Background Listening</span>
                    <span className="text-emerald-400">Web Foreground / ForegroundService APK</span>
                  </div>
                  <p className="text-slate-300 font-mono">
                    • <strong>Web Preview Reality:</strong> Uses Web Speech API (<code className="text-cyan-400">webkitSpeechRecognition</code>). Works for 15–20s utterances and continuous conversation loops while this web tab stays open and active. Mobile browsers automatically pause mic capture when the screen locks or user switches apps.
                  </p>
                  <p className="text-slate-300 font-mono">
                    • <strong>Native Android APK Implementation:</strong> Requires a sticky <code className="text-cyan-400">ForegroundService</code> with a persistent notification, plus <code className="text-cyan-400">FOREGROUND_SERVICE_MICROPHONE</code> and <code className="text-cyan-400">RECORD_AUDIO</code> permissions to continuously listen for commands or wake-words even when the phone screen is off.
                  </p>
                </div>
              </div>

              {/* Sample Android Manifest snippet */}
              <div className="p-3 rounded-xl bg-black/60 border border-cyan-500/30 text-[10px] font-mono">
                <div className="flex items-center justify-between text-cyan-300 font-semibold mb-1">
                  <span className="flex items-center gap-1">
                    <Code2 className="w-3.5 h-3.5" /> AndroidManifest.xml Blueprint
                  </span>
                </div>
                <pre className="text-slate-300 overflow-x-auto whitespace-pre">
{`<manifest package="com.stark.jarvisai">
  <uses-permission android:name="android.permission.RECORD_AUDIO" />
  <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
  <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />
  <uses-permission android:name="android.permission.CALL_PHONE" />
  <uses-permission android:name="android.permission.CAMERA" />
  <uses-permission android:name="android.permission.FLASHLIGHT" />
  <uses-permission android:name="com.android.alarm.permission.SET_ALARM" />
  <uses-permission android:name="android.permission.WAKE_LOCK" />
  <uses-permission android:name="android.permission.INTERNET" />

  <application android:name=".JarvisApp">
    <service
      android:name=".services.JarvisVoiceForegroundService"
      android:foregroundServiceType="microphone"
      android:exported="false" />
  </application>
</manifest>`}
                </pre>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-cyan-500/25 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-black font-semibold rounded-lg text-xs font-tech tracking-wider shadow-[0_0_15px_rgba(0,229,255,0.4)] transition-all cursor-pointer"
          >
            CONFIRM & RETURN
          </button>
        </div>
      </div>
    </div>
  );
};
