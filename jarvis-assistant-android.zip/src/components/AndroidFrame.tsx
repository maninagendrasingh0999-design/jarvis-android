/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal, Smartphone, Monitor } from 'lucide-react';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeLanguage: string;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ children, activeLanguage }) => {
  const [currentTime, setCurrentTime] = useState<string>('21:40');
  const [deviceView, setDeviceView] = useState<'mobile' | 'expanded'>('mobile');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-0 sm:p-4 md:p-6 relative overflow-x-hidden">
      {/* Background Cyber Grid Lines */}
      <div className="absolute inset-0 scanline-overlay pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(0,102,255,0.15),rgba(255,255,255,0))] pointer-events-none" />

      {/* Desktop Viewport Mode Toggle */}
      <div className="hidden sm:flex items-center gap-2 mb-3 z-20 bg-slate-950/80 px-3 py-1.5 rounded-full border border-cyan-500/30 text-xs font-mono">
        <span className="text-slate-400">Display Layout:</span>
        <button
          onClick={() => setDeviceView('mobile')}
          className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full transition-all ${
            deviceView === 'mobile'
              ? 'bg-cyan-500 text-black font-bold shadow-[0_0_10px_#00e5ff]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" /> Android Phone Shell
        </button>
        <button
          onClick={() => setDeviceView('expanded')}
          className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full transition-all ${
            deviceView === 'expanded'
              ? 'bg-cyan-500 text-black font-bold shadow-[0_0_10px_#00e5ff]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" /> Fullscreen Responsive
        </button>
      </div>

      {/* Main Container */}
      <div
        className={`w-full transition-all duration-300 relative z-10 flex flex-col bg-[#050811] ${
          deviceView === 'mobile'
            ? 'sm:max-w-[420px] sm:h-[820px] sm:max-h-[96vh] sm:rounded-[44px] sm:border-[5px] sm:border-slate-800 sm:ring-1 sm:ring-cyan-500/40 sm:shadow-[0_0_60px_rgba(0,229,255,0.25)] sm:overflow-hidden'
            : 'max-w-4xl min-h-screen sm:min-h-[820px] sm:rounded-2xl sm:border border-cyan-500/30 sm:shadow-[0_0_40px_rgba(0,229,255,0.2)]'
        }`}
      >
        {/* Android Status Bar */}
        <div className="w-full pt-2.5 px-6 pb-1 bg-slate-950/80 flex items-center justify-between text-xs font-mono text-slate-300 select-none shrink-0 border-b border-cyan-500/10">
          <div className="flex items-center gap-1 font-semibold text-cyan-200">
            <span>{currentTime}</span>
          </div>

          {/* Android Front Camera Notch Pin */}
          <div className="w-4 h-4 rounded-full bg-black border border-cyan-500/30 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-cyan-900" />
          </div>

          {/* System Indicators */}
          <div className="flex items-center gap-2 text-cyan-400">
            <Signal className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px]">98%</span>
              <BatteryMedium className="w-3.5 h-3.5 text-cyan-400" />
            </div>
          </div>
        </div>

        {/* Content Viewport */}
        <div className="flex-1 flex flex-col overflow-y-auto p-3 sm:p-4">
          {children}
        </div>

        {/* Android Bottom Home Navigation Pill */}
        <div className="w-full py-2 bg-slate-950/90 flex items-center justify-center select-none shrink-0 border-t border-cyan-500/10">
          <div className="w-32 h-1 rounded-full bg-cyan-400/40 hover:bg-cyan-400 transition-colors cursor-pointer" />
        </div>
      </div>
    </div>
  );
};
