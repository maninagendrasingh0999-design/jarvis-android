/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Terminal, Copy, Check, X, Code2, Wrench } from 'lucide-react';
import { CodeSolution } from '../types';

interface CodeTerminalModalProps {
  isOpen: boolean;
  onClose: () => void;
  solution: CodeSolution | null;
}

export const CodeTerminalModal: React.FC<CodeTerminalModalProps> = ({
  isOpen,
  onClose,
  solution,
}) => {
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen || !solution) return null;

  const handleCopy = () => {
    if (!solution.code) return;
    navigator.clipboard.writeText(solution.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-2xl max-h-[85vh] flex flex-col rounded-2xl border border-cyan-500/40 bg-slate-950/98 shadow-2xl shadow-cyan-500/25 text-cyan-100 overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-cyan-500/30 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
            </div>
            <div className="flex items-center gap-2 text-cyan-300 font-mono text-sm font-semibold">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>JARVIS Neural Solution Terminal</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[11px] font-mono uppercase font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              {solution.language || 'CODE'}
            </span>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Title & Explanation */}
        <div className="px-5 py-3.5 bg-slate-900/40 border-b border-cyan-500/20">
          <div className="flex items-center gap-2 text-cyan-200 font-bold text-base mb-1">
            <Wrench className="w-4 h-4 text-cyan-400 shrink-0" />
            <h4>{solution.title || 'Technical Implementation'}</h4>
          </div>
          {solution.explanation && (
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {solution.explanation}
            </p>
          )}
        </div>

        {/* Code Viewport with Line Numbers */}
        <div className="relative flex-1 p-4 overflow-y-auto bg-black/90 font-mono text-xs text-cyan-300 leading-relaxed">
          <button
            onClick={handleCopy}
            className="absolute top-4 right-4 z-10 flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-cyan-500/40 bg-slate-900/90 hover:bg-cyan-950 text-cyan-300 text-xs font-mono font-medium shadow-md transition-all"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-cyan-400" />
                <span>Copy Code</span>
              </>
            )}
          </button>

          <pre className="overflow-x-auto whitespace-pre font-mono pr-24 select-text selection:bg-cyan-500/30 selection:text-white">
            <code>{solution.code}</code>
          </pre>
        </div>

        {/* Terminal Footer */}
        <div className="flex items-center justify-between px-5 py-2.5 bg-slate-950 border-t border-cyan-500/20 text-[11px] font-mono text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            <span>Autonomous Code Engine • Verified</span>
          </div>
          <button
            onClick={handleCopy}
            className="hover:text-cyan-300 transition-colors cursor-pointer"
          >
            Click "Copy Code" to paste into IDE / Terminal
          </button>
        </div>
      </div>
    </div>
  );
};
