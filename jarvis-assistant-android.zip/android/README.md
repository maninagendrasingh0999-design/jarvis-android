# JARVIS Assistant — Native Android APK Project

Production-ready Native Android Studio Project for **JARVIS Assistant**, configured for **Vivo T3 Pro (Android 14 / Android 16 / Funtouch OS)**.

---

## 1. Project Specifications

- **App Name**: `JARVIS Assistant`
- **Application ID / Package**: `com.myassistant.app`
- **Minimum SDK**: Android 8.0 (API 26)
- **Target SDK**: Android 14 (API 34) (Fully compatible with Android 15 & Android 16)
- **Service Type**: `foregroundServiceType="microphone"`
- **Wake Phrase**: **"Hallo Javed"** &rarr; Voice Reply: *"Ji, main sun rahi hoon. Bataiye, kya karna hai?"*
- **Standby Commands**: **"Javed shutdown ho jao"**, **"Shutdown ho jao"**, **"Band ho jao"** &rarr; Leaves microphone listening for "Hallo Javed" without stopping the background service!
- **Downloadable ZIP Archive**: Available at `/download/jarvis-android-project.zip` (tap "APK Project" in HUD)

---

## 2. Tested Features & Native Capabilities

1. **Wake-Word & Hands-Free Interaction**:
   - `JarvisVoiceForegroundService`: Persistent ongoing notification (`FOREGROUND_SERVICE_MICROPHONE`).
   - Listens for "Hallo Javed", instantly responds with Hindi/Hinglish female voice, and keeps conversational listening active.
   - Saying "Javed shutdown ho jao" or "Shutdown ho jao" puts the app in Standby mode while maintaining wake-word detection.
2. **WhatsApp Intent**:
   - Commands: *"Amit Patel ko WhatsApp par message bhejo: taiyar ho jao"*, *"Rahul ko bolo ki main 10 minute mein aa raha hoon"*.
   - Queries `ContactsContract` for international phone number, presents confirmation dialog, and opens `com.whatsapp`.
3. **Phone Calling & Dialer**:
   - Commands: *"Amit Patel ko call lagao"*, *"Call Dr Banner"*.
   - Dispatches `ACTION_CALL` when permission is granted or prefilled `ACTION_DIAL`.
4. **Physical Flashlight**:
   - Controls physical rear LED via `CameraManager.setTorchMode()`.
5. **YouTube & Navigation**:
   - Commands: *"YouTube kholo"*, *"Navigate to Mumbai"*, *"Taj Mahal ka rasta dikhao"*.
   - Dispatches official YouTube (`com.google.android.youtube`) and Google Maps (`com.google.android.apps.maps`) intents.
6. **Installed Apps**:
   - Opens Calculator, Camera, Spotify, etc., using `PackageManager.getLaunchIntentForPackage`.

---

## 3. How to Build the APK (Phone-Only & PC Methods)

### Method A: Phone-Only via GitHub Actions (Zero PC Required)
If you only have your Vivo T3 Pro:
1. Tap the **APK Project** button in the top header to download `jarvis-assistant-android.zip`.
2. Extract the ZIP on your phone or upload it to a private repository on [github.com](https://github.com).
3. Add a GitHub Actions workflow (`.github/workflows/android.yml`):
   ```yaml
   name: Build Android APK
   on: [push, workflow_dispatch]
   jobs:
     build:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v4
         - uses: actions/setup-java@v4
           with: { java-version: '17', distribution: 'temurin' }
         - uses: gradle/actions/setup-gradle@v3
         - run: cd android && chmod +x gradlew && ./gradlew assembleDebug
         - uses: actions/upload-artifact@v4
           with: { name: app-debug, path: android/app/build/outputs/apk/debug/app-debug.apk }
   ```
4. GitHub will build `app-debug.apk` in ~2 minutes. Download the APK directly to your phone from the GitHub Actions tab!

### Method B: Build using Android Studio on PC
1. Download or clone this repository and open the `android/` directory in **Android Studio**.
2. Let Gradle automatically sync dependencies.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The output APK is generated at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 4. Vivo T3 Pro Setup (Funtouch OS)

To allow JARVIS to run all day in the background:
1. **Developer Options**:
   - Go to **Settings > About phone > Software information** &rarr; tap **Build number** 7 times.
   - Go to **Settings > System > Developer options** &rarr; enable **USB Debugging** and **Install via USB**.
2. **Background Battery Permission (Crucial for Vivo/iQOO)**:
   - Long-press the **JARVIS Assistant** icon &rarr; tap **App info**.
   - Tap **Battery** &rarr; select **Unrestricted** (prevents Funtouch OS from killing the voice service when the screen locks).
3. **Autostart Permission**:
   - Go to **Settings > Apps > Special app access > Autostart** &rarr; enable **JARVIS Assistant**.
