# ProGuard rules for J.A.R.V.I.S. AI Native Android APK

# Keep JavascriptInterface methods accessible from WebView
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep StarkAndroidBridge methods and class intact
-keep class com.myassistant.app.bridge.StarkAndroidBridge { *; }

# Keep SpeechRecognizer and Foreground Service components
-keep class com.myassistant.app.services.JarvisVoiceForegroundService { *; }
-keep class com.myassistant.app.MainActivity { *; }
-keep class com.myassistant.app.JarvisApp { *; }

# Keep AndroidX and Coroutines
-keepattributes *Annotation*
-dontwarn okio.**
-dontwarn javax.annotation.**
