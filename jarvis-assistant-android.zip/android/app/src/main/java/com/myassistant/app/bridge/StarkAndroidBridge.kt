package com.myassistant.app.bridge

import android.webkit.JavascriptInterface
import com.myassistant.app.MainActivity

/**
 * JavaScript interface exposed to the Stark web HUD as window.AndroidBridge and window.JarvisNative.
 *
 * Bridges HUD buttons, recognized voice commands, and Gemini autonomous actions to native Android APIs:
 * - Autonomous ActionExecutor for all actions (OPEN_APP, YOUTUBE_SEARCH_PLAY, WHATSAPP_SEND, MAKE_CALL, SET_ALARM, SET_TIMER, TOGGLE_TORCH, SYSTEM_SETTING, GOOGLE_SEARCH, OPEN_URL, GLOBAL_ACTION)
 * - MacroDroid Automation Bridge (broadcast + local HTTP webhook)
 * - Permanent Memory System (SharedPreferences)
 * - Gemini API key storage
 * - Direct app, phone, WhatsApp, and hardware controls
 */
class StarkAndroidBridge(private val activity: MainActivity) {

    /**
     * Autonomous Action Execution entry point called from Web UI HUD & Gemini Engine
     */
    @JavascriptInterface
    fun executeAction(actionJson: String): Boolean {
        activity.runOnUiThread {
            activity.actionExecutor.execute(actionJson)
        }
        return true
    }

    /**
     * Permanent Memory System: Save fact/memory into Android SharedPreferences
     */
    @JavascriptInterface
    fun saveMemory(key: String, value: String) {
        activity.actionExecutor.savePermanentMemory(key, value)
    }

    @JavascriptInterface
    fun getMemory(key: String): String? {
        return activity.actionExecutor.getPermanentMemory(key)
    }

    @JavascriptInterface
    fun getAllMemories(): String {
        return activity.actionExecutor.getAllPermanentMemories()
    }

    /**
     * Gemini API Key persistence in native storage
     */
    @JavascriptInterface
    fun saveApiKey(key: String) {
        activity.actionExecutor.saveGeminiApiKey(key)
    }

    @JavascriptInterface
    fun getApiKey(): String? {
        return activity.actionExecutor.getGeminiApiKey()
    }

    /**
     * Direct MacroDroid trigger
     */
    @JavascriptInterface
    fun triggerMacroDroid(command: String, target: String, message: String) {
        activity.actionExecutor.triggerMacroDroidBridge(command, target, message)
    }

    /**
     * Global gesture navigation (Back, Home, Recents, Notifications, Lock)
     */
    @JavascriptInterface
    fun performGlobalAction(action: String): Boolean {
        return activity.actionExecutor.performGlobalAction(action)
    }

    @JavascriptInterface
    fun sendWhatsApp(contactName: String, messageText: String) {
        activity.runOnUiThread {
            activity.actionExecutor.sendWhatsApp(contactName, null, messageText)
        }
    }

    @JavascriptInterface
    fun makeCall(phoneNumberOrName: String) {
        activity.runOnUiThread {
            activity.actionExecutor.makeCall(phoneNumberOrName)
        }
    }

    @JavascriptInterface
    fun setTorchMode(enabled: Boolean) {
        activity.runOnUiThread {
            activity.actionExecutor.toggleTorch(if (enabled) "on" else "off")
        }
    }

    @JavascriptInterface
    fun openYouTube(query: String) {
        activity.runOnUiThread {
            activity.actionExecutor.openYouTube(query)
        }
    }

    @JavascriptInterface
    fun openMaps(destination: String) {
        activity.runOnUiThread {
            activity.actionExecutor.openMaps(destination)
        }
    }

    @JavascriptInterface
    fun openApp(appNameOrPackage: String) {
        activity.runOnUiThread {
            activity.actionExecutor.openAppByNameOrPackage(appNameOrPackage)
        }
    }

    @JavascriptInterface
    fun setAlarm(message: String, minutesFromNow: Int) {
        activity.runOnUiThread {
            activity.actionExecutor.setAlarm(message, -1, -1, minutesFromNow, true)
        }
    }

    @JavascriptInterface
    fun startVoiceService() {
        activity.runOnUiThread {
            activity.startMicrophoneForegroundService()
        }
    }

    @JavascriptInterface
    fun stopVoiceService() {
        activity.runOnUiThread {
            activity.stopMicrophoneForegroundService()
        }
    }

    @JavascriptInterface
    fun enterStandby() {
        activity.runOnUiThread {
            activity.enterStandby()
        }
    }

    @JavascriptInterface
    fun speakText(text: String, lang: String) {
        activity.runOnUiThread {
            activity.speakWithNativeTTS(text, lang)
        }
    }

    @JavascriptInterface
    fun toggleFloatingOrb(enable: Boolean): Boolean {
        return activity.toggleFloatingOrb(enable)
    }

    @JavascriptInterface
    fun hasOverlayPermission(): Boolean {
        return activity.canDrawOverlays()
    }

    @JavascriptInterface
    fun requestOverlayPermission() {
        activity.runOnUiThread {
            activity.requestOverlayPermission()
        }
    }

    @JavascriptInterface
    fun isFloatingOrbRunning(): Boolean {
        return com.myassistant.app.services.FloatingOrbService.isRunning
    }

    @JavascriptInterface
    fun isNativeAndroid(): Boolean = true
}
