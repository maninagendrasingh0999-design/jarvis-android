package com.myassistant.app.services

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import com.myassistant.app.MainActivity

/**
 * Native Android Floating Arc-Reactor Screen Widget.
 *
 * Keeps a draggable, glowing Cyan Robotic Arc-Reactor ball overlaid on the screen
 * over all applications via SYSTEM_ALERT_WINDOW.
 * Tapping the floating ball triggers JARVIS continuous voice listening immediately!
 */
class FloatingOrbService : Service() {

    companion object {
        const val TAG = "FloatingOrbService"
        const val CHANNEL_ID = "jarvis_floating_orb_channel"
        const val NOTIFICATION_ID = 2002
        const val ACTION_START = "com.myassistant.app.action.START_ORB"
        const val ACTION_STOP = "com.myassistant.app.action.STOP_ORB"

        var isRunning = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, FloatingOrbService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingOrbService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private var windowManager: WindowManager? = null
    private var floatingContainer: FrameLayout? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        initFloatingView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Floating Screen Widget",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active Robotic Arc-Reactor Screen Overlay"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS Floating Orb Active")
            .setContentText("Tap floating ball on screen to speak with JARVIS")
            .setSmallIcon(android.R.drawable.ic_dialog_info) // Strict: zero unresolved resource errors
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initFloatingView() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val displayMetrics = DisplayMetrics()
        windowManager?.defaultDisplay?.getMetrics(displayMetrics)
        val screenWidth = displayMetrics.widthPixels

        val orbSizePx = (62 * resources.displayMetrics.density).toInt()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            orbSizePx,
            orbSizePx,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth - orbSizePx - (16 * resources.displayMetrics.density).toInt()
            y = (displayMetrics.heightPixels * 0.35).toInt()
        }

        floatingContainer = FrameLayout(this)
        val customOrbView = ArcReactorOrbView(this)
        floatingContainer?.addView(customOrbView)

        // Draggable Touch & Click Listener
        floatingContainer?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var touchStartTime = 0L

            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                if (event == null || params == null) return false

                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params!!.x
                        initialY = params!!.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        touchStartTime = System.currentTimeMillis()
                        v?.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        params!!.x = initialX + dx
                        params!!.y = initialY + dy
                        try {
                            windowManager?.updateViewLayout(floatingContainer, params)
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to update floating view position", e)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val moveX = Math.abs(event.rawX - initialTouchX)
                        val moveY = Math.abs(event.rawY - initialTouchY)
                        val touchDuration = System.currentTimeMillis() - touchStartTime

                        // Click detection: displacement < 15px within 350ms
                        if (moveX < 15 && moveY < 15 && touchDuration < 350) {
                            onFloatingOrbTapped()
                        }
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager?.addView(floatingContainer, params)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding floating orb to window manager", e)
        }
    }

    private fun onFloatingOrbTapped() {
        Log.i(TAG, "Floating Orb tapped! Initiating JARVIS Voice Receptors...")

        // 1. Trigger voice listening in foreground service
        JarvisVoiceForegroundService.startListening(this)

        // 2. Bring JARVIS HUD to foreground if needed
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra("EXTRA_START_LISTENING", true)
        }
        startActivity(launchIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        if (floatingContainer != null && windowManager != null) {
            try {
                windowManager?.removeView(floatingContainer)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing floating orb view", e)
            }
        }
    }

    /**
     * Programmatic Custom Arc-Reactor View
     * Draws glowing cyan rings, core triangle reactor, and subtle holographic aura
     */
    private class ArcReactorOrbView(context: Context) : View(context) {
        private val outerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = Color.parseColor("#00E5FF")
        }

        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            color = Color.parseColor("#06B6D4")
        }

        private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#00E5FF")
        }

        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.parseColor("#E6020617") // Deep dark cyan-black
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f
            val radius = (Math.min(width, height) / 2f) - 6f

            // Radial Glow Background
            val gradient = RadialGradient(
                cx, cy, radius,
                intArrayOf(Color.parseColor("#8000E5FF"), Color.parseColor("#1A002B36"), Color.TRANSPARENT),
                floatArrayOf(0.0f, 0.7f, 1.0f),
                Shader.TileMode.CLAMP
            )
            val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = gradient
            }
            canvas.drawCircle(cx, cy, radius + 4f, glowPaint)

            // Dark Center Disc
            canvas.drawCircle(cx, cy, radius, bgPaint)

            // Outer Arc Ring
            canvas.drawCircle(cx, cy, radius - 2f, ringPaint)
            canvas.drawCircle(cx, cy, radius - 7f, outerGlowPaint)

            // Core Arc Reactor Circle
            canvas.drawCircle(cx, cy, radius * 0.38f, corePaint)

            // Center White Arc Hotspot
            val hotspotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            canvas.drawCircle(cx, cy, radius * 0.18f, hotspotPaint)
        }
    }
}
