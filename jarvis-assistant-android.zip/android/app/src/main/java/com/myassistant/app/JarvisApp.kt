package com.myassistant.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class JarvisApp : Application() {

    companion object {
        const val VOICE_SERVICE_CHANNEL_ID = "JarvisVoiceForegroundChannel"
        const val ALERTS_CHANNEL_ID = "JarvisAlertsChannel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            // Channel 1: Foreground Voice Service
            val voiceChannel = NotificationChannel(
                VOICE_SERVICE_CHANNEL_ID,
                "J.A.R.V.I.S. Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps microphone receptors listening for hands-free commands"
                setShowBadge(false)
            }
            notificationManager?.createNotificationChannel(voiceChannel)

            // Channel 2: Alarms and Reminders
            val alertsChannel = NotificationChannel(
                ALERTS_CHANNEL_ID,
                "J.A.R.V.I.S. Reminders & Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifies when scheduled reminders and voice alarms elapse"
                enableVibration(true)
            }
            notificationManager?.createNotificationChannel(alertsChannel)
        }
    }
}
