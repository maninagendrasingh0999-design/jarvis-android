package com.myassistant.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.myassistant.app.services.JarvisAccessibilityService
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Autonomous Native Action Executor for JARVIS Assistant.
 *
 * Implements:
 * 1. Dynamic PackageManager search across ALL installed apps (Instagram, BGMI, Free Fire, Camera, etc.)
 * 2. 100% Hands-Free WhatsApp messaging with Accessibility Auto-Send (JarvisAccessibilityService)
 * 3. MacroDroid Automation Bridge (Simultaneous Broadcast Intent + Local HTTP Webhook + Deep-link)
 * 4. Automatic Contact Lookup from ContactsContract by Name
 * 5. Persistent Memory System stored in Android SharedPreferences
 * 6. Silent Alarm/Timer creation with EXTRA_SKIP_UI = true
 * 7. Hardware Flashlight and System Volume / Setting controls
 */
class ActionExecutor(private val context: Context) {

    companion object {
        const val TAG = "JarvisActionExecutor"
        const val MACRODROID_BROADCAST_ACTION = "com.myassistant.app.JARVIS_COMMAND"
        const val PREFS_MEMORY = "jarvis_permanent_memory"
        const val PREFS_SETTINGS = "jarvis_settings"
    }

    private val cameraManager by lazy { context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager }
    private val audioManager by lazy { context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager }
    private var cameraId: String? = null

    init {
        try {
            cameraId = cameraManager?.cameraIdList?.firstOrNull()
        } catch (e: Exception) {
            Log.w(TAG, "Error obtaining Camera ID", e)
        }
    }

    /**
     * Executes structured JSON action received from Web HUD or Gemini Engine
     */
    fun execute(actionJson: String): Boolean {
        try {
            val json = JSONObject(actionJson)
            val type = json.optString("type").uppercase()
            val params = json.optJSONObject("params") ?: json.optJSONObject("payload") ?: JSONObject()

            Log.i(TAG, "Executing autonomous action: $type with params: $params")

            return when (type) {
                "OPEN_APP" -> {
                    val appName = params.optString("appName", params.optString("query"))
                    val pkgName = params.optString("packageName")
                    openAppByNameOrPackage(appName, pkgName)
                }
                "YOUTUBE_SEARCH_PLAY", "OPEN_YOUTUBE" -> {
                    val query = params.optString("query")
                    openYouTube(query)
                }
                "WHATSAPP_SEND", "SEND_WHATSAPP" -> {
                    val recipient = params.optString("recipientName", params.optString("contactName"))
                    val phone = params.optString("phoneNumber")
                    val message = params.optString("messageText", params.optString("message"))
                    sendWhatsApp(recipient, phone, message)
                }
                "MAKE_CALL", "CALL_PHONE" -> {
                    val target = params.optString("phoneNumberOrName", params.optString("phoneNumber"))
                    makeCall(target)
                }
                "SET_ALARM" -> {
                    val msg = params.optString("message", "JARVIS Alarm")
                    val hour = params.optInt("hour", -1)
                    val minutes = params.optInt("minutes", -1)
                    val minutesFromNow = params.optInt("minutesFromNow", 0)
                    val skipUi = params.optBoolean("skipUi", true)
                    setAlarm(msg, hour, minutes, minutesFromNow, skipUi)
                }
                "SET_TIMER" -> {
                    val seconds = params.optInt("seconds", 60)
                    val msg = params.optString("message", "JARVIS Timer")
                    val skipUi = params.optBoolean("skipUi", true)
                    setTimer(seconds, msg, skipUi)
                }
                "TOGGLE_TORCH", "TORCH_CONTROL" -> {
                    val state = params.optString("state", params.optString("torchState", "toggle"))
                    toggleTorch(state)
                }
                "SYSTEM_SETTING", "OPEN_SETTINGS" -> {
                    val setting = params.optString("setting", "general")
                    val volumeAction = params.optString("volumeAction")
                    val volumeLevel = params.optInt("volumeLevel", -1)
                    handleSystemSetting(setting, volumeAction, volumeLevel)
                }
                "GOOGLE_SEARCH" -> {
                    val query = params.optString("query")
                    googleSearch(query)
                }
                "OPEN_URL" -> {
                    val url = params.optString("url")
                    openUrl(url)
                }
                "OPEN_MAPS" -> {
                    val destination = params.optString("destination", params.optString("query"))
                    openMaps(destination)
                }
                "GLOBAL_ACTION" -> {
                    val action = params.optString("action", "home")
                    performGlobalAction(action)
                }
                else -> {
                    Log.w(TAG, "Unknown action type: $type")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse and execute action: $actionJson", e)
            return false
        }
    }

    /**
     * MacroDroid Automation Bridge:
     * Fires Broadcast Intent AND local HTTP webhook simultaneously so external macro triggers work everywhere
     */
    fun triggerMacroDroidBridge(command: String, target: String, message: String) {
        // 1. Native Android Broadcast Intent
        try {
            val broadcastIntent = Intent(MACRODROID_BROADCAST_ACTION).apply {
                putExtra("command", command)
                putExtra("target", target)
                putExtra("message", message)
            }
            context.sendBroadcast(broadcastIntent)
            Log.d(TAG, "MacroDroid broadcast dispatched: $command | target: $target")
        } catch (e: Exception) {
            Log.w(TAG, "MacroDroid broadcast error", e)
        }

        // 2. Local MacroDroid HTTP Webhook in background thread (port 8080)
        Thread {
            try {
                val encCmd = URLEncoder.encode(command, "UTF-8")
                val encTarget = URLEncoder.encode(target, "UTF-8")
                val encMsg = URLEncoder.encode(message, "UTF-8")
                val webhookUrl = "http://127.0.0.1:8080/jarvis?cmd=$encCmd&target=$encTarget&msg=$encMsg"
                val url = URL(webhookUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 800
                conn.readTimeout = 800
                conn.requestMethod = "GET"
                conn.responseCode
                conn.disconnect()
            } catch (e: Exception) {
                // MacroDroid webhook may not be listening if MacroDroid is not installed; ignore silently
            }
        }.start()
    }

    /**
     * Dynamically searches ALL installed applications on the phone by label and launches
     */
    fun openAppByNameOrPackage(appName: String, explicitPackage: String? = null): Boolean {
        triggerMacroDroidBridge("OPEN_APP", appName, "")
        val pm = context.packageManager

        if (!explicitPackage.isNullOrBlank()) {
            val launchIntent = pm.getLaunchIntentForPackage(explicitPackage)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                Toast.makeText(context, "Opening $appName...", Toast.LENGTH_SHORT).show()
                return true
            }
        }

        val cleanQuery = appName.trim().lowercase()
        if (cleanQuery.isBlank()) return false

        val knownPackages = mapOf(
            "instagram" to "com.instagram.android",
            "whatsapp" to "com.whatsapp",
            "youtube" to "com.google.android.youtube",
            "free fire" to "com.dts.freefireth",
            "free fire max" to "com.dts.freefiremax",
            "bgmi" to "com.pubg.imobile",
            "battlegrounds" to "com.pubg.imobile",
            "pubg" to "com.tencent.ig",
            "chrome" to "com.android.chrome",
            "camera" to "com.android.camera",
            "calculator" to "com.google.android.calculator",
            "settings" to "com.android.settings",
            "spotify" to "com.spotify.music",
            "telegram" to "org.telegram.messenger",
            "snapchat" to "com.snapchat.android",
            "facebook" to "com.facebook.katana",
            "twitter" to "com.twitter.android",
            "x" to "com.twitter.android",
            "netflix" to "com.netflix.mediaclient",
            "hotstar" to "in.startv.hotstar",
            "jiocinema" to "com.jio.media.ondemand",
            "amazon" to "in.amazon.mShop.android.shopping",
            "flipkart" to "com.flipkart.android",
            "paytm" to "net.one97.paytm",
            "phonepe" to "com.phonepe.app",
            "gpay" to "com.google.android.apps.nbu.paisa.user",
            "google pay" to "com.google.android.apps.nbu.paisa.user",
            "clock" to "com.google.android.deskclock",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "photos" to "com.google.android.apps.photos",
            "gallery" to "com.android.gallery3d"
        )

        val directPkg = knownPackages[cleanQuery]
        if (directPkg != null) {
            val intent = pm.getLaunchIntentForPackage(directPkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                Toast.makeText(context, "Launching $appName...", Toast.LENGTH_SHORT).show()
                return true
            }
        }

        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val installedApps = pm.queryIntentActivities(mainIntent, 0)

            // Exact match on label
            val exactMatch = installedApps.firstOrNull {
                it.loadLabel(pm).toString().trim().lowercase() == cleanQuery
            }
            if (exactMatch != null) {
                val intent = pm.getLaunchIntentForPackage(exactMatch.activityInfo.packageName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent != null) {
                    context.startActivity(intent)
                    Toast.makeText(context, "Opening ${exactMatch.loadLabel(pm)}...", Toast.LENGTH_SHORT).show()
                    return true
                }
            }

            // Substring match on label or package
            val fuzzyMatch = installedApps.firstOrNull {
                val label = it.loadLabel(pm).toString().trim().lowercase()
                val pkg = it.activityInfo.packageName.lowercase()
                label.contains(cleanQuery) || pkg.contains(cleanQuery)
            }
            if (fuzzyMatch != null) {
                val intent = pm.getLaunchIntentForPackage(fuzzyMatch.activityInfo.packageName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent != null) {
                    context.startActivity(intent)
                    Toast.makeText(context, "Opening ${fuzzyMatch.loadLabel(pm)}...", Toast.LENGTH_SHORT).show()
                    return true
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error searching installed apps", e)
        }

        // Fallback: Google Play Store
        return try {
            val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${Uri.encode(appName)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(storeIntent)
            Toast.makeText(context, "App not found locally. Searching Play Store for $appName...", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=${Uri.encode(appName)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
            true
        }
    }

    /**
     * Directly opens YouTube app with search or video query
     */
    fun openYouTube(query: String?): Boolean {
        val cleanQuery = query?.trim() ?: ""
        triggerMacroDroidBridge("YOUTUBE", cleanQuery, "")

        val intent = if (cleanQuery.isNotBlank()) {
            Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", cleanQuery)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
                setPackage("com.google.android.youtube")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }

        return try {
            context.startActivity(intent)
            Toast.makeText(context, if (cleanQuery.isNotBlank()) "Searching YouTube for: $cleanQuery" else "Opening YouTube...", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            val webUrl = if (cleanQuery.isNotBlank()) "https://www.youtube.com/results?search_query=${Uri.encode(cleanQuery)}" else "https://www.youtube.com"
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
            true
        }
    }

    /**
     * 100% Hands-Free WhatsApp messaging with Accessibility Auto-Send & Contact Resolution
     */
    fun sendWhatsApp(contactName: String?, phoneNumber: String?, messageText: String?): Boolean {
        val cleanMsg = messageText?.trim() ?: ""
        triggerMacroDroidBridge("WHATSAPP_SEND", contactName ?: phoneNumber ?: "", cleanMsg)

        // 1. Prime Accessibility Service for 100% hands-free automatic click
        JarvisAccessibilityService.triggerWhatsAppAutoSend()

        val encodedMsg = try {
            URLEncoder.encode(cleanMsg, "UTF-8")
        } catch (e: Exception) {
            cleanMsg
        }

        // Automatic Contact Lookup from ContactsContract if name provided
        val resolvedPhone = if (!phoneNumber.isNullOrBlank()) {
            phoneNumber.replace("[^0-9+]".toRegex(), "")
        } else if (!contactName.isNullOrBlank()) {
            findContactPhoneNumber(contactName)
        } else null

        val uriString = if (!resolvedPhone.isNullOrBlank()) {
            "https://api.whatsapp.com/send?phone=$resolvedPhone&text=$encodedMsg"
        } else {
            "https://api.whatsapp.com/send?text=$encodedMsg"
        }

        val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
            setPackage("com.whatsapp")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(waIntent)
            Toast.makeText(context, "Opening WhatsApp & Sending...", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            val genericIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(genericIntent)
            true
        }
    }

    /**
     * Direct Phone Call / Contact Lookup
     */
    fun makeCall(phoneNumberOrName: String?): Boolean {
        val target = phoneNumberOrName?.trim() ?: ""
        triggerMacroDroidBridge("CALL", target, "")

        if (target.isBlank()) {
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(dialIntent)
            return true
        }

        val resolvedNumber = if (target.matches("^[+0-9\\s-]+$".toRegex())) {
            target.replace("\\s".toRegex(), "")
        } else {
            findContactPhoneNumber(target) ?: target
        }

        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$resolvedNumber")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return try {
            context.startActivity(dialIntent)
            Toast.makeText(context, "Calling $target ($resolvedNumber)...", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error dialing phone", e)
            false
        }
    }

    /**
     * Sets alarm silently without needing confirmation tap (EXTRA_SKIP_UI = true)
     */
    fun setAlarm(message: String, hour: Int, minutes: Int, minutesFromNow: Int, skipUi: Boolean): Boolean {
        triggerMacroDroidBridge("ALARM", message, "$hour:$minutes")
        val calendar = java.util.Calendar.getInstance()
        if (hour >= 0 && minutes >= 0) {
            calendar.set(java.util.Calendar.HOUR_OF_DAY, hour)
            calendar.set(java.util.Calendar.MINUTE, minutes)
        } else {
            val offset = if (minutesFromNow > 0) minutesFromNow else 5
            calendar.add(java.util.Calendar.MINUTE, offset)
        }

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_MESSAGE, message.ifBlank { "JARVIS Alarm" })
            putExtra(AlarmClock.EXTRA_HOUR, calendar.get(java.util.Calendar.HOUR_OF_DAY))
            putExtra(AlarmClock.EXTRA_MINUTES, calendar.get(java.util.Calendar.MINUTE))
            putExtra(AlarmClock.EXTRA_SKIP_UI, skipUi)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            val h = calendar.get(java.util.Calendar.HOUR_OF_DAY)
            val m = calendar.get(java.util.Calendar.MINUTE)
            val timeStr = String.format("%02d:%02d", h, m)
            Toast.makeText(context, "Alarm set silently for $timeStr: $message", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error setting alarm", e)
            false
        }
    }

    /**
     * Sets timer silently (EXTRA_SKIP_UI = true)
     */
    fun setTimer(seconds: Int, message: String, skipUi: Boolean): Boolean {
        triggerMacroDroidBridge("TIMER", message, "$seconds")
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, if (seconds > 0) seconds else 60)
            putExtra(AlarmClock.EXTRA_MESSAGE, message.ifBlank { "JARVIS Timer" })
            putExtra(AlarmClock.EXTRA_SKIP_UI, skipUi)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return try {
            context.startActivity(intent)
            Toast.makeText(context, "Timer set for ${seconds}s: $message", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error setting timer", e)
            false
        }
    }

    /**
     * Toggles flashlight hardware
     */
    fun toggleTorch(state: String): Boolean {
        val turnOn = when (state.lowercase()) {
            "on" -> true
            "off" -> false
            else -> true
        }
        triggerMacroDroidBridge(if (turnOn) "TORCH_ON" else "TORCH_OFF", "", "")

        return try {
            val camId = cameraId ?: cameraManager?.cameraIdList?.firstOrNull() ?: return false
            cameraManager?.setTorchMode(camId, turnOn)
            Toast.makeText(context, "Flashlight ${if (turnOn) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Flashlight error", e)
            false
        }
    }

    /**
     * Handles system settings and volume controls
     */
    fun handleSystemSetting(setting: String, volumeAction: String?, volumeLevel: Int): Boolean {
        triggerMacroDroidBridge("SETTING", setting, volumeAction ?: "$volumeLevel")

        if (!volumeAction.isNullOrBlank() || volumeLevel >= 0) {
            audioManager?.let { am ->
                when (volumeAction?.lowercase()) {
                    "up", "raise" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down", "lower" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "mute" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    else -> {
                        if (volumeLevel in 0..100) {
                            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            val target = (volumeLevel * max) / 100
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
                        }
                    }
                }
                Toast.makeText(context, "Volume adjusted", Toast.LENGTH_SHORT).show()
                return true
            }
        }

        val intent = when (setting.lowercase()) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "hotspot", "tethering" -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            "location", "gps" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "sound", "volume" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "display", "brightness" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            Toast.makeText(context, "Opening ${setting.uppercase()} Settings...", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error opening settings", e)
            false
        }
    }

    fun googleSearch(query: String?): Boolean {
        val cleanQuery = query?.trim() ?: ""
        val url = if (cleanQuery.isNotBlank()) "https://www.google.com/search?q=${Uri.encode(cleanQuery)}" else "https://www.google.com"
        return openUrl(url)
    }

    fun openUrl(url: String?): Boolean {
        val cleanUrl = url?.trim() ?: "https://www.google.com"
        val fullUrl = if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) "https://$cleanUrl" else cleanUrl
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error opening URL: $fullUrl", e)
            false
        }
    }

    fun openMaps(destination: String?): Boolean {
        val dest = destination?.trim() ?: ""
        val uri = if (dest.isNotBlank()) Uri.parse("geo:0,0?q=${Uri.encode(dest)}") else Uri.parse("geo:0,0")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.google.android.apps.maps")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return try {
            context.startActivity(intent)
            Toast.makeText(context, "Opening Google Maps for: $dest", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            val webUrl = "https://maps.google.com/?q=${Uri.encode(dest)}"
            openUrl(webUrl)
        }
    }

    fun performGlobalAction(action: String): Boolean {
        val service = JarvisAccessibilityService.instance
        if (service != null) {
            return service.performGlobalGesture(action)
        }
        Toast.makeText(context, "Enable JARVIS Accessibility in Android Settings for Global Gestures", Toast.LENGTH_LONG).show()
        return false
    }

    // ==========================================
    // Permanent Memory System (SharedPreferences)
    // ==========================================

    fun savePermanentMemory(key: String, value: String) {
        val prefs = context.getSharedPreferences(PREFS_MEMORY, Context.MODE_PRIVATE)
        prefs.edit().putString(key, value).apply()
        Log.i(TAG, "Permanent memory saved: $key = $value")
    }

    fun getPermanentMemory(key: String): String? {
        val prefs = context.getSharedPreferences(PREFS_MEMORY, Context.MODE_PRIVATE)
        return prefs.getString(key, null)
    }

    fun getAllPermanentMemories(): String {
        val prefs = context.getSharedPreferences(PREFS_MEMORY, Context.MODE_PRIVATE)
        val all = prefs.all
        val json = JSONObject()
        for ((k, v) in all) {
            json.put(k, v)
        }
        return json.toString()
    }

    // ==========================================
    // Gemini API Key Persistence
    // ==========================================

    fun saveGeminiApiKey(key: String) {
        val prefs = context.getSharedPreferences(PREFS_SETTINGS, Context.MODE_PRIVATE)
        prefs.edit().putString("gemini_api_key", key).apply()
    }

    fun getGeminiApiKey(): String? {
        val prefs = context.getSharedPreferences(PREFS_SETTINGS, Context.MODE_PRIVATE)
        val key = prefs.getString("gemini_api_key", null)
        return if (!key.isNullOrBlank()) key else "AIzaSyDNKMF5hhri9fvpU7DSgHyFKB7rdkxKaTI"
    }

    /**
     * Resolves contact phone number by name from Android ContactsContract
     */
    private fun findContactPhoneNumber(name: String): String? {
        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        var phoneNumber: String? = null
        try {
            val cursor: Cursor? = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"),
                null
            )
            cursor?.use {
                if (it.moveToFirst()) {
                    val index = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (index != -1) {
                        phoneNumber = it.getString(index)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not resolve contact phone", e)
        }
        return phoneNumber
    }
}
