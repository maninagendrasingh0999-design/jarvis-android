package com.myassistant.app.services

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Autonomous Accessibility Service for JARVIS Assistant.
 *
 * Provides:
 * 1. 100% Hands-Free WhatsApp Auto-Send:
 *    Automatically detects pre-filled message conversations and clicks WhatsApp's Send button
 *    (viewId: com.whatsapp:id/send, or contentDescription: "Send" / "भेजें").
 * 2. System Global Navigation Controls:
 *    Executes Home, Back, Recents, Notifications, and Lock Screen actions upon voice command.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        const val TAG = "JarvisAccessibility"
        var instance: JarvisAccessibilityService? = null
            private set

        @Volatile
        var isAutoSendWhatsAppPending = false

        fun triggerWhatsAppAutoSend() {
            isAutoSendWhatsAppPending = true
            Log.d(TAG, "WhatsApp autonomous auto-send primed")
            // Timeout after 8 seconds if WhatsApp fails to open
            Handler(Looper.getMainLooper()).postDelayed({
                isAutoSendWhatsAppPending = false
            }, 8000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "JarvisAccessibilityService connected and ready")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkgName = event.packageName?.toString() ?: ""
        if ((pkgName == "com.whatsapp" || pkgName == "com.whatsapp.w4b") && isAutoSendWhatsAppPending) {
            handleWhatsAppSendButton()
        }
    }

    private fun handleWhatsAppSendButton() {
        val rootNode = rootInActiveWindow ?: return

        try {
            // 1. Try finding by resource ID: com.whatsapp:id/send
            val sendNodesById = rootNode.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")
            if (!sendNodesById.isNullOrEmpty()) {
                val sendButton = sendNodesById.firstOrNull { it.isClickable || it.parent?.isClickable == true }
                if (sendButton != null) {
                    val clicked = if (sendButton.isClickable) {
                        sendButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    } else {
                        sendButton.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
                    }
                    if (clicked) {
                        isAutoSendWhatsAppPending = false
                        Toast.makeText(this, "JARVIS: WhatsApp message sent autonomously!", Toast.LENGTH_SHORT).show()
                        Log.i(TAG, "WhatsApp Send clicked via resource ID")
                        return
                    }
                }
            }

            // 2. Try finding by content description ("Send" or "भेजें")
            val sendByText = rootNode.findAccessibilityNodeInfosByText("Send")
            if (!sendByText.isNullOrEmpty()) {
                val button = sendByText.firstOrNull { it.isClickable || it.parent?.isClickable == true }
                if (button != null) {
                    val clicked = if (button.isClickable) {
                        button.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    } else {
                        button.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
                    }
                    if (clicked) {
                        isAutoSendWhatsAppPending = false
                        Toast.makeText(this, "JARVIS: WhatsApp message sent autonomously!", Toast.LENGTH_SHORT).show()
                        Log.i(TAG, "WhatsApp Send clicked via content text")
                        return
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in WhatsApp auto-send", e)
        } finally {
            rootNode.recycle()
        }
    }

    /**
     * Executes global system navigation gestures
     */
    fun performGlobalGesture(action: String): Boolean {
        return when (action.lowercase()) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents", "overview" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "lock", "lockscreen" -> performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            else -> false
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "JarvisAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        isAutoSendWhatsAppPending = false
        Log.d(TAG, "JarvisAccessibilityService destroyed")
    }
}
