package com.myassistant.app.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Native Android Microphone Foreground Service for JARVIS Assistant (com.myassistant.app).
 *
 * Implements Android 14+ (API 34) FOREGROUND_SERVICE_TYPE_MICROPHONE requirements:
 * 1. Persistent ongoing notification with visible mic indicator and STOP action.
 * 2. True Continuous Listening: Immediately restarts on speech timeouts and silence.
 * 3. 24/7 Background Execution: Holds a PARTIAL_WAKE_LOCK and uses START_STICKY.
 * 4. Wake Phrase Detection: "Hallo Javed" -> Activates conversation with "Ji, main sun rahi hoon. Bataiye, kya karna hai?".
 * 5. Standby Mode: "Javed shutdown ho jao", "Shutdown ho jao", "Band ho jao" -> returns to standby while preserving wake-word detection!
 * 6. Full Shutdown only upon explicit user stop action.
 */
class JarvisVoiceForegroundService : Service(), RecognitionListener {

    companion object {
        const val TAG = "JarvisVoiceService"
        const val CHANNEL_ID = "JarvisVoiceForegroundChannel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_LISTENING = "com.myassistant.app.action.START_LISTENING"
        const val ACTION_STOP_LISTENING = "com.myassistant.app.action.STOP_LISTENING"
        const val ACTION_STANDBY = "com.myassistant.app.action.STANDBY"
        const val ACTION_COMMAND_RECEIVED = "com.myassistant.app.action.COMMAND_RECEIVED"
        const val EXTRA_TRANSCRIPT = "extra_transcript"

        fun startListening(context: Context) {
            val intent = Intent(context, JarvisVoiceForegroundService::class.java).apply {
                action = ACTION_START_LISTENING
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopListening(context: Context) {
            val intent = Intent(context, JarvisVoiceForegroundService::class.java).apply {
                action = ACTION_STOP_LISTENING
            }
            context.startService(intent)
        }

        fun enterStandby(context: Context) {
            val intent = Intent(context, JarvisVoiceForegroundService::class.java).apply {
                action = ACTION_STANDBY
            }
            context.startService(intent)
        }
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var isListening = false
    private var isStandbyMode = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        initSpeechRecognizer()

        // 24/7 Background Operation: Acquire PARTIAL_WAKE_LOCK to prevent deep sleep CPU throttling
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "JarvisAssistant::VoiceWakeLock")?.apply {
                setReferenceCounted(false)
                acquire()
            }
            Log.d(TAG, "PARTIAL_WAKE_LOCK acquired for 24/7 background continuous listening")
        } catch (e: Exception) {
            Log.w(TAG, "Could not acquire PARTIAL_WAKE_LOCK", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_LISTENING -> {
                Log.d(TAG, "Explicit stop requested by user action")
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STANDBY -> {
                isStandbyMode = true
                startWithForegroundNotification("JARVIS Standby (Listening for 'Hallo Javed')")
                startListeningSession()
            }
            ACTION_START_LISTENING, null -> {
                isStandbyMode = false
                startWithForegroundNotification("JARVIS Assistant Active & Listening")
                startListeningSession()
            }
        }
        // Ensure service automatically restarts if killed by OS memory pressure
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
                setRecognitionListener(this@JarvisVoiceForegroundService)
            }
        } else {
            Log.e(TAG, "SpeechRecognizer is not available on this device")
        }
    }

    private fun startListeningSession() {
        if (isListening) return

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            // Generous continuous pause tolerance
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 15000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
        }

        try {
            speechRecognizer?.startListening(recognizerIntent)
            isListening = true
            val status = if (isStandbyMode) "Standby: Say 'Hallo Javed' to wake..." else "Listening (Hindi, Hinglish, English)..."
            updateNotification(status)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start native speech recognizer", e)
            isListening = false
            // Retry quickly
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                startListeningSession()
            }, 500L)
        }
    }

    private fun startWithForegroundNotification(statusText: String) {
        val notification = createNotification(statusText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(statusText: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, createNotification(statusText))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "JARVIS Assistant Voice Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps microphone active for hands-free 'Hallo Javed' wake word and voice commands"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun createNotification(text: String): Notification {
        val stopIntent = Intent(this, JarvisVoiceForegroundService::class.java).apply {
            action = ACTION_STOP_LISTENING
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            0,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("JARVIS Assistant")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP LISTENING", stopPendingIntent)
            .build()
    }

    // RecognitionListener Callbacks
    override fun onReadyForSpeech(params: Bundle?) {
        isListening = true
    }

    override fun onBeginningOfSpeech() {
        updateNotification("Processing vocal frequencies...")
    }

    override fun onRmsChanged(rmsdB: Float) {}

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        isListening = false
    }

    override fun onError(error: Int) {
        isListening = false
        Log.w(TAG, "SpeechRecognizer error code: $error")

        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            Log.e(TAG, "Microphone permission denied by Android OS")
            updateNotification("Microphone permission required")
            stopSelf()
            return
        }

        // True Continuous Listening: Immediately restart listening on any timeout/silence/no-match without stopping
        // Handles ERROR_NO_MATCH (7), ERROR_SPEECH_TIMEOUT (6), ERROR_NETWORK_TIMEOUT (1), etc.
        val delay = if (isStandbyMode) 300L else 150L
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            startListeningSession()
        }, delay)
    }

    override fun onResults(results: Bundle?) {
        isListening = false
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val finalTranscript = matches?.firstOrNull()?.trim()

        if (!finalTranscript.isNullOrBlank()) {
            Log.i(TAG, "Recognized command: $finalTranscript")
            val lower = finalTranscript.lowercase()

            val isWakeWord = lower == "hallo javed" ||
                    lower == "hello javed" ||
                    lower == "halo javed" ||
                    lower == "hey javed" ||
                    lower == "javed" ||
                    lower.startsWith("hallo javed") ||
                    lower.startsWith("hello javed")

            val isShutdownCommand = lower.contains("shutdown ho jao") ||
                    lower.contains("javed shutdown") ||
                    lower.contains("band ho jao") ||
                    lower.contains("javed band ho jao") ||
                    lower.contains("band hojao") ||
                    lower.contains("shutdown") ||
                    lower.contains("shut down") ||
                    lower.contains("stop listening") ||
                    lower.contains("ruk jao") ||
                    lower.contains("बंद हो जाओ")

            if (isWakeWord) {
                // Wake from standby into active conversation
                isStandbyMode = false
                updateNotification("Active: Ji, main sun rahi hoon. Bataiye, kya karna hai?")
            } else if (isShutdownCommand) {
                // Return to standby while PRESERVING wake-word detection (do NOT stop service)
                isStandbyMode = true
                updateNotification("JARVIS Standby (Listening for 'Hallo Javed')")
            } else {
                updateNotification("Executed: \"$finalTranscript\"")
            }

            // Broadcast recognized command to Stark Action Executor & App Activity
            val broadcastIntent = Intent(ACTION_COMMAND_RECEIVED).apply {
                putExtra(EXTRA_TRANSCRIPT, finalTranscript)
                setPackage(packageName)
            }
            sendBroadcast(broadcastIntent)
        }

        // True Continuous Listening: Restart listening session immediately
        val restartDelay = if (isStandbyMode) 500L else 200L
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            startListeningSession()
        }, restartDelay)
    }

    override fun onPartialResults(partialResults: Bundle?) {
        val partials = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val partialText = partials?.firstOrNull()
        if (!partialText.isNullOrBlank()) {
            updateNotification("Hearing: $partialText...")
        }
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}

    override fun onDestroy() {
        super.onDestroy()
        isListening = false
        speechRecognizer?.apply {
            stopListening()
            cancel()
            destroy()
        }
        speechRecognizer = null

        // Safely release wake lock
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
                Log.d(TAG, "PARTIAL_WAKE_LOCK released cleanly")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error releasing wakeLock", e)
        }
        wakeLock = null

        Log.d(TAG, "JarvisVoiceForegroundService destroyed cleanly")
    }
}
