package com.myassistant.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.Cursor
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.myassistant.app.bridge.StarkAndroidBridge
import com.myassistant.app.services.FloatingOrbService
import com.myassistant.app.services.JarvisVoiceForegroundService
import java.net.URLEncoder
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    companion object {
        const val TAG = "JarvisMainActivity"
        // Standalone offline bundled assets URL: Eliminates Google OAuth 403 Disallowed Useragent completely!
        const val LOCAL_ASSET_URL = "file:///android_asset/index.html"
    }

    val actionExecutor by lazy { ActionExecutor(this) }
    private lateinit var webView: WebView
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var isTorchOn = false
    private var cameraManager: CameraManager? = null
    private var cameraId: String? = null

    // Multi-permission request contract
    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        val callPhoneGranted = permissions[Manifest.permission.CALL_PHONE] ?: false
        val readContactsGranted = permissions[Manifest.permission.READ_CONTACTS] ?: false
        Log.i(TAG, "Permissions updated: Audio=$recordAudioGranted, Call=$callPhoneGranted, Contacts=$readContactsGranted")

        if (recordAudioGranted) {
            // Automatically launch persistent listening service once permission is granted
            startMicrophoneForegroundService()
        }
    }

    // Broadcast receiver for commands coming from background service
    private val voiceCommandReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == JarvisVoiceForegroundService.ACTION_COMMAND_RECEIVED) {
                val transcript = intent.getStringExtra(JarvisVoiceForegroundService.EXTRA_TRANSCRIPT)
                if (!transcript.isNullOrBlank()) {
                    dispatchVoiceCommandToHUD(transcript)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initHardwareManagers()
        initTextToSpeech()
        initWebView()
        requestRuntimePermissions()
        registerVoiceCommandReceiver()

        if (intent?.getBooleanExtra("EXTRA_START_LISTENING", false) == true) {
            JarvisVoiceForegroundService.startListening(this)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("EXTRA_START_LISTENING", false) == true) {
            JarvisVoiceForegroundService.startListening(this)
            webView.evaluateJavascript("if (typeof window.triggerJarvisListening === 'function') window.triggerJarvisListening();", null)
        }
    }

    fun canDrawOverlays(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            ).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
        }
    }

    fun toggleFloatingOrb(enable: Boolean): Boolean {
        return if (enable) {
            if (canDrawOverlays()) {
                FloatingOrbService.start(this)
                true
            } else {
                requestOverlayPermission()
                false
            }
        } else {
            FloatingOrbService.stop(this)
            true
        }
    }

    private fun initHardwareManagers() {
        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            cameraId = cameraManager?.cameraIdList?.firstOrNull()
        } catch (e: Exception) {
            Log.w(TAG, "Could not obtain Camera ID for flashlight control", e)
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            textToSpeech?.apply {
                setPitch(1.05f)
                setSpeechRate(1.0f)

                // Select female voice profile if available
                val availableVoices = voices
                val femaleVoice = availableVoices?.firstOrNull { voice ->
                    val name = voice.name.lowercase()
                    !voice.isNetworkConnectionRequired && (name.contains("female") || name.contains("f0") || name.contains("en-in") || name.contains("hi-in"))
                }
                if (femaleVoice != null) {
                    voice = femaleVoice
                }

                // Continuous Listening Loop: When TTS finishes speaking, immediately resume listening!
                setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        Log.d(TAG, "TTS vocalization started: $utteranceId")
                    }

                    override fun onDone(utteranceId: String?) {
                        Log.d(TAG, "TTS vocalization completed. Automatically restarting listening session...")
                        runOnUiThread {
                            // Resume foreground listening service immediately without user tap
                            JarvisVoiceForegroundService.startListening(this@MainActivity)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        Log.w(TAG, "TTS vocalization error on $utteranceId")
                        runOnUiThread {
                            JarvisVoiceForegroundService.startListening(this@MainActivity)
                        }
                    }
                })
            }
        } else {
            Log.e(TAG, "Native TextToSpeech initialization failed")
        }
    }

    private fun initWebView() {
        webView = findViewById(R.id.jarvisWebView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        // Bridge JavaScript <-> Native Android (Supported as JarvisAndroid, AndroidBridge and JarvisNative)
        val bridge = StarkAndroidBridge(this)
        webView.addJavascriptInterface(bridge, "JarvisAndroid")
        webView.addJavascriptInterface(bridge, "AndroidBridge")
        webView.addJavascriptInterface(bridge, "JarvisNative")

        // Handle Web Audio capture permissions transparently
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.let {
                    val requestedResources = it.resources
                    for (resource in requestedResources) {
                        if (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                            it.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                            return
                        }
                    }
                    it.deny()
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                Log.d(TAG, "JARVIS HUD loaded: $url")
            }
        }

        // Fix Google 403 Login Block: Load bundled local assets directly!
        // This guarantees instant startup, full offline capability, and avoids Google OAuth 403 disallowed_useragent!
        webView.loadUrl(LOCAL_ASSET_URL)
    }

    private fun requestRuntimePermissions() {
        val permissionsToRequest = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val missingPermissions = permissionsToRequest.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isNotEmpty()) {
            requestPermissionsLauncher.launch(missingPermissions.toTypedArray())
        }
    }

    private fun registerVoiceCommandReceiver() {
        val filter = IntentFilter(JarvisVoiceForegroundService.ACTION_COMMAND_RECEIVED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(voiceCommandReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(voiceCommandReceiver, filter)
        }
    }

    // ==========================================
    // Real Phone Controls & Instant Direct Intents
    // ==========================================

    /**
     * Direct WhatsApp Messaging:
     * Immediately triggers native WhatsApp conversation without requiring clickable links.
     */
    fun sendWhatsAppMessage(contactName: String, messageText: String) {
        val resolvedPhone = findContactPhoneNumber(contactName)
        val encodedMessage = try {
            URLEncoder.encode(messageText, "UTF-8")
        } catch (e: Exception) {
            messageText
        }

        val uriString = if (!resolvedPhone.isNullOrBlank()) {
            val cleanPhone = resolvedPhone.replace("[^0-9+]".toRegex(), "")
            "https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage"
        } else {
            "https://api.whatsapp.com/send?text=$encodedMessage"
        }

        val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
            setPackage("com.whatsapp")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        try {
            startActivity(waIntent)
            Toast.makeText(this, "Opening WhatsApp for $contactName...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            val genericIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uriString)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(genericIntent)
        }
    }

    /**
     * Resolves contact phone number by name from Android ContactsContract
     */
    private fun findContactPhoneNumber(name: String): String? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }

        var phoneNumber: String? = null
        val cursor: Cursor? = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )

        cursor?.use {
            if (it.moveToFirst()) {
                val index = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (index != -1) {
                    phoneNumber = it.getString(index)
                }
            }
        }
        return phoneNumber
    }

    /**
     * Direct Phone Call / Dialer Launch:
     * Immediately launches dialer or call without confirmation dialogs.
     */
    fun callContactOrPhone(phoneNumberOrName: String) {
        val resolvedNumber = if (phoneNumberOrName.matches("^[+0-9\\s-]+$".toRegex())) {
            phoneNumberOrName.replace("\\s".toRegex(), "")
        } else {
            findContactPhoneNumber(phoneNumberOrName) ?: phoneNumberOrName
        }

        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$resolvedNumber")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(dialIntent)
            Toast.makeText(this, "Opening dialer for $phoneNumberOrName...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Log.e(TAG, "Error opening dialer", e)
        }
    }

    /**
     * Direct Flashlight toggle:
     * Toggles phone hardware flashlight LED via CameraManager.
     */
    fun toggleFlashlight(enabled: Boolean) {
        try {
            val camId = cameraId ?: cameraManager?.cameraIdList?.firstOrNull()
            if (camId != null) {
                cameraManager?.setTorchMode(camId, enabled)
                isTorchOn = enabled
                Toast.makeText(this, "Torch ${if (enabled) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting flashlight torch mode", e)
            Toast.makeText(this, "Camera torch error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Direct YouTube Launch:
     * Immediately opens YouTube or video search with FLAG_ACTIVITY_NEW_TASK.
     */
    fun launchYouTube(query: String) {
        val intent = if (query.isNotBlank()) {
            Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", query)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:")).apply {
                setPackage("com.google.android.youtube")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }

        try {
            startActivity(intent)
            Toast.makeText(this, "Launching YouTube...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            val webUrl = if (query.isNotBlank()) "https://www.youtube.com/results?search_query=${Uri.encode(query)}" else "https://www.youtube.com"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }
    }

    /**
     * Direct Google Maps Launch:
     */
    fun launchMaps(destination: String) {
        val geoUri = if (destination.isNotBlank()) {
            Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
        } else {
            Uri.parse("geo:0,0")
        }
        val mapsIntent = Intent(Intent.ACTION_VIEW, geoUri).apply {
            setPackage("com.google.android.apps.maps")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(mapsIntent)
            Toast.makeText(this, "Opening Maps for $destination...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${Uri.encode(destination)}")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            })
        }
    }

    /**
     * Direct App Launch:
     */
    fun launchApp(appNameOrPackage: String) {
        val pkg = when (appNameOrPackage.lowercase()) {
            "calculator" -> "com.google.android.calculator"
            "camera" -> "com.android.camera"
            "whatsapp" -> "com.whatsapp"
            "spotify" -> "com.spotify.music"
            "instagram" -> "com.instagram.android"
            "youtube" -> "com.google.android.youtube"
            else -> appNameOrPackage
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(pkg)?.apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "App \"$appNameOrPackage\" is not installed", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Direct Alarm Launch:
     */
    fun createAlarm(message: String, minutesFromNow: Int) {
        val calendar = java.util.Calendar.getInstance().apply {
            add(java.util.Calendar.MINUTE, if (minutesFromNow > 0) minutesFromNow else 5)
        }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_MESSAGE, message.ifBlank { "JARVIS Reminder" })
            putExtra(AlarmClock.EXTRA_HOUR, calendar.get(java.util.Calendar.HOUR_OF_DAY))
            putExtra(AlarmClock.EXTRA_MINUTES, calendar.get(java.util.Calendar.MINUTE))
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            startActivity(intent)
            Toast.makeText(this, "Alarm set for $minutesFromNow minutes", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Alarm intent error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun startMicrophoneForegroundService() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            JarvisVoiceForegroundService.startListening(this)
            Toast.makeText(this, "JARVIS Background Audio Service Active (24/7)", Toast.LENGTH_SHORT).show()
        } else {
            requestPermissionsLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
        }
    }

    fun stopMicrophoneForegroundService() {
        JarvisVoiceForegroundService.stopListening(this)
        Toast.makeText(this, "JARVIS Audio Service Stopped", Toast.LENGTH_SHORT).show()
    }

    fun enterStandby() {
        JarvisVoiceForegroundService.enterStandby(this)
        Toast.makeText(this, "JARVIS in Standby (Say 'Hallo Javed' to wake)", Toast.LENGTH_SHORT).show()
    }

    fun speakWithNativeTTS(text: String, language: String) {
        if (!isTtsReady) return
        val targetLocale = when (language.lowercase()) {
            "hi" -> Locale("hi", "IN")
            "hinglish" -> Locale("en", "IN")
            else -> Locale.ENGLISH
        }
        textToSpeech?.language = targetLocale
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "JARVIS_TTS_${System.currentTimeMillis()}")
    }

    private fun dispatchVoiceCommandToHUD(transcript: String) {
        val sanitized = transcript.replace("\"", "\\\"").replace("'", "\\'")
        webView.evaluateJavascript("window.postMessage({ type: 'JARVIS_VOICE_COMMAND', transcript: '$sanitized' }, '*');", null)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(voiceCommandReceiver)
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}
