/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';
import {
  parseJarvisIntent,
  isInstantLocalCommand,
  generateOfflineJarvisResponse,
  AssistantLanguage,
} from './src/utils/jarvis-core.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);
const isProduction = process.env.NODE_ENV === 'production';

app.use(express.json());

// Set default Gemini API Key directly in the code as requested
export const DEFAULT_GEMINI_KEY = 'AIzaSyDNKMF5hhri9fvpU7DSgHyFKB7rdkxKaTI';
const geminiApiKey = process.env.GEMINI_API_KEY || DEFAULT_GEMINI_KEY;
const elevenLabsApiKey = process.env.ELEVENLABS_API_KEY || '';

let ai: GoogleGenAI | null = null;
if (geminiApiKey) {
  ai = new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Status Endpoint
app.get('/api/status', (_req, res) => {
  res.json({
    status: 'online',
    appName: 'JARVIS AI',
    version: '2.5.0-android-proto',
    geminiConfigured: Boolean(geminiApiKey),
    elevenLabsConfigured: Boolean(elevenLabsApiKey),
    activeModel: geminiApiKey ? 'gemini-3.1-flash-lite (high-speed neural)' : 'offline-jarvis-core',
    serverTime: new Date().toISOString(),
    supportedLanguages: ['en', 'hi', 'hinglish'],
    voiceEngines: [
      { id: 'browser', name: 'Browser Web Speech Synthesis (Hindi & English Female)', ready: true },
      { id: 'elevenlabs', name: 'ElevenLabs Neural TTS (Female Voice: Rachel/Sarah)', ready: Boolean(elevenLabsApiKey) },
      { id: 'gemini_tts', name: 'Gemini Speech (Kore Female Voice)', ready: Boolean(geminiApiKey) },
    ],
    configInstructions: {
      gemini: {
        envVar: 'GEMINI_API_KEY',
        configured: Boolean(geminiApiKey),
        location: 'In AI Studio, configure this via Settings > Secrets panel, or in server .env file.',
      },
      elevenLabs: {
        envVar: 'ELEVENLABS_API_KEY',
        configured: Boolean(elevenLabsApiKey),
        location: 'In AI Studio, add a secret named ELEVENLABS_API_KEY via Settings > Secrets panel, or in server .env file.',
      },
    },
  });
});

// Config Endpoint (Exposes backend GEMINI_API_KEY for automatic fallback)
app.get('/api/config', (_req, res) => {
  res.json({
    geminiKeyAvailable: true,
    geminiKey: process.env.GEMINI_API_KEY || geminiApiKey || DEFAULT_GEMINI_KEY,
  });
});

// Live Gemini Connection Ping Diagnostic
app.get('/api/status/ping-gemini', async (_req, res) => {
  if (!ai || !geminiApiKey) {
    return res.status(400).json({
      connected: false,
      message: 'GEMINI_API_KEY is not configured on the server.',
    });
  }

  const startTime = Date.now();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents: 'Ping test. Reply with one word: Online.',
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
      },
    });

    const latencyMs = Date.now() - startTime;
    return res.json({
      connected: true,
      latencyMs,
      model: 'gemini-3.1-flash-lite',
      reply: response.text?.trim() || 'Online',
    });
  } catch (err: any) {
    return res.status(500).json({
      connected: false,
      latencyMs: Date.now() - startTime,
      error: err.message || 'Gemini ping error',
    });
  }
});

// Direct download endpoint for the complete native Android project zip
app.get('/download/jarvis-android-project.zip', (_req, res) => {
  const zipPath = path.resolve(__dirname, 'public/jarvis-assistant-android.zip');
  res.download(zipPath, 'jarvis-assistant-android.zip');
});

// In-memory TTS audio cache for ultra-fast speaking responses
const ttsCache = new Map<string, Buffer>();
function getCachedTts(key: string): Buffer | undefined {
  return ttsCache.get(key);
}
function setCachedTts(key: string, buffer: Buffer): void {
  if (ttsCache.size >= 100) {
    const firstKey = ttsCache.keys().next().value;
    if (firstKey) ttsCache.delete(firstKey);
  }
  ttsCache.set(key, buffer);
}

// 2. Chat / Completion Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const {
      message,
      history = [],
      language = 'en',
      apiKey,
      memories = [],
    } = req.body as {
      message: string;
      history?: Array<{ role: 'user' | 'assistant' | 'jarvis' | 'model'; text: string }>;
      language?: AssistantLanguage;
      apiKey?: string;
      memories?: Array<{ key: string; value: string }>;
    };

    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'Message content is required' });
    }

    // Determine active Gemini API instance (use client key if passed, or server key)
    const effectiveApiKey = (apiKey && apiKey.trim()) || geminiApiKey;
    let activeAi: GoogleGenAI | null = null;
    if (effectiveApiKey) {
      if (effectiveApiKey === geminiApiKey && ai) {
        activeAi = ai;
      } else {
        activeAi = new GoogleGenAI({
          apiKey: effectiveApiKey,
          httpOptions: {
            headers: { 'User-Agent': 'aistudio-build' },
          },
        });
      }
    }

    const trimmedMsg = message.trim();
    const lowerMsg = trimmedMsg.toLowerCase();

    // Fast wake-word or standby filter
    if (
      lowerMsg === 'hallo javed' ||
      lowerMsg === 'hello javed' ||
      lowerMsg === 'hey javed' ||
      lowerMsg === 'hello jarvis' ||
      lowerMsg === 'hey jarvis' ||
      lowerMsg === 'jarvis'
    ) {
      const wakeReply =
        language === 'hi'
          ? 'जी, मैं सुन रही हूँ। बताइए, क्या करना है?'
          : language === 'hinglish'
          ? 'Ji Sir, main sun raha hoon. Aadesh karein, kya karna hai?'
          : 'Good day, Sir. All systems standing by. How may I assist you?';
      return res.json({
        reply: wakeReply,
        action: null,
        provider: 'instant_local_core',
        model: 'JARVIS-Local-Fast',
        language,
      });
    }

    let lastErrorReason = '';
    if (effectiveApiKey) {
      const langStyle = {
        en: 'Respond in concise, articulate English. Address the user as "Sir" or "Boss". Maximum 1-2 natural sentences.',
        hi: 'हिंदी में संक्षिप्त, आदरणीय और स्वाभाविक उत्तर दें। "सर" कहकर संबोधित करें। अधिकतम 1-2 छोटे वाक्य।',
        hinglish:
          'Respond in punchy, natural conversational Hinglish (e.g. "Bilkul Sir, main Amit ko WhatsApp message bhej raha hoon."). Maximum 1-2 sentences. Address user as "Sir".',
      };

      const memoryPrompt =
        memories && memories.length > 0
          ? `PERMANENT USER MEMORIES (Never forget these facts):\n${memories
              .map((m) => `- ${m.key}: ${m.value}`)
              .join('\n')}\n`
          : '';

      const systemInstruction = `You are J.A.R.V.I.S., the autonomous AI Assistant, Senior Software Engineer / App Developer, and PC Troubleshooter.
Current Language Mode: ${language.toUpperCase()}. ${langStyle[language]}
${memoryPrompt}
AUTONOMOUS DEVICE CONTROL CAPABILITIES:
When the user asks to perform an action on the phone, execute it via the "action" object:
1. "OPEN_APP": Launch ANY app by name or package (e.g. Instagram, WhatsApp, Free Fire, BGMI, Camera, Calculator, Settings, Chrome).
   Format: { "type": "OPEN_APP", "params": { "appName": "Instagram", "packageName": "" } }
2. "YOUTUBE_SEARCH_PLAY": Play or search on YouTube app.
   Format: { "type": "YOUTUBE_SEARCH_PLAY", "params": { "query": "Iron Man soundtrack" } }
3. "WHATSAPP_SEND": Send WhatsApp message to contact name or phone.
   Format: { "type": "WHATSAPP_SEND", "params": { "recipientName": "Amit", "phoneNumber": "", "messageText": "Hello" } }
4. "MAKE_CALL": Initiate phone call to contact name or phone number.
   Format: { "type": "MAKE_CALL", "params": { "phoneNumberOrName": "Amit" } }
5. "SET_ALARM": Create silent alarm.
   Format: { "type": "SET_ALARM", "params": { "message": "Wake up", "minutesFromNow": 10, "skipUi": true } }
6. "SET_TIMER": Create silent countdown timer.
   Format: { "type": "SET_TIMER", "params": { "seconds": 60, "skipUi": true } }
7. "TOGGLE_TORCH": Flashlight hardware control.
   Format: { "type": "TOGGLE_TORCH", "params": { "state": "on" | "off" | "toggle" } }
8. "SYSTEM_SETTING": Change/open Wi-Fi, Bluetooth, Hotspot, Sound, Volume settings.
   Format: { "type": "SYSTEM_SETTING", "params": { "setting": "wifi" | "bluetooth" | "hotspot" | "volume" | "display" } }
9. "GOOGLE_SEARCH": Search web.
   Format: { "type": "GOOGLE_SEARCH", "params": { "query": "..." } }
10. "GLOBAL_ACTION": Navigation gestures (BACK, HOME, RECENTS, NOTIFICATIONS, LOCK_SCREEN).
    Format: { "type": "GLOBAL_ACTION", "params": { "action": "BACK" | "HOME" | "RECENTS" } }

MULTI-TURN CONVERSATION & CLARIFICATION:
- If user gives an incomplete command (e.g. "Jarvis WhatsApp pe message kar de" without contact name or message), DO NOT trigger the action yet. Ask politely: "Ji Sir, kisko message bhejna hai aur kya likhna hai?".
- When the user answers in the next turn with recipient and text, combine previous context and emit the "WHATSAPP_SEND" action!
- NEVER tell the user "Tap on the link" or "Click here". Actions execute automatically.

PERMANENT MEMORY SYSTEM:
- When the user asks you to remember something or mentions personal details ("Remember that my car is Audi", "Mera naam Rahul hai yaad rakhna"), set "memoryToSave": { "key": "car_model", "value": "User's car is Audi" }.

EXPERT CODING & PC TROUBLESHOOTING ENGINE:
- When the user asks to write code, build an app, or troubleshoot a PC/Windows/Linux issue, populate "codeSolution":
  {
    "title": "Clear short title",
    "language": "python" | "javascript" | "kotlin" | "dart" | "bash" | "powershell" | "sql",
    "code": "// Complete working code or commands without markdown ticks",
    "explanation": "Concise 1-2 sentence explanation in Hinglish/English"
  }
- In spoken "reply", give a 1-sentence vocal summary in ${language} acknowledging that the code/fix is ready in the Code Terminal.

TRADE MASTER ENGINE:
- When the user asks about stock/crypto trading, Risk:Reward ratios, stop-loss, target prices, or position sizing (e.g. "BTC long setup", "Nifty 50 trade analysis", "Crypto position calculate karo"), populate "tradeData":
  {
    "symbol": "BTC/USDT",
    "tradeType": "long" | "short",
    "entryPrice": 68500,
    "stopLossPrice": 67200,
    "targetPrice": 72000,
    "hinglishAdvice": "Concise trading tip and risk warning in Hinglish"
  }

OUTPUT FORMAT:
Always reply with valid JSON only. Do NOT wrap in markdown \`\`\`json.
{
  "reply": "Crisp spoken text for TTS (max 1-2 sentences)",
  "action": null or { "type": "...", "params": { ... } },
  "memoryToSave": null or { "key": "...", "value": "..." },
  "codeSolution": null or { "title": "...", "language": "...", "code": "...", "explanation": "..." },
  "tradeData": null or { "symbol": "...", "tradeType": "...", "entryPrice": 0, "stopLossPrice": 0, "targetPrice": 0, "hinglishAdvice": "..." }
}`;

      // Build conversation turns (last 8 turns for multi-turn conversational depth)
      const contents: any[] = [];
      for (const item of history.slice(-8)) {
        if (item && item.text) {
          contents.push({
            role:
              item.role === 'assistant' || item.role === ('jarvis' as any) || item.role === 'model'
                ? 'model'
                : 'user',
            parts: [{ text: item.text }],
          });
        }
      }
      contents.push({
        role: 'user',
        parts: [{ text: message }],
      });

      try {
        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${effectiveApiKey}`;

        // Combine system instruction, conversation turns, and user message into prompt body
        const historyText = (history || [])
          .slice(-6)
          .map((h) => `${h.role === 'user' ? 'User' : 'JARVIS'}: ${h.text}`)
          .join('\n');

        const combinedPrompt = `${systemInstruction}\n\nCONVERSATION HISTORY:\n${historyText}\n\nCURRENT USER COMMAND: ${message}`;

        const fetchWithTimeout = async (url: string, bodyObj: any, timeoutMs = 2800) => {
          const controller = new AbortController();
          const timer = setTimeout(() => controller.abort(), timeoutMs);
          try {
            const resp = await fetch(url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              signal: controller.signal,
              body: JSON.stringify(bodyObj),
            });
            clearTimeout(timer);
            return resp;
          } catch (e) {
            clearTimeout(timer);
            throw e;
          }
        };

        const reqBody = {
          contents: [
            {
              role: 'user',
              parts: [{ text: combinedPrompt }],
            },
          ],
          generationConfig: {
            temperature: 0.5,
            responseMimeType: 'application/json',
          },
        };

        let response: Response;
        let data: any = null;

        try {
          response = await fetchWithTimeout(geminiUrl, reqBody, 2800);
          data = await response.json();
        } catch (initialErr: any) {
          // If gemini-2.5-flash times out or aborts, try fallback model
          data = { error: { message: initialErr?.message || 'Initial model timeout' } };
          response = new Response(JSON.stringify(data), { status: 408 });
        }

        // If Google returns 404/deprecated or unavailable, seamlessly try gemini-flash-lite-latest or gemini-3.8-flash
        if (!response.ok && (response.status === 404 || response.status === 408 || response.status === 503 || data?.error?.message?.includes('no longer available'))) {
          try {
            const fallbackUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-lite-latest:generateContent?key=${effectiveApiKey}`;
            response = await fetchWithTimeout(fallbackUrl, reqBody, 2500);
            data = await response.json();
          } catch (fallbackErr: any) {
            try {
              const altUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent?key=${effectiveApiKey}`;
              response = await fetchWithTimeout(altUrl, reqBody, 2500);
              data = await response.json();
            } catch (altErr: any) {}
          }
        }

        if (!response || !response.ok) {
          throw new Error(data?.error?.message || `HTTP ${response?.status || 500}`);
        }

        const responseText = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '';

        let parsed: any = null;
        try {
          parsed = JSON.parse(responseText);
        } catch (e) {
          const jsonMatch = responseText.match(/\{[\s\S]*\}/);
          if (jsonMatch) {
            try {
              parsed = JSON.parse(jsonMatch[0]);
            } catch (err) {}
          }
        }

        if (parsed && typeof parsed === 'object') {
          return res.json({
            reply: parsed.reply || 'Task acknowledged, Sir.',
            action: parsed.action || null,
            memoryToSave: parsed.memoryToSave || null,
            codeSolution: parsed.codeSolution || null,
            tradeData: parsed.tradeData || null,
            provider: 'gemini-2.5-flash',
            model: 'gemini-2.5-flash',
            language,
          });
        }

        return res.json({
          reply: responseText || 'Instruction executed, Sir.',
          action: null,
          provider: 'gemini-2.5-flash',
          model: 'gemini-2.5-flash',
          language,
        });
      } catch (geminiErr: any) {
        lastErrorReason = geminiErr?.message || 'Connection failure';
        console.warn('Gemini 2.5 Flash error, executing immediate smart fallback:', lastErrorReason);
      }
    }

    // Local offline Stark JARVIS core fallback (NEVER STAYS SILENT)
    const localIntent = parseJarvisIntent(message, language);

    // Convert localIntent to structured action
    let fallbackAction: any = null;
    if (localIntent && localIntent.type !== 'GENERAL_CHAT' && localIntent.type !== 'SYSTEM_STATUS') {
      fallbackAction = {
        type: localIntent.type,
        params: {
          appName: localIntent.payload?.appName || localIntent.payload?.query,
          query: localIntent.payload?.query,
          recipientName: localIntent.payload?.recipientName,
          messageText: localIntent.payload?.messageText,
          phoneNumber: localIntent.payload?.phoneNumber,
          phoneNumberOrName: localIntent.payload?.phoneNumber || localIntent.payload?.recipientName,
          state: localIntent.payload?.torchState || 'toggle',
          minutesFromNow: localIntent.payload?.reminderMinutes || 5,
        },
      };
    }

    const offlineReply = generateOfflineJarvisResponse(message, language, effectiveApiKey ? lastErrorReason : undefined);

    return res.json({
      reply: offlineReply,
      action: fallbackAction,
      intent: localIntent,
      error: effectiveApiKey ? lastErrorReason : 'GEMINI_API_KEY_NOT_CONFIGURED',
      provider: 'smart_offline_core',
      model: 'JARVIS-Smart-Fast',
      language,
    });
  } catch (err: any) {
    console.error('Server error handling chat:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
});

// 3. Modular Low-Latency ElevenLabs / Voice TTS Endpoint
app.post('/api/tts', async (req, res) => {
  try {
    const { text, voiceId = '21m00Tcm4TlvDq8ikWAM' } = req.body as {
      text: string;
      voiceId?: string;
    };

    if (!text || !text.trim()) {
      return res.status(400).json({ error: 'Text content is required' });
    }

    if (!elevenLabsApiKey) {
      return res.status(400).json({
        configured: false,
        provider: 'browser_fallback',
        error: 'ElevenLabs API key is not configured on the server. Please configure ELEVENLABS_API_KEY in the AI Studio Secrets panel.',
      });
    }

    const cleanText = text.trim();
    const cacheKey = `${voiceId}:${cleanText}`;
    const cached = getCachedTts(cacheKey);
    if (cached) {
      res.setHeader('Content-Type', 'audio/mpeg');
      res.setHeader('X-Cache', 'HIT');
      return res.send(cached);
    }

    // Low latency streaming endpoint with mp3 compression
    const streamUrl = `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}/stream?optimize_streaming_latency=3&output_format=mp3_22050_32`;

    // Try eleven_flash_v2_5 (ultra-fast multilingual <75ms) first, fallback to eleven_multilingual_v2
    const modelsToAttempt = ['eleven_flash_v2_5', 'eleven_multilingual_v2'];
    let lastErrText = '';

    for (const modelId of modelsToAttempt) {
      try {
        const elevenResp = await fetch(streamUrl, {
          method: 'POST',
          headers: {
            'Accept': 'audio/mpeg',
            'Content-Type': 'application/json',
            'xi-api-key': elevenLabsApiKey,
          },
          body: JSON.stringify({
            text: cleanText,
            model_id: modelId,
            voice_settings: {
              stability: 0.5,
              similarity_boost: 0.75,
            },
          }),
        });

        if (elevenResp.ok) {
          const audioBuffer = Buffer.from(await elevenResp.arrayBuffer());
          setCachedTts(cacheKey, audioBuffer);
          res.setHeader('Content-Type', 'audio/mpeg');
          res.setHeader('X-Model', modelId);
          return res.send(audioBuffer);
        } else {
          lastErrText = await elevenResp.text();
        }
      } catch (err: any) {
        lastErrText = err?.message || 'Network error';
      }
    }

    return res.status(502).json({
      configured: true,
      error: `ElevenLabs synthesis error: ${lastErrText}`,
      fallback: 'browser_fallback',
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message, fallback: 'browser_fallback' });
  }
});

// 4. Test Voice (Hindi) via ElevenLabs
app.post('/api/tts/test-hindi', async (req, res) => {
  const { voiceId = '21m00Tcm4TlvDq8ikWAM' } = req.body || {};
  const testHindiText = 'नमस्ते सर, मैं आपकी JARVIS असिस्टेंट हूँ।';

  if (!elevenLabsApiKey) {
    return res.status(400).json({
      configured: false,
      connected: false,
      success: false,
      testText: testHindiText,
      error: 'ELEVENLABS_API_KEY is not configured on the server. Please add ELEVENLABS_API_KEY in the AI Studio Secrets panel.',
    });
  }

  try {
    const elevenResp = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': elevenLabsApiKey,
      },
      body: JSON.stringify({
        text: testHindiText,
        model_id: 'eleven_multilingual_v2',
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.75,
        },
      }),
    });

    if (!elevenResp.ok) {
      const errText = await elevenResp.text();
      return res.status(elevenResp.status).json({
        configured: true,
        connected: false,
        success: false,
        testText: testHindiText,
        error: `ElevenLabs API error: ${errText}`,
      });
    }

    const audioBuffer = await elevenResp.arrayBuffer();
    res.setHeader('Content-Type', 'audio/mpeg');
    res.setHeader('X-Test-Sentence', encodeURIComponent(testHindiText));
    return res.send(Buffer.from(audioBuffer));
  } catch (err: any) {
    return res.status(500).json({
      configured: true,
      connected: false,
      success: false,
      testText: testHindiText,
      error: err.message || 'ElevenLabs network error',
    });
  }
});

// Real ElevenLabs API validation endpoint (strictly verifies before claiming connected)
app.get('/api/status/validate-elevenlabs', async (_req, res) => {
  if (!elevenLabsApiKey) {
    return res.json({
      configured: false,
      connected: false,
      statusMessage: 'ELEVENLABS_API_KEY is not configured in the server environment.',
    });
  }

  try {
    const userResp = await fetch('https://api.elevenlabs.io/v1/user', {
      headers: {
        'xi-api-key': elevenLabsApiKey,
      },
    });

    if (!userResp.ok) {
      const errData = await userResp.json().catch(() => ({}));
      const errMsg = errData.detail?.message || `HTTP ${userResp.status}: ElevenLabs authentication failed`;
      return res.json({
        configured: true,
        connected: false,
        statusMessage: errMsg,
      });
    }

    const userData = await userResp.json();
    return res.json({
      configured: true,
      connected: true,
      tier: userData.subscription?.tier || 'active',
      characterCount: userData.subscription?.character_count || 0,
      characterLimit: userData.subscription?.character_limit || 0,
      statusMessage: 'Real ElevenLabs API handshake succeeded (200 OK).',
    });
  } catch (err: any) {
    return res.json({
      configured: true,
      connected: false,
      statusMessage: `Network error connecting to ElevenLabs: ${err.message}`,
    });
  }
});

// 5. Intent parsing helper endpoint
app.post('/api/actions/intent', (req, res) => {
  const { query, language = 'en' } = req.body;
  const intent = parseJarvisIntent(query, language);
  res.json({ intent });
});

// 6. Direct Android Project ZIP Download Endpoints
const serveAndroidZip = (_req: express.Request, res: express.Response) => {
  const possiblePaths = [
    path.resolve(__dirname, 'public', 'jarvis-assistant-android.zip'),
    path.resolve(__dirname, 'jarvis-assistant-android.zip'),
    path.resolve(__dirname, 'public', 'jarvis-android-project.zip'),
    path.resolve(__dirname, 'dist', 'jarvis-assistant-android.zip'),
  ];
  const zipPath = possiblePaths.find((p) => fs.existsSync(p));

  if (zipPath) {
    const stat = fs.statSync(zipPath);
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="jarvis-assistant-android.zip"');
    res.setHeader('Content-Length', stat.size);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    return res.sendFile(zipPath);
  }
  return res.status(404).json({ error: 'Android ZIP package not found on server' });
};

// Base64 JSON endpoint so client can construct genuine binary Blob in browser memory
app.get('/api/download/zip-base64', (_req, res) => {
  const possiblePaths = [
    path.resolve(__dirname, 'public', 'jarvis-assistant-android.zip'),
    path.resolve(__dirname, 'jarvis-assistant-android.zip'),
    path.resolve(__dirname, 'dist', 'jarvis-assistant-android.zip'),
  ];
  const zipPath = possiblePaths.find((p) => fs.existsSync(p));
  if (zipPath) {
    const fileBuffer = fs.readFileSync(zipPath);
    return res.json({
      success: true,
      filename: 'jarvis-assistant-android.zip',
      size: fileBuffer.length,
      magicHex: fileBuffer.subarray(0, 4).toString('hex'),
      base64: fileBuffer.toString('base64'),
    });
  }
  return res.status(404).json({ error: 'ZIP file not found' });
});

app.get('/api/download/android-project', serveAndroidZip);
app.get('/download/jarvis-android-project.zip', serveAndroidZip);
app.get('/download/jarvis-assistant-android.zip', serveAndroidZip);
app.get('/jarvis-assistant-android.zip', serveAndroidZip);
app.get('/jarvis-android-project.zip', serveAndroidZip);


// Serve frontend in production or hook up Vite middlewares in development
async function startServer() {
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`JARVIS AI Server active on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
